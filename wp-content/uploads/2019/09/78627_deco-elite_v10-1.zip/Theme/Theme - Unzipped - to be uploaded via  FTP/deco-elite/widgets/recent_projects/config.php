<?php
/**
 * Config file, return as json_encode
 * http://www.aa-team.com
 * ======================
 *
 * @author		AA-Team
 * @version		1.0
 */
$decoElite = $GLOBALS['decoElite']; 
echo json_encode(
	array(
		'recent_projects' => array(
			'version' => '1.0',
			'title' => esc_html__('Deco Elite Recent Projects', 'deco-elite'),
			'description' => esc_html__("With this widget you can add recent projects to your site!", 'deco-elite'),
			'options' => array(
				'title' 	=> array(
					'title'		=> esc_html__('Title', 'deco-elite'),
					'type' 		=> 'text',
					'width'		=> '100%',
					'std' 		=> esc_html__('Latest Projects', 'deco-elite')	
				),
				
				'url' 	=> array(
					'title'		=> esc_html__('Link to project list', 'deco-elite'),
					'type' 		=> 'text',
					'width'		=> '100%',
					'std' 		=> esc_html__('#', 'deco-elite')	
				),
				
				'nb' 	=> array(
					'title'		=> esc_html__('Number of projects.', 'deco-elite'),
					'type' 		=> 'text',
					'width'		=> '100%',
					'std' 		=> 4	
				),
			)
		)
	)
);