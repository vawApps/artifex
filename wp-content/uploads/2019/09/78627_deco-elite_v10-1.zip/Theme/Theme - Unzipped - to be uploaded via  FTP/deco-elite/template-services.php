<?php  
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Amazon Affiliate Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *  Template Name: Template Services
 *	
**/
get_header();
add_filter("the_content", array( $decoElite->coreFunctions,"the_content_filter" ));
$page_size = 'col-lg-9 col-md-8 col-sm-8 col-xs-12';

if( isset($decoElite->coreFunctions->data['page_sidebars']) == false || count($decoElite->coreFunctions->data['page_sidebars']) == 0 ){
	$page_size = 'col-lg-12 col-sm-12 col-xs-12';
}
?>
	<div class="container-fluid de-resizeable-container de-template-services">
		<?php
			$decoElite->coreFunctions->printSidebar( 'left' );
		?>
		
		<!-- Main Content Section -->
		<div class="de-main-content-box post-entry">
			<div class="extra-container-box">		
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<?php the_content(); ?>		
				<?php endwhile; endif; ?> 					
			</div>
		</div>
		
		<?php
			$decoElite->coreFunctions->printSidebar( 'right' );
		?>
	</div>
    <!-- end of content -->

<?php get_footer(); ?>