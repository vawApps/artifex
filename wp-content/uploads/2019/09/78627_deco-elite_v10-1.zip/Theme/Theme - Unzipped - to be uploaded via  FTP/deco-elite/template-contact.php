<?php 
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Amazon Affiliate Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *  Template Name: Template Contact
 *	
**/
get_header();

$page_size = 'col-lg-9 col-md-8 col-sm-8 col-xs-12';

if( isset($decoElite->coreFunctions->data['page_sidebars']) == false || count($decoElite->coreFunctions->data['page_sidebars']) == 0 ){
	$page_size = 'col-lg-12 col-sm-12 col-xs-12';
}
?>
	<div class="container-fluid de-resizeable-container de-template-contact">
		<div class="row">
			<?php
				$decoElite->coreFunctions->printSidebar( 'left' );
			?>
			<div class="<?php echo $page_size;?> section-page-contact">
				<!-- Main Content Section -->
				<div class="de-main-content-box post-entry">
					<div class="extra-container-box">	
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<article id="post_<?php echo $post->ID; ?>" <?php post_class(); ?>>
							<div class="the-content" <?php post_class(); ?>>
								<?php if(isset($data['single_image']) && $data['single_image'] == "1"): $blog_thumb = wp_get_attachment_image_src(get_post_thumbnail_id(), 'thumb-post-featured'); ?>
									<?php if(has_post_thumbnail()): ?>
									<div class="row-fluid">
										<div class="span16">
											<a class="s_thumb" href="<?php echo esc_url( $preview[0] ); ?>" rel="prettyPhoto">
												<img src="<?php echo $thumb[0]; ?>" alt="<?php echo the_title(); ?>" />
											</a>
										</div>
									</div>
									<?php endif; ?>
								<?php endif; ?>
								
								<?php 
								if( isset($decoElite->coreFunctions->data['layout']['print_page_title']) && $decoElite->coreFunctions->data['layout']['print_page_title'] == 'no' ){}else{
								?>
									<h1><?php the_title(); ?></h1>
								<?php }?>
								<?php the_content(); ?>
							</div>
						</article>
		
					<?php endwhile; endif; ?> 
					
					</div>
				</div>
			</div>
			<?php
				$decoElite->coreFunctions->printSidebar( 'right' );
			?>
		</div>
	</div>
    <!-- end of content -->

<?php get_footer(); ?>
