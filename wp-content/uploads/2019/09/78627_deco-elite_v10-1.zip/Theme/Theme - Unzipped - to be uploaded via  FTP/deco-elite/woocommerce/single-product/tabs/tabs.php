<?php
/**
 * Single Product tabs
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Filter tabs and allow third parties to add their own
 *
 * Each tab is an array containing title, callback and priority.
 * @see woocommerce_default_product_tabs()
 */
$tabs = apply_filters( 'woocommerce_product_tabs', array() );

if ( ! empty( $tabs ) ) : ?>
<div class="row">
	<div class="de_tabs col-lg-12 col-sm-12">
		<!-- Tab panes -->
		<div class="de_tab_content">
			<?php 
			$cc = 0;
			foreach ( $tabs as $key => $tab ) : 
			?>
				<p class="de_tab_title"><?php echo apply_filters( 'woocommerce_product_' . $key . '_tab_title', $tab['title'], $key ) ?></p>
				<div class="entry-content tab-pane <?php echo $cc == 0 ? 'active': '';?>" id="tab-<?php echo $key ?>">
					<div class="de_tabs_entry">
					<?php call_user_func( $tab['callback'], $key, $tab ) ?>
					</div>
				</div>
			<?php
				$cc++; 
			endforeach; 
			?>
		</div>
	</div>
</div>
<?php endif; ?>