/*
Document   :  decoEliteSidebars
Author     :  AA-Team http://themeforest.net/user/AA-Team
*/
// Initialization and events code for the app
decoEliteSidebars = (function ($) {
    "use strict";

    // public
    var debug_level = 0;
    var maincontainer = null;
    
    var sidebar_row = 0;

	// init function, autoload
	(function init() {
		// load the triggers
		$(document).ready(function(){
			maincontainer = $(".decoElite-panel");
			sidebar_row = parseInt($("#decoElite-sidebars-nr").val()) + 1;
    
			triggers();
		});
	})();
	
	
	function deleteSidebar( $btn )
	{
		var contentDom 	= jQuery("#decoElite-panel-content-step"),
			parentRow = $btn.parents('.decoElite-form-row');
		
		if (confirm('Are you sure to delete this sidebar?')) {
			
			parentRow.remove();
			if(contentDom.find('.decoElite-form-row').size() == 0) {
				contentDom.find('#decoElite-ingredient-no-items').show();
				
				sidebar_row = 0;
			}
			
			sidebar_row++;
		}
	}
	
	function makeSortableSidebar() 
	{
		jQuery(function() {
			jQuery( "div#decoElite-panel-content-ingredient" ).sortable({
				placeholder: "decoElite-form-row-fake-ingredient",
				stop: function() {
				}
			});
		});
	}
	
	function makeSortableSidebar() 
	{
		jQuery(function() {
			jQuery( "div#decoElite-panel-content-sidebar" ).sortable({
				placeholder: "decoElite-form-row-fake-sidebar",
				stop: function() {
				}
			});
		});
	}
	
	function addNewSidebar() 
	{
		var contentDom 	= jQuery("#decoElite-panel-content-sidebar"),
			lastRow 	= contentDom.find('.decoElite-form-row').last(),
			template_step = maincontainer.find("#decoElite-template-sidebar"),
			clone = template_step.clone();
			
		clone.find('input,textarea').each(function(){
			var that = $(this),
				name = that.data('name');
			that.attr('name', "sidebar[" + ( sidebar_row ) + "][" + ( name ) + "]");
		});
		 
		// append new posible step
		if(contentDom.find('.decoElite-form-row').size() > 0){
			lastRow.after( clone.html() );
		}else{
			contentDom.append( clone.html() );
			contentDom.find('#decoElite-sidebar-no-items').hide();
		}
		makeSortableSidebar();
		sidebar_row++;
	}
	
	function sidebarCheckNew( value, that )
	{
		var sidebar_position = $("#decoElite-sidebar-position");
			
		$("#decoElite-sidebar-items").find('tr').hide();
		$("#decoElite-" + ( value ) + "-sidebar-item").show();
		
		$("#decoElite-sidebar-position").find('a').removeClass('on');
		that.addClass('on');
		
		sidebar_position.find('input[type="radio"]').prop('checked', false);
		sidebar_position.find('input[value="' + ( value ) + '"]').prop('checked', true);
	}
	
	function triggers()
	{
		maincontainer.on('click', '#decoElite-add-new-sidebar', function(e) {
			e.preventDefault();
			addNewSidebar();
		});
		
		maincontainer.on('click', 'a.sidebar-delete-btn', function(e) {
			e.preventDefault();
			deleteSidebar(jQuery(this));
		});
		
		makeSortableSidebar();
	}

	// external usage
	return {}
})(jQuery);