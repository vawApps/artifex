<?php 
// Make sure we don't expose any info if called directly
if ( ! function_exists( 'add_action' ) ) {
    die('Direct script access not allowed');
}

if(class_exists('decoElite_recent_projects') != true) 
{
	class decoElite_recent_projects extends WP_Widget 
	{
		private $the_theme = null;
		private $the_widget = array();
		private $alias = 'recent_projects';
		
	    private $default_config = array(
	        'title' => ''
	    );
	    
	    public function __construct() 
	    {
			global $decoElite;
			//  
			$this->the_theme = $decoElite;
			$this->the_widget = $this->the_theme->cfg['widgets'][$this->alias];
			if( isset($this->the_widget) && count($this->the_widget) > 0 ){
				$widget_ops = array(
		            'classname'   => 'widget_' . $this->the_theme->alias . '_' . $this->alias, 
		            'description' => $this->the_widget[$this->alias]['description']
		        );
		        parent::__construct( $this->the_theme->alias . '-' . $this->alias, $this->the_theme->alias . ' - ' . $this->the_widget[$this->alias]['title'], $widget_ops);
			}
	    }
	

	    public function widget( $args, $instance ) 
	    {
	        extract( $args );
			
			$Qargs = array(
				'post_type' => 'projects',
				'posts_per_page' => (int)$instance['nb']
			);
			
			$rPosts = new WP_Query($Qargs);
			
			echo $args['before_widget'];
			?>
			<!-- Custom Text Widget -->
			<div class="de-recent_projects">
				<h3><?php echo esc_attr($instance["title"]); ?></h3>
				<ul>
					<?php while ($rPosts->have_posts()) : $rPosts->the_post(); ?>
						<li>
							<?php if( has_post_thumbnail($rPosts->ID) ){?>
								<a href="<?php echo esc_url(get_permalink($rPosts->ID));?>"><?php echo get_the_post_thumbnail( $rPosts->ID, 'decoElite-project-list-image' ); ?></a>
							<?php } ?>
						</li>
					<?php endwhile; ?>
				</ul>
				
				<?php if(trim($instance["url"]) != "" ){?>
					<a href="<?php echo esc_url($instance["url"]);?>" class="recent_projects-btn"><?php esc_html_e('view all projects', 'deco-elite')?></a>
				<?php } ?>
			</div>
			<?php 
			echo $args['after_widget'];
	    }
	    
	    public function parse_output($instance)
	    {
	        $html = array();
	        
	        return implode("\n", $html);
	    }
	    
	    public function update( $new_instance, $old_instance )
	    {   
	        $instance = $old_instance;
	        // Strip tags from title and name to remove HTML 
	        if( count($this->the_widget[$this->alias]['options']) > 0 ){
	        	foreach ($this->the_widget[$this->alias]['options'] as $key => $value) {
					$instance[$key] = esc_html( $_REQUEST[$key] );  
				}
	        } 
			
	        return $instance;
	    }
	
	    public function form( $instance ) 
	    {
	    	echo $this->the_theme->print_widget_fields( $this->the_widget[$this->alias]['options'], $instance );
	    }
	}

	// register the widgets
	add_action( 'widgets_init', create_function( '', 'return register_widget("decoElite_' . ( $GLOBALS['decoElite_current_widget'] ) . '");' ) );
}