<?php
/**
 * AA-Team - http://www.aa-team.com
 * ===============================+
 *
 * @package		decoEliteAdminMenu
 * @author		Andrei Dinca
 * @version		1.0
 */
! defined( 'ABSPATH' ) and exit;

if(class_exists('decoEliteAdminMenu') != true) {
	class decoEliteAdminMenu {
		
		/*
        * Some required plugin information
        */
        const VERSION = '1.0';

        /*
        * Store some helpers config
        */
		public $the_plugin = null;
		private $the_menu = array();
		private $current_menu = '';
		private $ln = '';

		static protected $_instance;

        /*
        * Required __construct() function that initalizes the AA-Team Framework
        */
        public function __construct()
        {
        	global $decoElite;
        	$this->the_plugin = $decoElite;
			$this->ln = $this->the_plugin->localizationName;
			
			// update the menu tree
			$this->the_menu_tree();
			
			return $this;
        }

		/**
	    * Singleton pattern
	    *
	    * @return decoEliteDashboard Singleton instance
	    */
	    static public function getInstance()
	    {
	        if (!self::$_instance) {
	            self::$_instance = new self;
	        }

	        return self::$_instance;
	    }
		
		private function the_menu_tree()
		{
			$this->the_menu['dashboard'] = array( 
				'title' => esc_html__( 'Dashboard', 'deco-elite' ),
				'url' => admin_url("admin.php?page=decoElite#!/dashboard"),
				'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
				'menu_icon' => 'images/16_dashboard.png'
			);
			
			$this->the_menu['layout'] = array( 
				'title' => esc_html__( 'Layout', 'deco-elite' ),
				'url' => admin_url("admin.php?page=decoElite#!/layout"),
				'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
				'menu_icon' => 'images/16_layout.png'
			);
			
			$this->the_menu['sidebars'] = array( 
				'title' => esc_html__( 'Sidebars', 'deco-elite' ),
				'url' => "#!/",
				'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
				'menu_icon' => 'images/16_sidebarsection.png',
				'submenu' => array(
					'sidebars' => array(
						'title' => esc_html__( 'Sidebars Manager', 'deco-elite' ),
						'url' => admin_url("admin.php?page=decoElite#!/sidebars"),
						'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
						'menu_icon' => 'images/16_sidebars.png'
					),
					
					'sidebars_per_sections' => array(
						'title' => esc_html__( 'Sidebars Per Sections', 'deco-elite' ),
						'url' => admin_url("admin.php?page=decoElite#!/sidebars_per_sections"),
						'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
						'menu_icon' => 'images/16_sidebarsec.png',

					),
				)
			);
			
			$this->the_menu['widgets_manager'] = array( 
				'title' => esc_html__( 'Widgets Manager', 'deco-elite' ),
				'url' => admin_url("admin.php?page=decoElite#!/widgets_manager"),
				'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
				'menu_icon' => 'images/16_widgets.png'
			);
			
			$this->the_menu['bulk_products_colors_check'] = array( 
				'title' => esc_html__( 'Bulk Colors Check', 'deco-elite' ),
				'url' => admin_url("admin.php?page=decoElite#!/bulk_products_colors_check"),
				'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
				'menu_icon' => 'images/16_colors.png'
			);
			
			$this->the_menu['general'] = array( 
				'title' => esc_html__( 'Theme Settings', 'deco-elite' ),
				'url' => "#!/",
				'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
				'menu_icon' => 'images/16_pluginsett.png',
				'submenu' => array(
					'modules_manager' => array(
						'title' => esc_html__( 'Modules Manager', 'deco-elite' ),
						'url' => admin_url("admin.php?page=decoElite#!/modules_manager"),
						'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
						'menu_icon' => 'images/16_modules.png'
					),
					
					'setup_backup' => array(
						'title' => esc_html__( 'Setup / Backup', 'deco-elite' ),
						'url' => admin_url("admin.php?page=decoElite#!/setup_backup"),
						'folder_uri' => $this->the_plugin->cfg['paths']['freamwork_dir_url'],
						'menu_icon' => 'images/16_setupbackup.png'
					),
				)
			);
		}
		
		public function show_menu()
		{
			$plugin_data = $this->the_plugin->theme_data();
			//var_dump('<pre>',,'</pre>'); die;  
			$html = array();
			// id="decoElite-nav-dashboard" 
			$html[] = '<div id="decoElite-header">';
			$html[] = 	'<div id="decoElite-header-bottom">';
			$html[] = 		'<div id="decoElite-topMenu">';
			$html[] = 			'<a href="' . esc_url('http://codecanyon.net/item/woocommerce-amazon-affiliates-wordpress-plugin/3057503?ref=AA-Team'). '" target="_blank" class="decoElite-product-logo">
									<img src="' . ( $this->the_plugin->cfg['paths']['theme_dir_url'] ) . 'thumb.png" alt="">
									<h2><b>Deco Elite</b> Wordpress Theme</h2>
									<h3>' . ( $plugin_data['version'] ) . '</h3>
									
									<span class="decoElite-rate-now"></span>
									<img src="' . ( $this->the_plugin->cfg['paths']['freamwork_dir_url'] ) . 'images/rate-now.png" class="decoElite-rate-img">
									<img src="' . ( $this->the_plugin->cfg['paths']['freamwork_dir_url'] ) . 'images/star.gif" class="decoElite-rate-gif">
									<strong>Don`t forget to rate us!</strong>
								</a>';
			$html[] = 			'<ul>';
								foreach ($this->the_menu as $key => $value) {
									$iconImg = '<img src="' . ( $value['folder_uri'] . $value['menu_icon'] ) . '" />';
									$html[] = '<li id="decoElite-nav-' . ( $key ) . '" class="decoElite-section-' . ( $key ) . ' ' . ( isset($this->current_menu[0]) && ( $key == $this->current_menu[0] ) ? 'active' : '' ) . '">';
									
									if( $value['url'] == "#!/" ){
										$value['url'] = 'javascript: void(0)';
									}
									$html[] = 	'<a href="' . ( $value['url'] ) . '">' . ( $iconImg ) . '' . ( $value['title'] ) . '</a>';
									if( isset($value['submenu']) ){
										$html[] = 	'<ul class="decoElite-sub-menu">';
										foreach ($value['submenu'] as $kk2 => $vv2) {
											if( ($kk2 != 'synchronization_log') && !in_array( $kk2, array_keys($this->the_plugin->cfg['activate_modules'])) ) continue;
		
											$iconImg = '<img src="' . ( $vv2['folder_uri'] . $vv2['menu_icon'] ) . '" />';
											$html[] = '<li class="decoElite-section-' . ( $kk2 ) . '  ' . ( isset($this->current_menu[1]) && $kk2 == $this->current_menu[1] ? 'active' : '' ) . '" id="decoElite-sub-nav-' . ( $kk2 ) . '">';
											$html[] = 	$iconImg;
											$html[] = 	'<a href="' . ( $vv2['url'] ) . '">' . ( $vv2['title'] ) . '</a>'; 
											
											if( isset($vv2['submenu']) ){
												$html[] = 	'<ul class="decoElite-sub-sub-menu">';
												foreach ($vv2['submenu'] as $kk3 => $vv3) {
													$html[] = '<li id="decoElite-sub-sub-nav-' . ( $kk3 ) . '">';
													$html[] = 	'<a href="' . ( $vv3['url'] ) . '">' . ( $vv3['title'] ) . '</a>';
													$html[] = '</li>';
												}
												$html[] = 	'</ul>';
											}
											$html[] = '</li>';
										}
										$html[] = 	'</ul>';
									}
									$html[] = '</li>';
								}
			$html[] = 			'</ul>';
			$html[] = 		'</div>';
			$html[] = 	'</div>';
			
			$html[] = 	'<a href="' . esc_url('http://codecanyon.net/user/AA-Team/portfolio?ref=AA-Team').'" class="decoElite-aateam-logo">AA-Team</a>';
			
			$html[] = '</div>';
			
			$html[] = '<script>
			(function($) {
				var decoEliteMenu = $("#decoElite-topMenu");
				
				decoEliteMenu.on("click", "a", function(e){
					
					var that = $(this),
						href = that.attr("href");
					
					if( href == "javascript: void(0)" ){
						var current_open = decoEliteMenu.find("li.active");
						current_open.find(".decoElite-sub-menu").slideUp(350);
						current_open.removeClass("active");
						
						that.parent("li").eq(0).find(".decoElite-sub-menu").slideDown(350, function(){
							that.parent("li").eq(0).addClass("active");
						});
					}
				});
			})(jQuery);
			
			</script>';
			
			echo implode("\n", $html);
		}

		public function make_active( $section='' )
		{
			$this->current_menu = explode("|", $section);
			return $this;
		}
	}
}