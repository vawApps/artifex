<?php   
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Amazon Affiliate Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *	
**/

get_header(); 
global $woocommerce;

$gallery_meta = get_post_meta( $post->ID, '_project_full_img', true );
?>
	<div class="de-content">
		
   	<div class="container-fluid de-single-project woocommerce">
		<div class="row">
			<!-- Main Container -->
			<section id="post-<?php the_ID(); ?>" class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
				<?php if( have_posts() ) : while( have_posts() ) : the_post();?>
				<div class="de-project-details-text">
					<div class="de-post-title-wrap">
						<h6 class="de-project-cat"><?php echo get_the_term_list( get_the_ID(), 'projects_category', '', ', ', '' ); ?></h6>
						<?php
						if( isset($decoElite->coreFunctions->settings['layout']['fb_like_share']) && trim($decoElite->coreFunctions->settings['layout']['fb_like_share']) == 'yes' ){
						?>
							<div class="fb-like" data-href="<?php echo esc_url( get_permalink() ); ?>" data-width="91" data-layout="button" data-action="like" data-show-faces="false" data-share="true"></div>
						<?php } ?>
						
						<div class="clear"></div>
						<h1><?php  the_title(); ?></h1>
					</div>
					<div class="clear"></div>
					
					<div class="post-entry">
						<?php
						$content = get_the_content();
						
						if( has_shortcode( $content, 'decoElite_project_gallery') ) {
							the_content();
						}else{
						?>
							<div class="de_simple_post_image de_hovereffect">
								<a href="<?php echo esc_url( wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) ) ); ?>" class="prettyPhoto">
									<?php
										echo get_the_post_thumbnail( $project_id, 'blog-featured-image' );
									?>
									<div class="mask">
									 	<div class="de_bk_icon">
											<i class="fa fa-link"></i>
										</div>
									</div>
								</a>
							</div>
						<?php
							the_content();
						}
						?>
						<?php //the_content(); ?>
					</div>
				</div>		
				<?php endwhile; endif; ?>
				
				<div class="clear"></div>
				
			</section>
			
			<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 de-applied-products-wrap">
				<div id="de-applied-products">
					<h3><?php esc_html_e('Products in this collection', 'deco-elite'); ?></h3>
					<div id="de-bd-wrap">
						<?php if( isset($gallery_meta) && is_array($gallery_meta) && count($gallery_meta) > 0 ) { ?>
						
						<?php
							$added_products = array();
							foreach ( $gallery_meta as $image ) {
								$image_full = wp_get_attachment_image_src( $image['image'], 'full' );
								$pins = json_decode( $image['pins'], true );
						?>
							<?php
								if( count($pins) > 0 && $pins != '' ) {
										$pins = array_unique($pins, SORT_REGULAR); 
									
									foreach( $pins as $pin ) {
										$product_id = $pin['product'];
										
										if( in_array( $product_id, $added_products ) ) continue;
										
										$added_products[] = $product_id;
										$status = get_post_status( $product_id );

										if( $status == 'publish' ) {
										$product = get_product($product_id);
										$product_metas = get_post_meta( $product_id );
										$title = get_the_title($product_id);   
									?>
									<div class="item">
										<p class="de-prod-img">
											<?php if (has_post_thumbnail( $product_id ) ): ?>
												<?php if( $product->is_on_sale() ){?>
									        	<span class="de-sale-badge"><?php esc_html_e('Sale' , 'deco-elite'); ?></span>
										        <?php }?>
												<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'single-post-thumbnail' ); ?>
												<img src="<?php echo $image[0]; ?>" />
											<?php endif; ?>
										</p>
										<a href="<?php echo esc_url( get_permalink( $product_id ) ); ?>" target="_blank"><h6 class="de-prod-title"><?php echo strlen($title) > 30 ? substr($title, 0, 30) . '&hellip;' : $title; ?></h6></a>
										<?php
											$sale_price = $product_metas["_sale_price"][0]; 
											$regular_price = $product_metas["_regular_price"][0];
											$price = $product_metas["_price"][0];
										?>
										<p class="de-prod-price">
											<?php
												$currency = get_woocommerce_currency_symbol();
												if( isset($regular_price) && $regular_price != '' ){
													if( isset($sale_price) && $sale_price != ''  ) {
														echo '<del style="color: #000;">'.$regular_price.$currency.'</del>';
													} else {
														echo $regular_price.$currency;
													}
												}
												
												if( isset($sale_price) && $sale_price != '' ){
													echo $sale_price.$currency;
												}
											?>
										</p>
										
										<a class="de-prod-add-to-cart add_to_cart_button product_type_simple" data-product_id="<?php echo $product_id; ?>" href="<?php echo esc_url( get_permalink() ); ?>?add-to-cart=<?php echo $product_id; ?>"><?php esc_html_e('Add to cart', 'deco-elite'); ?></a>
										
									</div>
									<?php } ?>
							<?php	 
									}
								}
							}
						?>
						<?php
						} else {
							echo '<p>' . esc_html__('No products available in this collection', 'deco-elite') . '</p>';
						}
						?>	  
					</div>
				</div>
			</div>
			
			<?php if( isset($decoElite->coreFunctions->settings['layout']['enable_complementary_products']) && trim($decoElite->coreFunctions->settings['layout']['enable_complementary_products']) == 'yes' ){ ?>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="de_complementary_wrap">
					<div class="de_complementary_title">
						<h2><?php esc_html_e('Complementary products from the collection', 'deco-elite'); ?></h2>
					</div>
					
					<a class="de-view-all-prod" href="<?php echo function_exists('woocommerce_get_page_id') ? esc_url( get_permalink( woocommerce_get_page_id( 'shop' ) ) ) : "#"; ?>"><?php esc_html_e('View all', 'deco-elite'); ?></a>
					
					<?php
					global $product;
					$args = array(
						'post_type' => 'product',
						'posts_per_page' => 4
					);
					$loop = new WP_Query( $args );
					?> 
					
					<div class="row">
						<div id="de_complementary_products">
						<?php
						if ( $loop->have_posts() ) {
							while ( $loop->have_posts() ) : $loop->the_post();
							$title = get_the_title();
						?>
							<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
								<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>
								<div class="de-products de-white-bg">
									<div class="de-prod-container">
										
										<div class="de-fp-prod-image">
											<?php if( $product->is_on_sale() ){?>
								        	<span class="de-sale-badge"><?php esc_html_e('Sale' , 'deco-elite'); ?></span>
									        <?php }?>
									        <div class="wish-comparebtns">
										        <?php
										        	if( shortcode_exists('yith_wcwl_add_to_wishlist')) {
										        		echo do_shortcode('[yith_wcwl_add_to_wishlist wishlist_url="'. get_site_url() .'/wishlist/"]');
													} 
										        ?>
										    	<?php 
										    		if( shortcode_exists('yith_compare_button')) {
										    			echo do_shortcode('[yith_compare_button]'); 
													}
										    	?>
									        </div>
									        <div class="product-hover-mask">
												<a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo woocommerce_template_loop_product_thumbnail();?></a>
											</div>
										</div>
										
										<div class="de-fp-prod-info">
											<a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo strlen($title) > 20 ? substr($title, 0, 20) . '&hellip;' : $title; ?></a>
											<p>
												<?php echo woocommerce_template_loop_price(); ?>
											</p>
											<div class="de_buttons_wrapper">
												<div class="de-add-to-cart-button"><?php echo woocommerce_template_loop_add_to_cart(); ?></div>
											</div>
										</div>
									</div>
								</div>
							</div>
								
						<?php
							endwhile;
						} else {
							echo "<div class='col-lg-12'>" . esc_html__( 'No products found', 'deco-elite' ) . '</div>';
						}
						wp_reset_postdata();
						?>
						</div>
					</div>
				</div>	
			</div><!-- end .de_complementary_wrap -->
			<?php } ?>
				
			<?php if( isset($decoElite->coreFunctions->settings['layout']['enable_other_collections']) && trim($decoElite->coreFunctions->settings['layout']['enable_other_collections']) == 'yes' ){ ?>
			<div class="de-content de_other_collection">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					
					<h2 class="de_other_collection_title"><?php esc_html_e('Other collections you might like', 'deco-elite'); ?></h2>
					<a class="de-view-all-collections" href="<?php esc_url( bloginfo('siteurl') ); ?>/projects/"><?php esc_html_e('View all', 'deco-elite'); ?></a>
					
					<div class="row">
					<?php
						$args = array(
						    'numberposts' => 4,
						    'orderby' => 'post_date',
						    'order' => 'DESC',
						    'post_type' => 'projects',
						    'post_status' => 'publish',
						    'suppress_filters' => true 
						);
					
					    $recent_projects = wp_get_recent_posts( $args, ARRAY_A );
						if( count( $recent_projects ) > 0 ){
							$cc = 1;
							foreach ($recent_projects as $project) {
								
								$project_link = esc_url( get_permalink( $project['ID'] ) );
								$project_terms = get_the_terms( $project['ID'], 'projects_category' );
								$project_category = $project_terms[0]->name;
								$project_thumbnail_id = get_post_thumbnail_id( $project['ID'] );
								$project_thumb = wp_get_attachment_image_src( $project_thumbnail_id, 'decoElite-project-list-image' );
								if( $cc % 2 == 0 ) {
									$elem_no = 'second';
								} elseif( $cc % 3 == 0 ) {
									$elem_no = 'third';
								} else {
									$elem_no = 'first';
								}
								$html[] = '<div class="de-collection-box col-lg-3 col-md-6 col-sm-6 col-xs-12">';
									$html[] = '<div class="de-two-rows de-fp-product de-'. $elem_no .'">';
										if( $project_thumb != false ){
											$html[] = '<div class="de-product-img de-proj-home">';
												$html[] = '<img alt="" src="' . ( $project_thumb[0] ) . '">';
												$html[] = '<a href="' . ( $project_link ) . '" class="info">'; 
												$html[] = '<span class="mask"><i class="fa fa-link"></i></span>';
												$html[] = '</a>';
											$html[] = '</div>';
										}
										else { }
										$html[] = '<h6>'. $project_category .'</h6>';
										$html[] = '<h3>' . ( $project['post_title'] ) . '</h3>';
										$html[] = '<p>' . ( strlen($project['post_excerpt']) > 55 ? substr($project['post_excerpt'], 0, 55) . '...' : $project['post_excerpt'] ) . '</p>';
										$html[] = '<a href="' . ( $project_link ) . '" class="link">'.esc_html__('Learn More', 'deco-elite').'</a>';
									$html[] = '</div>';
								$html[] = '</div>';
							$cc++;
							}
						}
						
						echo implode("\n", $html);
					?>
					</div>
					
				</div>
			</div><!-- end de_other_collection -->
			<?php } ?>
			
		</div>
  	</div>
  	</div>
    <!-- end of content -->
<?php get_footer(); ?>
