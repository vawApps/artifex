<!-- Footer -->
<?php
global $decoElite;
?>
	<!-- Footer -->
	<div class="de-footer">
		<?php if( isset($decoElite->coreFunctions->settings['layout']['enable_footer_sidebar']) && trim($decoElite->coreFunctions->settings['layout']['enable_footer_sidebar']) && $decoElite->coreFunctions->settings['layout']['enable_footer_sidebar'] == 'yes' ){ ?>
		<div class="de-footer-links">
			<div class="container-fluid">
				<div class="row">
					<?php 
					if ( is_active_sidebar( 'footercontent' ) ) {
						dynamic_sidebar( 'footercontent' );
					}
					?>
				</div>
			</div>
		</div>
		<?php } ?>
		
		<div class="de-footer-disclaimer">
			<div class="de-footer-logo">
				<a href="<?php echo esc_url( home_url('/') ); ?>">
					<?php 
					if( !isset($decoElite->coreFunctions->settings['layout']['footer_logo']) || empty($decoElite->coreFunctions->settings['layout']['footer_logo']) ){
						echo '<img src="' . ( $decoElite->cfg['paths']['theme_dir_url'] ) . 'images/footerlogo.png">';
					}else{
						echo wp_get_attachment_image( $decoElite->coreFunctions->settings['layout']['footer_logo'], 'full' );
					}
					?>
				</a>
			</div>
			
			<?php
				if( isset($decoElite->coreFunctions->settings['layout']['footer_copyright']) && trim($decoElite->coreFunctions->settings['layout']['footer_copyright']) ){
			?>
				<p><?php echo stripslashes( $decoElite->coreFunctions->settings['layout']['footer_copyright'] ); ?></p>
				<?php
				} 
				?>
		</div>
	</div>
	
	<?php wp_footer(); ?>
</body>
</html>