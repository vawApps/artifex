<?php 
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Amazon Affiliate Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *	
**/
! defined( 'ABSPATH' ) and exit;


/**
 * ===============================================
 * Table of Contents
 * ===============================================
 *
 * 1. The class constructor
 * 2. Favicon function
 * 3. Load the css files for the theme
 * 4. Load the javascript files for the theme
 * 5. Extra head html content
 * 
 */
 
if(class_exists('decoEliteCoreFunctions') != true) {
	class decoEliteCoreFunctions extends decoElite 
	{
		private $debug = false;
		public $the_theme = null;
		public $data = array();
		public $settings = array();
		
		// shortcuts 
		public $template_directory = '';
		public $locName = '';
		
		/* 1. The class constructor
		=========================== */
		public function __construct( $the_theme=array() ) 
		{
			$this->the_theme = $the_theme;
			$this->template_directory = $this->the_theme->cfg['paths']['theme_dir_url'];
			
			add_action( 'after_setup_theme', array( $this, 'after_setup_theme' ) );
			add_action( 'after_switch_theme', array( $this, 'after_switch_theme' ), 1 );
			
			// load only for frontend
			if ( !is_admin() ) {
				if( !function_exists('wp_site_icon') ) {   
					add_action( 'wp_head', array( $this, 'favicon' ));
				}
				add_action( 'wp_head', array( $this, 'html_head' ));
				
				add_action( 'wp_enqueue_scripts', array( $this, 'add_styles' ), 10);
				add_action( 'wp_enqueue_scripts', array( $this, 'add_scripts' ));
				
				add_action('wp', array( $this, 'update_page_data' ), 10);
				add_action('wp', array( $this, 'update_settings' ), 10);
				
				add_action( 'wp_footer', array( $this, 'facebook_init' ) );
				
				// Background customizer
				add_theme_support('custom-background');
				
				// This theme styles the visual editor with editor-style.css to match the theme style.
				//add_editor_style(); 
			}
			
			// Add default posts and comments RSS feed links to <head>.
			add_theme_support( 'automatic-feed-links' );
			add_theme_support( "post-thumbnails" );
			add_theme_support( "title-tag" );
			add_theme_support( "custom-header" );
			
			add_filter( 'the_content', array( $this, 'remove_empty_p' ), 20, 1 );
			
			// Declare WooCommerce support
			add_theme_support( 'woocommerce' );
			
			remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);
			remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 20, 0);
			
			add_filter( 'woocommerce_get_price_html', array($this, 'superscride_price_html'), 100, 2 );
			
			add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 9;' ), 20 );
			
			// ajax star rating for amazon products
			add_action('wp_ajax_decoElite_save_stars', array( $this, 'save_stars') );
			add_action('wp_ajax_nopriv_decoElite_save_stars', array( $this, 'save_stars') );
			
			// ajax live search
			add_action('wp_ajax_decoElite_live_search', array( $this, 'live_search') );
			add_action('wp_ajax_nopriv_decoElite_live_search', array( $this, 'live_search') );
			
			// get share count
			add_action('wp_ajax_decoElite_get_share_count', array( $this, 'get_share_count') );
			add_action('wp_ajax_nopriv_decoElite_get_share_count', array( $this, 'get_share_count') );
			
			// 3d panorama
			add_action('wp_ajax_decoElite_3d_panorama', array( $this, 'panorama_3d') );
			add_action('wp_ajax_nopriv_decoElite_3d_panorama', array( $this, 'panorama_3d') );
			
			add_filter( 'the_content', array($this, 'remove_gallery'), 6);
			
			// add theme default gravatar
			add_filter( 'avatar_defaults', array( $this, 'newGravatar' ) );
			
			// Loads the theme's translated strings
			load_theme_textdomain( 'deco-elite', get_template_directory() . '/languages' );
			
			add_action('init', array( $this,'register_sidebars'), 10);
			
			// navigation menu	
			if(function_exists('add_theme_support')){
			    add_theme_support('menus');
			    register_nav_menus(array(
			    	'top_nav' =>'Top Navigation',
			    	'main_nav' => 'Main Navigation'
				));
			}
			
			$this->data['slideshow_buttons'] = array(
				esc_html__('Buy NOW!', 'deco-elite'),
				esc_html__('Get IT!', 'deco-elite'),
				esc_html__('View Details', 'deco-elite'),
				esc_html__('Read more', 'deco-elite'),
				esc_html__('More', 'deco-elite'),
			);
			
			// Include the TGM_Plugin_Activation class
			load_template( $this->the_theme->cfg['paths']['freamwork_dir_path'] . 'class-tgm-plugin-activation.php', true );
			add_action( 'tgmpa_register', array( $this, 'register_required_plugins') );
			
			add_filter( 'wp_head', array( $this, 'wp_title') );
			
			add_filter( 'get_product_search_form' , array( $this, 'woo_custom_product_searchform' ) );
			
			add_action( 'wp_head', array( $this, 'compare_extra_css' ));
			
			if ( ! isset( $content_width ) ) $content_width = 900;
			
			add_filter( 'excerpt_more', array($this, 'new_excerpt_more') );
	    }
		
		public function after_setup_theme(){
			// set size for blog featured image
			add_image_size( 'decoElite-blog-featured-image', 845, 300, true );
			// set size for project list image
			add_image_size( 'decoElite-project-list-image', 286, 203, true );
		}
		
		public function after_switch_theme() {
			global $pagenow;
		 
			if ( ! isset( $_GET['activated'] ) || $pagenow != 'themes.php' ) {
				return;
			}
			
			// Set default theme avatar
			update_option('avatar_default', esc_url(get_template_directory_uri()) . '/images/decoEliteGravatar.png');
			
			// Set theme specific default image sizes for woocommerce
		  	$catalog = array(
				'width' 	=> '187',	// px
				'height'	=> '250',	// px
				'crop'		=> 1 		// false
			);
			$single = array(
				'width' 	=> '398',	// px
				'height'	=> '440',	// px
				'crop'		=> 0 		// false
			);
			$thumbnail = array(
				'width' 	=> '86',	// px
				'height'	=> '86',	// px
				'crop'		=> 1 		// false
			);
			// Image sizes
			update_option( 'shop_catalog_image_size', $catalog ); 		// Product category thumbs
			update_option( 'shop_single_image_size', $single ); 		// Single product image
			update_option( 'shop_thumbnail_image_size', $thumbnail ); 	// Image gallery thumbs
		}
		
		/**
		 * Return the post URL to use as link on link post formats.
		 *
		 * @uses get_url_in_content() to get the URL in the post meta (if it exists) or
		 * the first link found in the post content.
		 *
		 * Falls back to the post permalink if no URL is found in the post.
		 *
		 * @return string The Link format URL.
		 */
		public function deco_get_link_url() {
			$content = get_the_content();
			$check_url = get_url_in_content( $content );
		
			return ( $check_url ) ? $check_url : apply_filters( 'the_permalink', get_permalink() );
		}
		
		public function get_gallery_attachments(){
			global $post;
			
			$post_content = $post->post_content;
			preg_match('/\[gallery.*ids=.(.*).\]/', $post_content, $ids);
			$images_id = count($ids) > 0 ? explode(",", $ids[1]) : null;
			
			return $images_id;
		}
		
		
		public function new_excerpt_more( $more ) {
			return '...';
		}
		
		public function woo_custom_product_searchform( $form ) {
			
			$form = '<form role="search" method="get" id="searchform" action="' . esc_url( home_url('/') ) . '">
				<div>
					<label class="screen-reader-text" for="s">' . esc_html__( 'Search for:', 'woocommerce' ) . '</label>
					<input type="text" value="' . get_search_query() . '" name="s" id="s" placeholder="' . esc_html__( 'Search Product', 'woocommerce' ) . '" />
					<input type="hidden" name="post_type" value="product" />
					<button id="searchsubmit"></button>
				</div>
			</form>';
			
			return $form;
			
		}
		
		public function wp_title() 
		{
		?>
			<title><?php wp_title( '|', true, 'right' ); ?></title>
		<?php
		}
				
		public function update_settings()
		{
			$this->settings['layout'] = maybe_unserialize( get_option( $this->the_theme->alias . '_config', true ) ); 
		}
		
		public function data_debug()
		{ 
			if( $this->debug == true ){
			?> 
				<script>console.log( '<?php echo json_encode($this->data);?>' )</script>
			<?php
			}	
		}
		
		public function update_page_data()
		{
			$page_object = get_queried_object();
			$page_id     = get_queried_object_id();
			 
			if( $page_object && $page_id == 0 && $page_object->query_var == 'product' && isset($page_object->query_var) ){
				if( function_exists('woocommerce_get_page_id') ) $page_id = woocommerce_get_page_id('shop');
			}
			if( (int) $page_id > 0 ){
				
				// get the sidebar position and id
				$this->data['sidebar'] = array(
					'position' => get_post_meta( $page_id, '_page_sidebar_position', true ),
					'sidebars' => get_post_meta( $page_id, '_page_sidebar_ids', true ),
				);
				
				$this->data['layout'] = get_post_meta( $page_id, '_layout', true );
			} 
			
			// get all sidebars
			$sidebars_list = get_option( 'decoElite_dynamic_sidebars', true ); 
			if( $sidebars_list && count($sidebars_list) > 0 && $sidebars_list !== true ){
				foreach ($sidebars_list as $sidebar ) {
					$this->data['sidebar'][sanitize_title($sidebar['title'])] = get_option( 'decoElite_ds_' . md5(sanitize_title($sidebar['title'])), true );
				}
			} 
		}
		
		public function printSidebar( $pos='none', $_size="" )
		{ 
			if( isset($this->data['page_sidebars']) && $this->data['page_sidebars'] != '' && count($this->data['page_sidebars']) > 0 ){
				foreach ($this->data['page_sidebars'] as $sidebar_key => $sidebar_value) {
					if( $sidebar_value['settings']['position'] == $pos && !isset($this->data['sidebar']['printed']) ){
						$this->data['sidebar']['printed'] = true;
						
						$size = 'col-lg-3 col-md-3 col-sm-12 col-xs-12';
						if( $_size != "" ) $size = $_size;
		?>
					<div class="de_shop_sidebar <?php echo $sidebar_value['settings']['position']; ?>">
						<?php dynamic_sidebar( $sidebar_key ); ?>
					</div>
		<?php
					}
				}
			}
		}
		
		public function content_width()
		{
			$class = 'style="width:100%;"';
			if( isset($this->data['page_sidebars']) && count($this->data['page_sidebars']) > 0 ){
				$class = '';
			}
			
			return $class;
		}
		
		public function content_class( $_size="" )
		{
			$class = 'col-lg-12 col-md-9 col-sm-12 col-xs-12';
			if( isset($this->data['page_sidebars']) && count($this->data['page_sidebars']) > 0 ){
		
				$class = 'col-lg-9 col-md-8 col-sm-12 col-xs-12';
				if( $_size != "" ) $class = $_size;
			}
			
			return $class;
		}

		public function register_sidebars()
		{
			if ( function_exists('register_sidebar') ) {
				$getSettings = maybe_unserialize( get_option( $this->the_theme->alias . '_config', true ) );
				// default sidebar
				
				if( isset( $getSettings["footer_cols"] ) ){
					if( (int)$getSettings["footer_cols"] == 1 ) {
						$cols = '<div class="col-lg-12 col-md-12 col-sm-3 col-xs-12 de-footer-box decoElite-widget">';
					} elseif( (int)$getSettings["footer_cols"] == 2 ) {
						$cols = '<div class="col-lg-6 col-md-6 col-sm-3 col-xs-12 de-footer-box decoElite-widget">';
					} elseif( (int)$getSettings["footer_cols"] == 3 ) {
						$cols = '<div class="col-lg-4 col-md-4 col-sm-3 col-xs-12 de-footer-box decoElite-widget">';
					} elseif( (int)$getSettings["footer_cols"] == 4 ) {
						$cols = '<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 de-footer-box decoElite-widget">';
					}
					 
				} else {
					$cols = '<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 decoElite-widget">';
				}
				
				// custom sidebars (base on admin.php?page=decoElite#!/sidebars)
				$sidebars_meta =  get_option( 'decoElite_dynamic_sidebars' );
				if( $sidebars_meta !== false && count($sidebars_meta) > 0 && isset($sidebars_meta) && is_array($sidebars_meta) ){
					$sidebars_meta = $sidebars_meta;
					foreach ($sidebars_meta as $key => $value) {
						register_sidebar(array(
							'name' => $value['title'],
							'id' => sanitize_title($value['title']),
							'before_widget' => '<div id="%1$s" class="decoElite-widget %2$s">',
							'after_widget' => '</div>',
							'before_title' => '<h3>',
							'after_title' => '</h3>'
						));  
					}
				}
				
				register_sidebar(array(
					'name' => 'Footer Content',
					'id' => 'footercontent',
					'description'   => '',
				    'class'         => '',
					'before_widget' => $cols,
					'after_widget'  => '</div>',
					'before_title'  => '<h3>',
					'after_title'   => '</h3>'
				));
			}
		}

		public function limit_posts_per_archive_page() {
			if ( is_search() )
				set_query_var('posts_per_archive_page', 30); // or use variable key: posts_per_page
		}
		
		/* 2. Favicon function
		====================== */
		public function favicon()
		{ 
			if(isset($this->settings['layout']['favicon']) && !empty($this->settings['layout']['favicon'])){
				$image = wp_get_attachment_image_src( (int)$this->settings['layout']['favicon'], 'thumbnail' ); 
				$favicon = '<link rel="shortcut icon" href="' . esc_url($image[0]) . '"/>';
			} else {
				$favicon = '<link rel="shortcut icon" href="'. ( esc_url($this->template_directory) ) .'favicon.ico" />';
			}
			echo $favicon;
		}
		
		/* 3. Load the css files for the theme
		====================================== */
		public function add_styles()
		{
			global $decoElite;
			$protocol = is_ssl() ? 'https' : 'http';
			
			wp_enqueue_style( $this->the_theme->alias . '-bootstrapcss', $this->template_directory . 'css/bootstrap.css', array(), '3.1.0' );
			wp_enqueue_style( $this->the_theme->alias . '-bootstrap-theme', $this->template_directory . 'css/bootstrap-theme.css', array(), '1.0' );
			wp_enqueue_style( $this->the_theme->alias . '-font-awesome', $this->template_directory . 'css/font-awesome.min.css', array(), '4.4.0' );
			wp_enqueue_style( $this->the_theme->alias . '-MoonIcons', $this->template_directory . 'css/moon-icons.css', array(), '1.0' );
			
			// Fonts
			if( isset($decoElite->coreFunctions->settings['layout']["main_font"]) ){
				wp_enqueue_style( $this->the_theme->alias .'-'. preg_replace('/\s+/', '-', $decoElite->coreFunctions->settings['layout']["main_font"]), $protocol . '://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700' );
			}
			
			if( isset($decoElite->coreFunctions->settings['layout']["top_menu_font_family"]) ){
				wp_enqueue_style( $this->the_theme->alias .'-'. preg_replace('/\s+/', '-', $decoElite->coreFunctions->settings['layout']["top_menu_font_family"]), $protocol . '://fonts.googleapis.com/css?family='.$decoElite->coreFunctions->settings['layout']["top_menu_font_family"].':400,700' );	
			}
			if( isset($decoElite->coreFunctions->settings['layout']["main_menu_font_family"]) ){
				wp_enqueue_style( $this->the_theme->alias .'-'. preg_replace('/\s+/', '-', $decoElite->coreFunctions->settings['layout']["main_menu_font_family"]), $protocol . '://fonts.googleapis.com/css?family='.$decoElite->coreFunctions->settings['layout']["main_menu_font_family"].':400,700' );	
			}
			
			if( isset($decoElite->coreFunctions->settings['layout']["intro_font"]) ){
				wp_enqueue_style( $this->the_theme->alias .'-'. preg_replace('/\s+/', '-', $decoElite->coreFunctions->settings['layout']["intro_font"]), $protocol . '://fonts.googleapis.com/css?family=Playfair+Display:700,700italic' );
			}
			
			$style_url = $this->template_directory . 'load-style.php';
			  
			if( is_file( $this->template_directory . 'load-style.css' ) ){  
				$style_url = str_replace(".php", '.css', $style_url);
			}
			wp_enqueue_style( $this->the_theme->alias . '-main-style', $style_url, array( $this->the_theme->alias . '-bootstrapcss' ), '1.0' );
			//wp_enqueue_style( $this->the_theme->alias . '-main-style', $this->template_directory . 'load-style.php', array( $this->the_theme->alias . '-bootstrapcss' ), '1.0' );
			
			// Isotope
			wp_enqueue_style( $this->the_theme->alias . '-isotope', $this->template_directory . 'css/isotope.css', array(), '1.0' );
			
			wp_enqueue_style( $this->the_theme->alias . '-carousel', $this->template_directory . 'owl-carousel/owl.carousel.css', array(), '1.2' );
			//wp_enqueue_style( $this->the_theme->alias . '-carousel-theme', $this->template_directory . 'owl-carousel/owl.theme.css', array(), '1.2' );
			
			wp_enqueue_style( $this->the_theme->alias . '-prettyPhoto', $this->template_directory . 'css/prettyPhoto.css', array(), '1.0' );			
			
			//wp_enqueue_style( $this->the_theme->alias . '-compare', $this->template_directory . 'css/compare.css' );
			
			//wp_enqueue_style( $this->the_theme->alias . '-responsive', $this->template_directory . 'css/responsive.css' );

			// DISABLE WOOCOMMERCE PRETTY PHOTO STYLE
			wp_deregister_style( 'woocommerce_prettyPhoto_css' );
		}
		
		/* 4. Load the javascript files for the theme
		============================================= */
		public function add_scripts()
		{
			if(is_singular() && comments_open() && get_option('thread_comments')) wp_enqueue_script('comment-reply');
			
			//wp_enqueue_script( $this->the_theme->alias . '-jquery', $this->template_directory . 'js/jquery-1.11.0.min.js', array(), '1.10.1', true);
			wp_enqueue_script( $this->the_theme->alias . '-jquery-ui', $this->template_directory . 'js/jquery-ui.js', array(), '1.10.4', true);
			
			wp_enqueue_script( $this->the_theme->alias . '-bootstrapjs', $this->template_directory . 'js/bootstrap.js', array('jquery'), '3.0.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-owl-carousel', $this->template_directory . 'owl-carousel/owl.carousel.js', array('jquery'), '1.2', true);
			wp_enqueue_script( $this->the_theme->alias . '-bootstrap-rating', $this->template_directory . 'js/bootstrap-rating-input.min.js', array('jquery'), '1.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-pretty-photo', $this->template_directory . 'js/jquery.prettyPhoto.min.js', array('jquery'), '3.1.6', true);
			wp_enqueue_script( $this->the_theme->alias . '-ddaccordion', $this->template_directory . 'js/ddaccordion.js', array('jquery'), '1.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-responsive-nav', $this->template_directory . 'js/responsive-nav.js', array('jquery'), '1.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-responsive-nav', $this->template_directory . 'js/responsive-nav.min.js', array('jquery'), '1.0', true);
			//wp_enqueue_script( $this->the_theme->alias . '-jquery-gmap', $this->template_directory . 'js/jquery.gmap.min.js', array('jquery', $this->the_theme->alias . '-google-maps'), '1.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-modernizr', $this->template_directory . 'js/modernizr.custom.js', array('jquery' ), '1.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-classie', $this->template_directory . 'js/classie.js', array('jquery' ), '1.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-isotope', $this->template_directory . 'js/isotope.pkgd.min.js', array('jquery'), '1.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-fullscreen', $this->template_directory . 'js/jquery.fullscreen-0.4.1.min.js', array('jquery'), '1.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-jquery-mousewheel', $this->template_directory . 'js/jquery.mousewheel.min.js', array('jquery'), '3.1.13', true);
			wp_enqueue_script( $this->the_theme->alias . '-scrollpanel', $this->template_directory . 'js/jquery.scrollpanel-0.5.0.min.js', array('jquery', $this->the_theme->alias.'-jquery-mousewheel'), '0.5.0', true);
			wp_enqueue_script( $this->the_theme->alias . '-main', $this->template_directory . 'js/main.js', array('jquery'), '1.0', true);
			//wp_enqueue_script( $this->the_theme->alias . '-gmap', $this->template_directory . 'js/gmaps.js', array('jquery'), '1.0', true);
			
			if( is_page_template( 'template-contact.php') ) {   
				wp_enqueue_script( $this->the_theme->alias . '-google-maps', 'http://maps.google.com/maps/api/js?sensor=false', array('jquery', $this->the_theme->alias . '-main'), '2.0', true);
			}
		}
		
		/* 5. Extra head html content
		============================= */
		public function html_head()
		{
			global $decoElite;
			?>
			<meta name="viewport" content="initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0, width=device-width" />
			<script type="text/javascript">
				var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
			</script>
			
			<!--[if lt IE 9]>
				<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<![endif]-->
			<?php
		}
		
		public function display_breadcrumbs()
	    {
	        $text['home']     = 'Home'; // text for the 'Home' link
			$text['category'] = 'Archive by Category "%s"'; // text for a category page
			$text['tax'] 	  = 'Archive for "%s"'; // text for a taxonomy page
			$text['search']   = 'Search Results for "%s" Query'; // text for a search results page
			$text['tag']      = 'Posts Tagged "%s"'; // text for a tag page
			$text['author']   = 'Articles Posted by %s'; // text for an author page
			$text['404']      = 'Error 404'; // text for the 404 page
		
			$showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
			$before      = '<li class="current">'; // tag before the current crumb
			$after       = '</li>'; // tag after the current crumb
			$linkAttr = '';
			$delimiter = '';
			$cats = '';
			/* === END OF OPTIONS === */
		
			global $post;
			$homeLink = esc_url( home_url('/') );
			$linkBefore = '<li>';
			$linkAfter = '</li>';
			$link = $linkBefore . '<a' . $linkAttr . ' href="%1$s">%2$s</a>' . $linkAfter;
		
			echo '<ul id="crumbs" class="breadcrumb">' . sprintf($link, $homeLink, esc_attr($text['home'])) . $delimiter;
			
			if ( is_category() ) {
				$thisCat = get_category(get_query_var('cat'), false);
				if ($thisCat->parent != 0) {
					$cats = get_category_parents($thisCat->parent, TRUE, $delimiter);
					$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
					$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
					echo $cats;
				}
				echo $before . sprintf(esc_attr($text['category']), single_cat_title('', false)) . $after;
	
			} elseif ( function_exists('is_product') && is_product() ) { 
				$terms = get_the_terms( $post->ID, 'product_cat' );
				if( $terms && count($terms) > 0 ){
					foreach ($terms as $term) {
					    $product_cat_id = $term->term_id;
						$product_cat_slug = $term->slug;
						$product_cat_name = esc_attr($term->name);
						
						$cats .= '<li><a href="'. esc_url(get_site_url() . '/product-category/' . $product_cat_slug) .'">'.$product_cat_name.'</a></li>';	
						$cats .= '<li><a href="'. esc_url(get_permalink()) .'">'. esc_attr($post->post_title) .'</a></li>';			
						echo $cats;
						break;
					}
				}
			} elseif( is_tax() ){
				$thisCat = get_category(get_query_var('cat'), false);
				if ($thisCat->parent != 0) {
					$cats = get_category_parents($thisCat->parent, TRUE, $delimiter);
					$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
					$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
					echo $cats;
				}
				echo $before . sprintf(esc_attr($text['tax']), single_cat_title('', false)) . $after;
			
			} elseif ( is_search() ) {
				echo $before . sprintf(esc_attr($text['search']), get_search_query()) . $after;
	
			} elseif ( is_day() ) {
				echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
				echo sprintf($link, get_month_link(get_the_time('Y'),get_the_time('m')), get_the_time('F')) . $delimiter;
				echo $before . get_the_time('d') . $after;
	
			} elseif ( is_month() ) {
				echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
				echo $before . get_the_time('F') . $after;
	
			} elseif ( is_year() ) {
				echo $before . get_the_time('Y') . $after;
	
			} elseif ( is_single() && !is_attachment() ) {
				if ( get_post_type() != 'post' ) {
					$post_type = get_post_type_object(get_post_type());
					$slug = $post_type->rewrite;
					printf($link, $homeLink . '/' . $slug['slug'] . '/', $post_type->labels->singular_name);
					if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;
				} else {
					$cat = get_the_category(); $cat = $cat[0];
					$cats = get_category_parents($cat, TRUE, $delimiter);
					if ($showCurrent == 0) $cats = preg_replace("#^(.+)$delimiter$#", "$1", $cats);
					$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
					$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
					echo $cats;
					if ($showCurrent == 1) echo $before . get_the_title() . $after;
				}
	
			} elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
				$post_type = get_post_type_object(get_post_type());
				echo $before . esc_attr($post_type->labels->singular_name) . $after;
	
			} elseif ( is_attachment() ) {
				$parent = get_post($post->post_parent);
				$cat = get_the_category($parent->ID); $cat = $cat[0];
				$cats = get_category_parents($cat, TRUE, $delimiter);
				$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
				$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
				echo $cats;
				printf($link, get_permalink($parent), $parent->post_title);
				if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;
	
			} elseif ( is_page() && !$post->post_parent ) {
				if ($showCurrent == 1) echo $before . get_the_title() . $after;
	
			} elseif ( is_page() && $post->post_parent ) {
				$parent_id  = $post->post_parent;
				$breadcrumbs = array();
				while ($parent_id) {
					$page = get_page($parent_id);
					$breadcrumbs[] = sprintf($link, get_permalink($page->ID), get_the_title($page->ID));
					$parent_id  = $page->post_parent;
				}
				$breadcrumbs = array_reverse($breadcrumbs);
				for ($i = 0; $i < count($breadcrumbs); $i++) {
					echo $breadcrumbs[$i];
					if ($i != count($breadcrumbs)-1) echo $delimiter;
				}
				if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;
	
			} elseif ( is_tag() ) {
				echo $before . sprintf(esc_attr($text['tag']), single_tag_title('', false)) . $after;
	
			} elseif ( is_author() ) {
		 		global $author;
				$userdata = get_userdata($author);
				echo $before . sprintf(esc_attr($text['author']), $userdata->display_name) . $after;
	
			} elseif ( is_404() ) {
				echo $before . esc_attr($text['404']) . $after;
			}
	
			echo '</ul>';
	    }

		/**
		* Get first paragraph from a WordPress post. Use inside the Loop.
		*
		* @return string
		*/
		function get_first_paragraph()
		{
			global $post;
			$str = wpautop( preg_replace("~(?:\[/?)[^/\]]+/?\]~s", '', get_the_content() ) );
			$str = substr( $str, 0, strpos( $str, '</p>' ) + 4 );
			$str = strip_tags($str);
			 
			return '<p>' . implode(' ', array_slice(explode(' ', $str), 0, 30)) . '</p>';
		}

		public function remove_gallery($content)
		{
			if( function_exists('is_product') && is_product() ){	
		    	return str_replace('[gallery]', '', $content);
			}
			return $content;
		}
		
		public function save_stars()
		{
			$_product_rating = (int)get_post_meta( $post->ID, '_product_rating', true );
			$_product_votes = (int)get_post_meta( $post->ID, '_product_votes', true );
			
			update_post_meta( (int)$_REQUEST['productid'], '_product_rating', $_product_rating + (int)$_REQUEST['value'] );
			update_post_meta( (int)$_REQUEST['productid'], '_product_votes', $_product_votes + 1 );
			die(json_encode(array(
				'status' => 'valid'
			)));
		}
		
		public function live_search()
		{
			global $wpdb;
			
			// WP_Query arguments
			$args = array (
				'post_type'              => array('product', 'post', 'page', 'projects'),
				'post_status'            => 'publish',
				'posts_per_page'         => 20,
				's'                      => $wpdb->prepare('%s', $_REQUEST['query']),
				'order'                  => 'ASC',
				'orderby'                => 'title',
			);
			
			// The Query
			$query = new WP_Query( $args );
			
			// The Loop
			if ( $query->have_posts() ) {
				while ( $query->have_posts() ) {
					$query->the_post();
					echo '<li class="result">';
						echo '<a href="'. esc_url(get_permalink()) .'">';
							echo '<span>[ ' . get_post_type( get_the_ID() ) . ' ]</span>';
							echo get_the_title();
						echo '</a>';
					echo '</li>';
				}
			} else {
				// no posts found
			}
			
			// Restore original Post Data
			wp_reset_postdata();
			die();
		}
		
		public function superscride_price_html( $price, $product )
		{
			$post_id = isset($product->id) ? $product->id : 0;
			if ( $post_id <=0 ) return $price;
			
			return preg_replace('/\.([0-9]*)/', '<sup>.$1</sup>', $price);
		}
		
		public function print_slideshow_button( $key=0 )
		{
			return isset($this->data['slideshow_buttons'][$key]) ? $this->data['slideshow_buttons'][$key] : ''; 
		}

		public function remove_empty_p($content)
		{
		    $content = force_balance_tags($content);
		    return preg_replace('#<p>\s*+(<br\s*/*>)?\s*</p>#i', '', $content);
		}
		
		public function comment_template($comment, $args, $depth)
		{
		?>
			<li class="de_comments type-<?php echo get_comment_type(); ?>" id="comment-<?php comment_id(); ?>">
				<?php if( in_array( get_comment_type(), array('pingback', 'trackback') ) ) { ?>
					
					<div class="de_comment_author">
						<div class="de_comment_name">
							<span><?php echo comment_type(); ?>: <a href="<?php echo comment_author_url(); ?>" target="_blank"><strong><?php comment_author();?></strong></a> - <?php edit_comment_link( esc_html__( 'Edit', 'deco-elite' ) ); ?></span>
						</div>
					</div>
				
				<?php }else{ ?>
				
					<div class="de_comment_author">
						<div class="de_comment_image">
							<?php echo get_avatar( $comment, 50 );?>
						</div>
						
						<div class="de_comment_name">
							<span><strong><?php comment_author();?></strong> - <?php comment_date();?></span>
							<div class="clearfix"></div>
							<div class="de_comment_reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => esc_html__('Reply', 'deco-elite')))) ?></div>
							<div class="de_comment_edit"><?php edit_comment_link( esc_html__( 'Edit', 'deco-elite' ) ); ?></div>
						</div>
					</div>
					
					<div class="de_comment_container">
						<?php comment_text(); ?>
					</div>
					
				<?php } ?>
			</li>
		<?php
		}
		
		public function print_share_buttons( $post_id, $post_title='', $post_excerpt='', $show_count = false )
		{
			$post_url = get_permalink( $post_id );
			$image_url = wp_get_attachment_url( get_post_thumbnail_id( $post_id ) );
		?>
			<a href="<?php echo esc_url('https://twitter.com/share?url='.$post_url.'&text='.(preg_replace('/\s+/', '+', $post_title))); ?>" target="_blank" class="tw-share"><i class="fa fa-twitter"></i> <?php echo $show_count ? '<span>0</span>' : ''; ?></a>
			<a href="<?php echo esc_url('http://www.facebook.com/sharer.php?u='.$post_url); ?>" target="_blank" class="fb-share"><i class="fa fa-facebook"></i> <?php echo $show_count ? '<span>0</span>' : ''; ?></a>
			<a href="<?php echo esc_url('https://pinterest.com/pin/create/bookmarklet/?url='.$post_url.'&description='.(preg_replace('/\s+/', '+', $post_title)).'&media='.$image_url); ?>" target="_blank" class="pin-share"><i class="fa fa-pinterest"></i> <?php echo $show_count ? '<span>0</span>' : ''; ?></a>
			<a href="<?php echo esc_url('https://plus.google.com/share?url='.$post_url);?>" target="_blank" class="g-share"><i class="fa fa-google-plus"></i> <?php echo $show_count ? '<span>0</span>' : ''; ?></a>
			
		<?php if( $show_count ) { ?>
			<script type="text/javascript">
				jQuery.post('<?php echo admin_url('admin-ajax.php'); ?>', {
					'action' : 'decoElite_get_share_count',
					'post_url' : '<?php echo $post_url; ?>'
				}, function(resp) { 
					if( resp.tw || resp.fb || resp.pinterest || resp.gplus ) {
						$('a.tw-share span').html( resp.tw );
						$('a.fb-share span').html( resp.fb );
						$('a.pin-share span').html( resp.pinterest );
						$('a.g-share span').html( resp.gplus );
					}
				}, 'json');
			</script>
		<?php }
		}

		public function get_shares_count_all()
		{
			return "Test";
		}
		
		public function shorten_string($str, $limit=100, $strip = false)
		{
		    $str = ($strip == true)?strip_tags($str):$str;
		    if (strlen ($str) > $limit) {
		        $str = substr ($str, 0, $limit - 3);
		        return (substr ($str, 0, strrpos ($str, ' ')).'...');
		    }
		    return trim($str);
		}
		
		public function register_required_plugins() 
		{
			/**
			 * Array of plugin arrays. Required keys are name and slug.
			 * If the source is NOT from the .org repo, then source is also required.
			 */
			$plugins = array(
				array(
					'name'     				=> 'decoElite - Core Functionality',
					'slug'     				=> 'decoElite-core-functionality',
					'source'   				=> get_stylesheet_directory() . '/plugins/decoElite-core-functionality.zip',
					'required' 				=> true,
					'version' 				=> '1.0', 
					'force_activation' 		=> false,
					'force_deactivation' 	=> false,
					'external_url' 			=> '', 
				),
				
				array(
					'name'     				=> 'decoElite - Shortcodes plugin',
					'slug'     				=> 'decoElite-shortcodes',
					'source'   				=> get_stylesheet_directory() . '/plugins/decoElite-shortcodes.zip',
					'required' 				=> true,
					'version' 				=> '1.0', 
					'force_activation' 		=> false,
					'force_deactivation' 	=> false,
					'external_url' 			=> '', 
				),
				
				array(
					'name'     				=> 'AA Backup Manager for Deco Elite',
					'slug'     				=> 'aa-backup-manager',
					'source'   				=> get_stylesheet_directory() . '/plugins/aa-backup-manager.zip',
					'required' 				=> false,
					'version' 				=> '1.0', 
					'force_activation' 		=> false,
					'force_deactivation' 	=> false,
					'external_url' 			=> '', 
				),
				
				array(
					'name'     				=> 'Mega Menu',
					'slug'     				=> 'mega-menu',
					'source'   				=> get_stylesheet_directory() . '/plugins/mega-menu.zip',
					'required' 				=> false,
					'version' 				=> '1.0', 
					'force_activation' 		=> false,
					'force_deactivation' 	=> false,
					'external_url' 			=> '', 
				),
				
				array(
					'name'     				=> 'Revolution Slider Plugin',
					'slug'     				=> 'revslider',
					'source'   				=> get_stylesheet_directory() . '/plugins/revslider.zip',
					'required' 				=> true,
					'version' 				=> '1.0', 
					'force_activation' 		=> false,
					'force_deactivation' 	=> false,
					'external_url' 			=> '', 
				),
				
		        array(
		            'name'      => 'Woocommerce',
		            'slug'      => 'woocommerce',
		            'required'  => false,
		            'force_activation' 	=> false
		        ),
		        
				array(
		            'name'      => 'YITH WooCommerce Wishlist',
		            'slug'      => 'yith-woocommerce-wishlist',
		            'required'  => false,
		            'force_activation' 	=> false
		        ),
		        
				array(
		            'name'      => 'YITH WooCommerce Compare',
		            'slug'      => 'yith-woocommerce-compare',
		            'required'  => false,
		            'force_activation' 	=> false
		        ),
		        
				array(
		            'name'      => 'Contact Form 7',
		            'slug'      => 'contact-form-7',
		            'required'  => false,
		            'force_activation' 	=> false
		        ),
		        
				array(
		            'name'      => 'Recent Posts Widget Extended',
		            'slug'      => 'recent-posts-widget-extended',
		            'required'  => false,
		            'force_activation' 	=> false
		        ),
		        
				array(
					'name'     				=> 'WooZone - WooCommerce Amazon Affiliates',
					'slug'     				=> 'woozone',
					'source'   				=> get_stylesheet_directory() . '/plugins/woozone.zip',
					'required' 				=> false,
					'version' 				=> '8.1.3', 
					'force_activation' 		=> false,
					'force_deactivation' 	=> false,
					'external_url' 			=> '', 
				),
				
				array(
					'name'     				=> 'Premium SEO pack - Wordpress Plugin',
					'slug'     				=> 'premium-seo-pack',
					'source'   				=> get_stylesheet_directory() . '/plugins/premium-seo-pack.zip',
					'required' 				=> false,
					'version' 				=> '1.9.1', 
					'force_activation' 		=> false,
					'force_deactivation' 	=> false,
					'external_url' 			=> '', 
				),
				
			);
		
			// Change this to your theme text domain, used for internationalising strings
			$theme_text_domain = 'tgmpa';
		
			/**
			 * Array of configuration settings. Amend each line as needed.
			 * If you want the default strings to be available under your own theme domain,
			 * leave the strings uncommented.
			 * Some of the strings are added into a sprintf, so see the comments at the
			 * end of each line for what each argument will be.
			 */
			$config = array(
				'domain'       		=> 'decoElite',         	// Text domain - likely want to be the same as your theme.
				'default_path' 		=> '',                         	// Default absolute path to pre-packaged plugins
				'menu'         		=> 'install-required-plugins', 	// Menu slug
				'has_notices'      	=> true,                       	// Show admin notices or not
				'is_automatic'    	=> false,					   	// Automatically activate plugins after installation or not
				'message' 			=> '',							// Message to output right before the plugins table
				'strings'      		=> array(
					'nag_type' => 'updated' // Determines admin notice type - can only be 'updated' or 'error'
				)
			);
		
			tgmpa( $plugins, $config );
		}

		public function adjustBrightness($hex, $steps) 
		{
		    // Steps should be between -255 and 255. Negative = darker, positive = lighter
		    $steps = max(-255, min(255, $steps));
		
		    // Format the hex color string
		    $hex = str_replace('#', '', $hex);
		    if (strlen($hex) == 3) {
		        $hex = str_repeat(substr($hex,0,1), 2).str_repeat(substr($hex,1,1), 2).str_repeat(substr($hex,2,1), 2);
		    }
		
		    // Get decimal values
		    $r = hexdec(substr($hex,0,2));
		    $g = hexdec(substr($hex,2,2));
		    $b = hexdec(substr($hex,4,2));
		
		    // Adjust number of steps and keep it inside 0 to 255
		    $r = max(0,min(255,$r + $steps));
		    $g = max(0,min(255,$g + $steps));  
		    $b = max(0,min(255,$b + $steps));
		
		    $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
		    $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
		    $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
		
		    return '#'.$r_hex.$g_hex.$b_hex;
		}
		
		public function getAllGfonts( $what='all' ) 
		{   
			$fonts = json_decode(  
			$this->the_theme->wp_filesystem->get_contents( $this->the_theme->cfg['paths']['theme_dir_path'] . '/fonts/google-webfonts.json' ), true);
			
			$ret_fonts = array();
			if(count($fonts['items']) > 0 ){ 
				foreach ( $fonts['items'] as $font ) {
					$ret_fonts[$font['family']] = $font['family'];
				}
			}
			
			if( $what == 'all' ){
				return $ret_fonts;
			}
			
		}
		
		public function the_content_filter($content) 
		{
			global $shortcode_tags;
			
			/*foreach( array_keys($shortcode_tags) as $tags => $value ) {
				if(preg_match("/decoElite/i", $value)) {
					
					echo ", '" . $value . "'";
				}
			}
			echo __FILE__ . ":" . __LINE__;die . PHP_EOL;   
			*/
			
			$block = join("|", array( 'decoElite_button', 'decoElite_list_type', 'decoElite_column', 'decoElite_subcolumn', 'decoElite_row', 'decoElite_subrow', 'decoElite_box', 'decoElite_vertical_space', 'decoElite_box_headline', 'decoElite_code', 'decoElite_google_maps', 'decoElite_blog_slideshow', 'decoElite_our_process', 'decoElite_designer_box', 'decoElite_designer_box2', 'decoElite_project_list', 'decoElite_project_box', 'decoElite_services', 'decoElite_promotions', 'decoElite_contact_address', 'decoElite_contact_phone', 'decoElite_contact_email', 'decoElite_contact_schedule', 'decoElite_services_slider_box', 'decoElite_services_slide', 'decoElite_icon_box', 'decoElite_de_other_services', 'decoElite_de_tabs', 'decoElite_de_testimonial', 'decoElite_de_testimonials', 'decoElite_de_accordion', 'decoElite_de_accordion_elm', 'decoElite_de_clear', 'decoElite_interior_our_process', 'decoElite_interior_startfrom_box', 'decoElite_interior_step1', 'decoElite_interior_step4', 'decoElite_interior_step2', 'decoElite_interior_step3' ) );
			
			
			// opening tag
			$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
			
			// closing tag
			$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
			return $rep;
		}

		public function newGravatar($avatar_defaults) {
			$myavatar = esc_url(get_template_directory_uri()) . '/images/decoEliteGravatar.png';
			$avatar_defaults[$myavatar] = "Deco Elite";
		    return $avatar_defaults;
		}
		
		public function compare_extra_css()
		{
			if( isset($_REQUEST['action']) && $_REQUEST['action'] == 'yith-woocompare-view-table' )
				echo '<link rel="stylesheet" href="' . ( esc_url( $this->template_directory . 'css/compare.css' ) ) . '" type="text/css" />';
		}
		
		public function add_panorama_scripts()
		{
			wp_enqueue_script( $this->the_theme->alias . '-three', $this->template_directory . 'js/three.min.js', array(), '1.0');
			wp_enqueue_script( $this->the_theme->alias . '-three-init', $this->template_directory . 'js/three.init.js', array(), '1.0', true);
		}
		
		public function panorama_3d()
		{
			$image_full = wp_get_attachment_image_src( (int)$_REQUEST['id'], 'full' );
			$image_full = isset($image_full[0]) ? $image_full[0] : '';
			
			add_action( 'wp_enqueue_scripts', array( $this, 'add_panorama_scripts' ));
			?>
			
			<!DOCTYPE html>
			<html lang="en">
			    <head>
			        <meta charset="utf-8">
			        <meta name="viewport" content="width=device-width, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
			        <style>
			            body {
			                background-color: #000000;
			                margin: 0px;
			                overflow: hidden;
			            }
			        </style>
			        
			        <?php wp_head(); ?>
			    </head>
			    <body>
			        <div id="container" data-img="<?php echo $image_full;?>"></div>
			    
			   	 <?php wp_footer(); ?>
			    </body>
			</html>
			<?php
			die; 
		}

		public function get_share_count() 
		{
			$post_url = isset($_REQUEST['post_url']) && trim($_REQUEST['post_url']) != '' ? $_REQUEST['post_url'] : false;
			//$post_url = 'http://mashable.com/2015/10/07/gwendoline-christie-fashion-week/?utm_cid=mash-com-fb-main-link#xK5_rnU_pmq1';
			
			if( $post_url ) {
				$tw_get = wp_remote_get('http://urls.api.twitter.com/1/urls/count.json?url=' . $post_url);
				$tw_count = json_decode($tw_get['body']);
				
				$fb_get = wp_remote_get('http://graph.facebook.com/?id=' . $post_url);  
				$fb_count = json_decode($fb_get['body']);
				
				//$pin_get = wp_remote_get('http://api.pinterest.com/v1/urls/count.json?callback=&url=' . $post_url);
				$pin_get = wp_remote_get('http://api.pinterest.com/v1/urls/count.json?url=' . $post_url);
				$pin_count = json_decode( preg_replace('/^receiveCount\((.*)\)$/', "\\1", $pin_get['body']) );
				
				$g_get = wp_remote_get('http://www.linkedin.com/countserv/count/share?url='. ($post_url) .'&format=json');
				$g_count = json_decode($g_get['body']);
				
				$resp = array(
					'tw' => $tw_count->count,
					'fb' => $fb_count->shares,
					'pinterest' => $pin_count->count,
					'gplus' => $g_count->count
				);
			}else{
				$resp = array();
			}
			
			return die(json_encode($resp));
		}

		public function facebook_init()
		{
		?>
			<div id="fb-root"></div>
			<script>(function(d, s, id) {
			  var js, fjs = d.getElementsByTagName(s)[0];
			  if (d.getElementById(id)) return;
			  js = d.createElement(s); js.id = id;
			  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=<?php echo (int)$this->settings['layout']['fb_app_id']; ?>";
			  fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));</script>
		<?php
		}
	}
}
