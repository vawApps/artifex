/*
Document   :  Asset Download
Author     :  Andrei Dinca, AA-Team http://codecanyon.net/user/AA-Team
*/

// Initialization and events code for the app
decoEliteImagesHotpoints = (function($) {
	"use strict";

	// public
	var debug_level 		= 0,
		loading 			= $('<div id="wwcAmzAff-ajaxLoadingBox" class="wwcAmzAff-panel-widget">loading</div>'), // append loading
		_editor 			= null,
		hotpoints_ids 		= new Array(),
		hotpoints_products 	= null,
		hotpoints_add_new 	= null,
		curr_gallery_item	= null,
		hotpoints_colors	= new Array(),
		cc					= 0,
		upload_popup_parent	= null;
	
	// init function, autoload
	(function init() {
		// load the triggers
		$(document).ready(function() {
			triggers();
		});
		
		hotpoint_colors();
		hotpoints_colors = shuffle( hotpoints_colors ); 
	})();
	
	function shuffle( array )
	{
	    var counter = array.length, temp, index;
	
	    // While there are elements in the array
	    while (counter > 0) {
	        // Pick a random index
	        index = Math.floor(Math.random() * counter);
	
	        // Decrease counter by 1
	        counter--;
	
	        // And swap the last element with it
	        temp = array[counter];
	        array[counter] = array[index];
	        array[index] = temp;
	    }
	
	    return array;
	}

	function create_interface( elm )
	{
		ajaxLoading( 'show' );
		
		$("#decoEliteLighboxContent").html('');
		hotpoints_ids = new Array();
		var attach_id = elm.find('input[type=hidden]').val();
		$.post(ajaxurl, {
			'action': 'decoEliteImagesHotpoints',
			'subaction': 'create-interface',
			'image' : attach_id
		}, function(response) {
			
			if( response.status == 'valid' ){
				$("#decoEliteLighboxContent").html( response.html );
				
				hotpoints_products = $("#deco-interface-wrapper .hotpoints-images");
				hotpoints_add_new = $("#deco-interface-wrapper #deco-add-new-tpl").text();

                // build hotpoints on image load...
				$("#deco-interface-full-image").find('img').on('load', function() {
                    rebuild_hotpoints();
				});
			}
			
			ajaxLoading( 'remove' );
		}, 
		'json');
	}
	
	function createLightbox( elm )
	{
		tb_show( 'Create Hotspot(s) ... ', '#TB_inline?inlineId=decoEliteLighbox' );
		//tb_position();
		tb_resize();
		
		create_interface( elm );
	}
	
	function tb_resize()
	{
		function resize(){
			
			var win 		= $(window),
				winHeight 	= win.height(),
				winWidth 	= win.width(),
				tbWindow 	= $('#TB_window');
				
			tbWindow.css('width', "70%");
			tbWindow.css('margin-left', '-' + (parseInt(tbWindow.width() / 2)) + 'px');

			var tbWindow = $('#TB_window'),
				tb_width = tbWindow.width(),
				tb_height = tbWindow.height();
			
			$('#TB_ajaxContent').css({
				'width': (tb_width - 40) + "px",
				'height': (tb_height - 50) + "px"
			});
		}
		resize();
		
		$(window).on('resize', function(){
			resize();
		});
	}
	
	function createHotpoint( image_wrapper, e, type, product_id )
	{
		var new_id = hotpoints_ids.slice(-1).pop();
		if( typeof new_id == 'undefined' ){
			new_id = 0;
		}else{
			++new_id;
		}

		hotpoints_ids.push( new_id );

		var hotpointHtml = $("<span class='deco-hotpoint' />");
		hotpointHtml.data( 'hpid',  new_id );
 
        var iwh = {
            w: parseInt( image_wrapper.find('img').width() ), //image_wrapper.outerWidth()
            h: parseInt( image_wrapper.find('img').height() ) //image_wrapper.outerWidth() / image_wrapper.find('img').data('prop')
        };
        //console.log( 'iwh', iwh ); 
		if( type != 'rebuid' ){
			var divPos = {
		        left: ( e.pageX - image_wrapper.offset().left - 12 ),
		        top: ( e.pageY - image_wrapper.offset().top - 12 )
		    };
	   	}
	   	else{
	   		var divPos = {
		        left: e.pageX,
		        top: e.pageY
		    };
	   	}
        divPos = {
            left: parseInt( divPos.left ),
            top: parseInt( divPos.top )
        };
	   	//console.log( 'divPos', divPos );
	   	
	   	// relative positioning
	   	divPos = $.extend(divPos, {
	   	    iw      : iwh.w,
	   	    ih      : iwh.h
	   	   //,_left    : parseFloat( ( divPos.left * 100 ) / iwh.w ).toFixed(3),
	   	   //,_top     : parseFloat( ( divPos.top * 100 ) / iwh.h ).toFixed(3)
	   	});
	   	//console.log( 'divPos2' ); console.dir( divPos );

	    hotpointHtml
		    .css({
		    	'left'   : divPos.left + "px",
		    	'top'    : divPos.top + "px"
		    })
		    .data(divPos); 

		image_wrapper.append( hotpointHtml );

		hotpointHtml.draggable({
			containment: image_wrapper,
			stop: function( event, ui ) {
				
				// find hp rel
				$(".hotpoints-images > li").each(function(){
					var that2 = $(this),
						relid = that2.data('hprel');
						
					if( relid == hotpointHtml.data("hpid") ){
					    var posObj = {
                            left    : parseInt( ui.position.left ), //( ui.position.left - 30 )
                            top     : parseInt( ui.position.top ) //( ui.position.top - 30 )
                        };
                        // relative positioning
                        posObj = $.extend(posObj, {
                            iw      : iwh.w,
                            ih      : iwh.h
                           //,_left    : parseFloat( ( posObj.left * 100 ) / iwh.w ).toFixed(3),
                           //,_top     : parseFloat( ( posObj.top * 100 ) / iwh.h ).toFixed(3)
                        });
						that2.data(posObj);
					}
				});
			   	
			   	update_save_params();
			}
		});

		create_hotpoint_details( hotpointHtml, product_id );
	}
	
	function new_hotpoint_color( hotpointHtml, hp_elm )
	{
		hotpointHtml.css( "background-color", hotpoints_colors[hotpointHtml.data('hpid')] );
		hp_elm.find(".deco-product-image").css( "background-color", hotpoints_colors[hotpointHtml.data('hpid')] );
		
		hp_elm.data({
            left      : ( hotpointHtml.data('left') ),
	    	top       : ( hotpointHtml.data('top') ),
            iw        : ( hotpointHtml.data('iw') ),
            ih        : ( hotpointHtml.data('ih') )
            //,_left     : ( hotpointHtml.data('_left') ),
            //,_top      : ( hotpointHtml.data('_top') )
	   	});
	   	
	   	update_save_params();
	}
	
	function rebuild_hotpoints()
	{
		var params = curr_gallery_item.find('textarea').text();
		if( params != "" ){
			$.each( $.parseJSON( params ), function(key, value){
				createHotpoint( $("#deco-interface-full-image"), {
					'pageY': value.hotpoint.top,
					'pageX': value.hotpoint.left
				}, 'rebuid', value.product );
			});
		} 
	}
	
	function update_save_params()
	{
		// create textarea if not exist
		if( curr_gallery_item.find("textarea").size() == 0 ){
			var textarea =  $('<textarea />');
			textarea.attr( "name", 'deco-image-name' );
			curr_gallery_item.append( textarea );
		}
		
		
		var textarea = curr_gallery_item.find("textarea"),
			params_arr = new Array();
		
		$("#decoEliteLighboxContent #deco-interface-wrapper .hotpoints-images > li").each(function(){
			var that = $(this);
 
			if( parseInt( that.find("select").val() ) > 0 ){
				
				var saveObj = {
                    'product': that.find("select").val(),
                    'hotpoint': {
                        'left'      : that.data("left"),
                        'top'       : that.data("top"),
                        'iw'        : that.data("iw"),
                        'ih'        : that.data("ih")
                        //,'_left'     : that.data("_left"),
                        //,'_top'      : that.data("_top")
                    }
                };
				//console.dir( saveObj ); 
				params_arr.push(saveObj);	
			}
		});
		
		var save_to_textarea = JSON.stringify( params_arr ).replace( '"/g', "'" );
		
		textarea.text( save_to_textarea );
	}
	
	function hotpoint_colors()
	{
		hotpoints_colors.push( '#1abc9c' ); 
		hotpoints_colors.push( '#2ecc71' ); 
		hotpoints_colors.push( '#3498db' ); 
		hotpoints_colors.push( '#9b59b6' ); 
		hotpoints_colors.push( '#34495e' ); 
		hotpoints_colors.push( '#16a085' ); 
		hotpoints_colors.push( '#27ae60' ); 
		hotpoints_colors.push( '#2980b9' ); 
		hotpoints_colors.push( '#8e44ad' ); 
		hotpoints_colors.push( '#2c3e50' ); 
		hotpoints_colors.push( '#f1c40f' ); 
		hotpoints_colors.push( '#e67e22' ); 
		hotpoints_colors.push( '#e74c3c' ); 
		hotpoints_colors.push( '#ecf0f1' ); 
		hotpoints_colors.push( '#95a5a6' ); 
		hotpoints_colors.push( '#f39c12' ); 
		hotpoints_colors.push( '#d35400' ); 
		hotpoints_colors.push( '#c0392b' ); 
		hotpoints_colors.push( '#bdc3c7' ); 
		hotpoints_colors.push( '#7f8c8d' ); 
	}
	
	function create_hotpoint_details( hotpointHtml, product_id )
	{
		var hp_elm = $( hotpoints_add_new );
		hp_elm.find( ".de-chose-select" ).chosen({
			no_results_text: "Oops, nothing found!", 
			width: "290px"
		});
		
		hp_elm.data( "hprel", hotpointHtml.data('hpid') );
		hotpoints_products.append( hp_elm );
		
		hotpoints_products.find("#deco-no-pins").hide();
		
		new_hotpoint_color( hotpointHtml, hp_elm );
		
		if( parseInt( product_id ) > 0 ){
			hp_elm.find("select").val( product_id ).trigger('chosen:updated').trigger('change');
		}
	}
	
	function makeSortable()
	{
		$(".decoElite-hotpoints-gallery-box").sortable({
			items: 'li:not(:last)'
		});
		$(".decoElite-panorama-gallery-box").sortable({
			items: 'li:not(:last)',
			stop: function(){
				preview_into_cube();
			}
		});
	}
	
	function ajaxLoading( status ) 
    {
    	if( status == 'show' ){
        	$("#wwcAmzAffAddProduct").append( loading );
       	}
       	else{
       		$("#wwcAmzAff-ajaxLoadingBox").remove();
       	}
    }
    
    function removeHotpoint( that )
    {
    	var row 	= that.parents('li').eq(0),
    		rel_id 	= row.data('hprel');
    	
    	$("#deco-interface-full-image").find('span.deco-hotpoint').each(function(){
			var that2 = $(this);
			if( rel_id == that2.data('hpid') ){
				$(that2).fadeOut(400).remove();
				row.fadeOut(400).remove();
				
				update_save_params();
				
				if( hotpoints_products.find("li").size() <= 1 ){ 
					hotpoints_products.find("#deco-no-pins").show();
				}
				return;
			}
		});
    }
    
    function highlight_hotpoint( that, scale_size )
    {
    	$("#deco-interface-full-image").find('span.deco-hotpoint').each(function(){
			var that2 = $(this);
			if( that.data('hprel') == that2.data('hpid') ){
				that2.css('transform', 'scale(' + ( scale_size ) + ')');
				return;
			}
		});
    }
    
    function send_to_editor()
    {
		if( window.send_to_editor != undefined ) {
			// store old send to editor function
			window.restore_send_to_editor = window.send_to_editor;	
		}
		
		function new_image_box_html( element_id, thumb_id, response )
		{
			var html = '';
			html += '<li>';
			html += 	'<input type="hidden" name="' + ( element_id ) + '[' + ( thumb_id ) + '][image]" value="' + ( thumb_id ) + '">';
			html += 	'<textarea name="' + ( element_id ) + '[' + ( thumb_id ) + '][pins]"></textarea>';
			html += 	'<div class="upload_image_preview">';
			html += 		'<img src="' + ( response.thumb ) + '">';
			html += 		'<span class="decoElite-button blue deco-manage-pins">Manage Pins</span>';
			html += 		'<span class="decoElite-button red deco-remove-image">Remove Image</span>';
			html +=		'</div>';
			html += '</li>';
			
			return html;
		}
	
		window.send_to_editor = function(html){
			var thumb_id = $('img', html).attr('class').split('wp-image-');
			if( typeof thumb_id == 'undefined' ) {
				var thumb_id = $(html).attr('class').split('wp-image-');
			}
			thumb_id = parseInt(thumb_id[1]);
			
			jQuery.post(ajaxurl, {
				'action' : 'decoEliteWPMediaUploadImage',
				'att_id' : thumb_id
			}, function(response) {
				if (response.status == 'valid') {
					
					// create the new box for image or use existend one
					var html = new_image_box_html( upload_popup_parent.find('a').data('elmid'), thumb_id, response );
					
					upload_popup_parent.before( html );
					
					makeSortable();
				
				}
			}, 'json');
			
			tb_remove();
			
			if( window.restore_send_to_editor != undefined ) {
				// store old send to editor function
				window.restore_send_to_editor = window.send_to_editor;	
			}
		}
	}
	
	function preview_into_cube()
	{
		var panorama_target = $("#decoElite-panorama-scheme li.de-border"),
    		cc = 0;
    	
    	panorama_target.each(function(){
    		$(this).html('');
    	});
    	
    	$('.decoElite-panorama-gallery-box .upload_image_preview').each(function(){
    		var that = $(this);
    		var actualImg = that.find('img');
    		
    		panorama_target.eq(cc).html( $('<img src="' + ( actualImg.attr("src") ) + '" />'));
    		cc++;
    	});
	}
    
    function triggers()
    {
    	$("body").on('click', '.deco-manage-pins', function(e){
    		e.preventDefault();
    		var that = $(this);
    		curr_gallery_item = that.parents('li').eq(0);
    		
    		createLightbox( curr_gallery_item );
    	});

    	
    	$("body").on("click", "#deco-interface-full-image", function(e){
    		e.preventDefault();
    		var that = $(this);
    		
    		createHotpoint( that, e );
    	});
    	
    	$("body").on("change", ".de-chose-select", function(e){
    		var that 	= $(this),
    			val		= that.val(),
    			opt		= that.find('option[value="' + ( val ) + '"]'),
    			thumb 	= opt.data('thumb'),
    			row 	= that.parents('li').eq(0);
    		
    		// update the image
    		if( typeof thumb != "undefined" ){
    			row.find(".deco-product-image img").attr( 'src', thumb );
    		}
    		
    		update_save_params();
    	});
    	
    	$("body").on("mouseenter", ".hotpoints-images > li", function(){
    		highlight_hotpoint( $(this), 1.2 );
    		
    	}).on("mouseleave", ".hotpoints-images > li", function(){
    		highlight_hotpoint( $(this), 1 );
    	});
    	
    	$("body").on("click", ".deco-product-remove", function(e){
    		e.preventDefault();
    		var that = $(this);
    		
    		removeHotpoint( that );
    	});
    	
    	$("body").on("click", ".deco-remove-image", function(e){
    		e.preventDefault();
    		var that = $(this);
    		
    		if( confirm("Are tou sure you want to delete this image from gallery?") ){
    			that.parents("li").eq(0).remove();
    			preview_into_cube();
    		}
    	});
    	
    	
    	$("body").on("click", "#decoEliteLighboxContent #deco-interface-wrapper .hotpoints-options a", function(e){
    		e.preventDefault();
    		tb_remove();
    	});
    	
    	$("body").on("click", ".decoElite-hotpoints-add-new-image", function(e){
    		e.preventDefault();
    		
    		upload_popup_parent = $(this).parent("li");
			var win = $(window);
			
			send_to_editor();
		
			tb_show('Select image', 'media-upload.php?type=image&amp;height=' + ( parseInt(win.height() / 1.2) ) + '&amp;width=610&amp;post_id=0&amp;from=aaframework&amp;TB_iframe=true');
    	});
    	
    	$("body").on("click", ".decoElite-panorama-add-new-image", function(e){
    		e.preventDefault();
    		
    		upload_popup_parent = $(this).parent("li");
			var win = $(window);
			
			send_to_editor();
		
			tb_show('Select image', 'media-upload.php?type=image&amp;height=' + ( parseInt(win.height() / 1.2) ) + '&amp;width=610&amp;post_id=0&amp;from=aaframework&amp;TB_iframe=true');
    	});
    	
    	makeSortable();
    	
    	preview_into_cube();
    }
    

	// external usage
	return {
	}
})(jQuery);