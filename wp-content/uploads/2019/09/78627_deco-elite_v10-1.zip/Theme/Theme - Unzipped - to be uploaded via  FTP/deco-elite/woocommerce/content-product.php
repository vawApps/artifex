<?php
/**
 * The template for displaying product content within loops.
 *
 * Override this template by copying it to yourtheme/woocommerce/content-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $product, $woocommerce_loop, $decoElite;

// Store loop count we're currently on
if ( empty( $woocommerce_loop['loop'] ) )
	$woocommerce_loop['loop'] = 0;

// Store column count for displaying the grid
if ( empty( $woocommerce_loop['columns'] ) )
	$woocommerce_loop['columns'] = apply_filters( 'loop_shop_columns', 4 );

// Ensure visibility
if ( ! $product || ! $product->is_visible() )
	return;

// Increase loop count
$woocommerce_loop['loop']++;

// Extra post classes
$classes = array();
if ( 0 == ( $woocommerce_loop['loop'] - 1 ) % $woocommerce_loop['columns'] || 1 == $woocommerce_loop['columns'] )
	$classes[] = 'first';
if ( 0 == $woocommerce_loop['loop'] % $woocommerce_loop['columns'] )
	$classes[] = 'last';

$item_size_class = isset($woocommerce_loop['item_size_class']) ? $woocommerce_loop['item_size_class'] : 'col-lg-3 col-md-4 col-sm-6 col-xs-12'; 
if( isset($decoElite->coreFunctions->data['page_sidebars']) && count($decoElite->coreFunctions->data['page_sidebars']) > 0 ){
	if( !isset($woocommerce_loop['where']) || $woocommerce_loop['where'] != "releated" ){
		$item_size_class = 'col-lg-4 col-md-6 col-sm-12';
	}
}
?>

<div class="<?php echo $item_size_class;?>">
	<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>
	<div class="de-products de-white-bg">
		<div class="de-prod-container">
			<div class="de-fp-prod-image">
				<?php if( $product->is_on_sale() ){?>
	        	<span class="de-sale-badge"><?php esc_html_e('Sale' , 'deco-elite'); ?></span>
		        <?php }?>
		        <div class="wish-comparebtns">
			        <?php
			        	if( shortcode_exists('yith_wcwl_add_to_wishlist')) {
			        		echo do_shortcode('[yith_wcwl_add_to_wishlist wishlist_url="'. get_site_url() .'/wishlist/"]');
						} 
			        ?>
			    	<?php 
			    		if( shortcode_exists('yith_compare_button')) {
			    			echo do_shortcode('[yith_compare_button product="'.(get_the_ID()).'"]'); 
						}
			    	?>
		        </div>
		        <div class="product-hover-mask">
					<a href="<?php the_permalink(); ?>"><?php echo woocommerce_template_loop_product_thumbnail();?></a>
				</div>
			</div>
			<div class="de-fp-prod-info">
				<a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a>
				<p>
					<?php echo woocommerce_template_loop_price(); ?>
				</p>
				<div class="de_buttons_wrapper">
					<div class="de-add-to-cart-button"><?php echo woocommerce_template_loop_add_to_cart(); ?></div>
				</div>
			</div>
		</div>
	</div>
</div>