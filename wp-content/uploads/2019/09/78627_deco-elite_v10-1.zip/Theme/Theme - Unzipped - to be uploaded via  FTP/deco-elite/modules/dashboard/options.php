<?php
/**
* Return as json_encode
* http://www.aa-team.com
* ======================
*
* @author		Andrei Dinca, AA-Team
* @version		1.0
*/
global $decoElite;
$decoEliteDashboard = decoEliteDashboard::getInstance();
echo json_encode(array(
    $GLOBALS['decoElite_tried_module']['db_alias'] =
        'html_validation' => $decoEliteDashboard->getBoxes()
));