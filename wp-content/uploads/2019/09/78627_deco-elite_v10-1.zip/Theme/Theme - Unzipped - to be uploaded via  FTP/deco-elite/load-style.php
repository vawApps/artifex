<?php
if ( !defined('ABSPATH') ) {
	$absolute_path = __FILE__;
	$path_to_file = explode( 'wp-content', $absolute_path );
	$path_to_wp = $path_to_file[0];


	/** Set up WordPress environment */
	if( file_exists( $path_to_wp.'/wp-load.php' ) ) {
		require_once( $path_to_wp.'/wp-load.php' );
	}
	else{
		require_once( '../../../wp-load.php' );
	}

	global $decoElite, $wp_filesystem;;

	$decoElite->coreFunctions->update_settings();
	$cssFiles = array( $decoElite->cfg['paths']['theme_dir_path'] . 'style.css', $decoElite->cfg['paths']['theme_dir_path'] . 'css/responsive.css' );
	  
	if( isset( $decoElite->coreFunctions->settings['layout']['slider_theme'] ) && $decoElite->coreFunctions->settings['layout']['slider_theme'] == 'slider_theme2') {
		$cssFiles[] = $decoElite->cfg['paths']['theme_dir_path'] . 'css/slider-themes/slider-theme-2.css';
	}

	$buffer = "";

	foreach ($cssFiles as $cssFile) {

		//$buffer .= file_get_contents($cssFile);
		$buffer .= $wp_filesystem->get_contents($cssFile);

	}
	if( isset($decoElite->coreFunctions->settings['layout']["body_color"]) ){
		$buffer .= 'body { background-color: '.$decoElite->coreFunctions->settings['layout']["body_color"].';}';
	}
	 
	if( isset($decoElite->coreFunctions->settings['layout']["background_image"]) && $decoElite->coreFunctions->settings['layout']["background_image"] != '' && $decoElite->coreFunctions->settings['layout']["background_image"] > 1 ){
		$bk_fit = $decoElite->coreFunctions->settings['layout']["background_fit"];
		$bkg_image = wp_get_attachment_image_src( $decoElite->coreFunctions->settings['layout']['background_image'], 'full' );
		$bkg_image = $bkg_image[0];
		$buffer .= 'body { background-image: url('. $bkg_image .'); }';
		
		if( $bk_fit == 'cover' || $bk_fit == 'contain' ) { 
			$buffer .= 'body { background-size: '. $bk_fit .'; }';
		} elseif( $bk_fit == 'repeat') {
			$buffer .= 'body { background-repeat: '. $bk_fit .'; }';
		} elseif( $bk_fit == '100% auto' || $bk_fit == 'auto 100%' ) {	
			$buffer .= 'body { background-size: '. $bk_fit .'; background-repeat: no-repeat; }';
		} elseif( $bk_fit == 'center' ) {
			$buffer .= 'body { background-position: '. $bk_fit .'; }';
		}
	}

	if( isset($decoElite->coreFunctions->settings['layout']['primary_color']) && trim($decoElite->coreFunctions->settings['layout']['primary_color']) != "" && $decoElite->coreFunctions->settings['layout']['primary_color'] != strtolower('#e93712') ){
		$buffer = str_replace( array( strtolower("#e93712"), "#E93712" ), strtoupper($decoElite->coreFunctions->settings['layout']['primary_color']), $buffer);
	}

	if( isset($decoElite->coreFunctions->settings['layout']['secondary_color']) && trim($decoElite->coreFunctions->settings['layout']['secondary_color']) != "" && $decoElite->coreFunctions->settings['layout']['secondary_color'] != strtolower('#55312a') ){
		$buffer = str_replace( array( strtolower("#55312a"),"#55312a" ) , strtoupper($decoElite->coreFunctions->settings['layout']['secondary_color']), $buffer);
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["main_font"]) ){
		$buffer = str_replace( "Source Sans Pro", $decoElite->coreFunctions->settings['layout']["main_font"], $buffer );
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["headers_font"]) ){
		$buffer = str_replace( "Montserrat", $decoElite->coreFunctions->settings['layout']["headers_font"], $buffer );
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["intro_font"]) ){
		$buffer = str_replace( "Playfair Display", $decoElite->coreFunctions->settings['layout']["intro_font"], $buffer );
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["logo_width"]) ){
		$buffer .= 'body .de-main-nav .de-logo img { width: '.$decoElite->coreFunctions->settings['layout']["logo_width"].';}';
		$buffer .= 'body .de-main-nav .de-logo { width: '.$decoElite->coreFunctions->settings['layout']["logo_width"].' ;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["logo_height"]) ){
		$buffer .= 'body .de-main-nav .de-logo img { height: '.$decoElite->coreFunctions->settings['layout']["logo_height"].' ;}';
		$buffer .= 'body .de-main-nav .de-logo { height: '.$decoElite->coreFunctions->settings['layout']["logo_height"].' ;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["footer_logo_width"]) ){
		$buffer .= 'body .de-footer-logo { width: '.$decoElite->coreFunctions->settings['layout']["footer_logo_width"].' !important;}';
		$buffer .= 'body .de-footer-logo a img { width: '.$decoElite->coreFunctions->settings['layout']["footer_logo_width"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["footer_logo_height"]) ){
		$buffer .= 'body .de-footer-logo { height: '.$decoElite->coreFunctions->settings['layout']["footer_logo_height"].' !important;}';
		$buffer .= 'body .de-footer-logo a img { height: '.$decoElite->coreFunctions->settings['layout']["footer_logo_height"].' !important;}';
	}
	
	if( $decoElite->coreFunctions->settings['layout']["logo_bg_color"] != 'yes' ) {
		$buffer .= 'body .de-main-nav .de-logo { background: none; }';
	} else {
		$buffer .= 'body .de-main-nav .de-logo { background: '. $decoElite->coreFunctions->settings['layout']["logo_bg_color_select"] .'!important; }';
	}
	
	if( $decoElite->coreFunctions->settings['layout']["footer_logo_bg_color"] != 'yes' ) {
		$buffer .= 'body .de-footer-logo a img { background: none !important; }';
	} else {
		$buffer .= 'body .de-footer-logo a img { background: '. $decoElite->coreFunctions->settings['layout']["footer_logo_bg_color_select"] .'!important; }';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["main_menu_background"]) ){
		$buffer .= 'body .de-main-nav { background: '.$decoElite->coreFunctions->settings['layout']["main_menu_background"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["main_menu_top_padding"]) ){
		$buffer .= 'body .de-main-nav .de-main-menu { padding-top: '.$decoElite->coreFunctions->settings['layout']["main_menu_top_padding"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["main_menu_bottom_padding"]) ){
		$buffer .= 'body .de-main-nav .de-main-menu { padding-bottom: '.$decoElite->coreFunctions->settings['layout']["main_menu_bottom_padding"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["main_menu_element_margin"]) ){
		$buffer .= 'body .de-main-nav .de-main-menu li { margin: '.$decoElite->coreFunctions->settings['layout']["main_menu_element_margin"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["main_menu_element_padding"]) ){
		$buffer .= 'body .de-main-nav .de-main-menu li a { padding: '.$decoElite->coreFunctions->settings['layout']["main_menu_element_padding"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["main_menu_text_color"]) ){
		$buffer .= 'body .de-main-nav .de-main-menu li a { color: '.$decoElite->coreFunctions->settings['layout']["main_menu_text_color"].' !important;}';
	}

	if( isset($decoElite->coreFunctions->settings['layout']["main_menu_hover_text_color"]) ){
		$buffer .= 'body .de-main-nav .de-main-menu li a:hover, .de-main-nav .de-main-menu li.current-menu-item a { color: '.$decoElite->coreFunctions->settings['layout']["main_menu_hover_text_color"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["main_menu_font_size"]) ){
		$buffer .= 'body .de-main-nav .de-main-menu li a { font-size: '.$decoElite->coreFunctions->settings['layout']["main_menu_font_size"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["main_menu_font_family"]) ){
		$buffer .= 'body .de-main-nav .de-main-menu li a { font-family: '.$decoElite->coreFunctions->settings['layout']["main_menu_font_family"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["top_menu_background"]) ){
		$buffer .= 'body .de-top-nav { background: '.$decoElite->coreFunctions->settings['layout']["top_menu_background"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["top_menu_text_color"]) ){
		$buffer .= 'body .de-top-nav .pull-left a, body .de-top-nav .de-wishlist, .de-top-nav .de-phone { color: '.$decoElite->coreFunctions->settings['layout']["top_menu_text_color"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["top_menu_font_size"]) ){
		$buffer .= 'body .de-top-nav .pull-left a, body .de-top-nav .de-wishlist, .de-top-nav .de-phone { font-size: '.$decoElite->coreFunctions->settings['layout']["top_menu_font_size"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["top_menu_font_family"]) ){
		$buffer .= 'body .de-top-nav .pull-left a, body .de-top-nav .de-wishlist, .de-top-nav .de-phone { font-family: '.$decoElite->coreFunctions->settings['layout']["top_menu_font_family"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["footer_container_background"]) ){
		$buffer .= 'body .de-footer-links { background: '.$decoElite->coreFunctions->settings['layout']["footer_container_background"].' !important;}';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["footer_disclaimer_background"]) ){
		$buffer .= 'body .de-footer-disclaimer { background: '.$decoElite->coreFunctions->settings['layout']["footer_disclaimer_background"].'; }';
		//$buffer .= 'body .de-footer-box { border-left: '.$decoElite->coreFunctions->settings['layout']["footer_disclaimer_background"].' !important; }';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["footer_disclaimer_text_color"]) ){
		$buffer .= 'body .de-footer-disclaimer p, body .de-footer-disclaimer p a { color: '.$decoElite->coreFunctions->settings['layout']["footer_disclaimer_text_color"].' !important; }';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["footer_font_size"]) ){
		$buffer .= 'body .de-footer-box ul li a, body .de-footer-disclaimer p, body .de-footer-disclaimer p a { font-size: '.$decoElite->coreFunctions->settings['layout']["footer_font_size"].' !important; }';
	}
	
	if( isset($decoElite->coreFunctions->settings['layout']["footer_font_family"]) ){
		$buffer .= 'body .de-footer-box ul li a, body .de-footer-disclaimer p, body .de-footer-disclaimer p a { font-family: '.$decoElite->coreFunctions->settings['layout']["footer_font_family"].' !important; }';
	}

	if( isset($decoElite->coreFunctions->settings['layout']['border_radius']) && $decoElite->coreFunctions->settings['layout']['border_radius'] == 'no' ){

		$pattern = '~border-radius:\s*([^;$]+)~si';

		$buffer = preg_replace( $pattern, 'border-radius: 0px !important', $buffer );

	} 
 
	// Remove comments

	$buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer);

	// Remove space after colons

	$buffer = str_replace(': ', ':', $buffer);

	 

	// Remove whitespace

	$buffer = str_replace(array("\r\n", "\r", "\n", "\t", '    ', '    '), '', $buffer);

	 

	// Enable GZip encoding.

	if ( ! ini_get('zlib.output_compression') || 'ob_gzhandler' != ini_get('output_handler') ) ob_start();

	else ob_start("ob_gzhandler");

	 

	// Enable caching

	header('Cache-Control: public');

	 

	// Expire in one day

	header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 86400) . ' GMT');

	 

	// Set the correct MIME type, because Apache won't set it for us

	header("Content-type: text/css");

	 

	// Write everything out

	echo $buffer;  
	
	// try to write the buffer as .css
	if( !is_file( get_template_directory() . '/load-style.css' ) ){
		//file_put_contents( get_template_directory() . '/load-style.css', $buffer );
		$wp_filesystem->put_contents( get_template_directory() . '/load-style.css', $buffer );
	} 
}