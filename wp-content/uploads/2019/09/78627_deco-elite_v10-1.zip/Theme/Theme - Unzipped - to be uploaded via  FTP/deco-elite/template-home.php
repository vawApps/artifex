<?php  
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *  Template Name: Template Homepage
 *	
**/
get_header(); 
// remove autop for homepage
add_filter("the_content", array( $decoElite->coreFunctions,"the_content_filter" ));
?>
	<!-- Content -->
	<div class="de-content">
		<div class="container-fluid de-resizeable-container">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>	
			<?php the_content(); ?>
		<?php endwhile; endif; ?>
		</div><!-- END of .container -->
	</div>
	
<?php get_footer(); ?>