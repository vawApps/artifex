<?php
/**
 * Config file, return as json_encode
 * http://www.aa-team.com
 * ======================
 *
 * @author		AA-Team
 * @version		1.0
 */
$decoElite = $GLOBALS['decoElite']; 
echo json_encode(
	array(
		'advertising' => array(
			'version' => '1.0',
			'title' => esc_html__('decoElite Advertising', 'deco-elite'),
			'description' => esc_html__("With this widget you can add advertising to your site (links or images) !", 'deco-elite'),
			'options' => array(
				'title' 	=> array(
					'title'		=> esc_html__('Title', 'deco-elite'),
					'type' 		=> 'text',
					'width'		=> '100%',
					'std' 		=> esc_html__('Smashing Offer', 'deco-elite')	
				),
				'url' 	=> array(
					'title'		=> esc_html__('Link', 'deco-elite'),
					'type' 		=> 'text',
					'width'		=> '100%',
					'std' 		=> esc_html__('', 'deco-elite')	
				),
				'image' => array(
					'type' 			=> 'upload_image_wp',
					'size' 			=> 'large',
					'force_width'	=> '80',
					'preview_size'	=> 'large',	
					'value' 		=> esc_html__('Banner Image', 'deco-elite'),
					'title' 		=> esc_html__('Banner', 'deco-elite'),
					'desc' 			=> esc_html__('Upload your banner using the native media uploader', 'deco-elite'),
				),
			)
		)
	)
);