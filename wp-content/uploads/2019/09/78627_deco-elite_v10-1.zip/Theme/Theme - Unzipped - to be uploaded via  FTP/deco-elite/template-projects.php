<?php  
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Amazon Affiliate Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *  Template Name: Template Projects
 *	
**/
get_header();
global $tag, $cat;   
?>
	<div class="container-fluid de-template-projects">
		<?php
			$decoElite->coreFunctions->printSidebar( 'left' );
		?>
		<!-- Main Container -->
		<section>
			<?php
			$args = array(
				'post_type' => 'projects',
				'paged' => $paged,
				'posts_per_page' => -1
			);
			
			if( isset($tag) && trim($tag) != "" ){
				$args['tag'] = $tag;
			}
			if( isset($cat) && trim($cat) != "" ){
				$args['cat'] = $cat;
			}
			query_posts($args);
			?>
			<?php if ( have_posts() ) : ?>
				
				<div class="projects-filter-wrapper">
					<h1 class="de-projects-maintitle"><?php the_title(); ?></h1>
					<?php 
					$categories = get_terms( 'projects_category', array(
					 	'orderby'    => 'count',
					 	'hide_empty' => 1
					) );
					?>
					<ul class="projects-filter">
						<li><a href="#" data-filter="*" class="active">All</a></li>
						<?php
						if( count($categories) > 0 ){
							foreach ($categories as $term) {
								echo '<li><a href="#" data-filter=".filter-' . ( $term->slug ) . '">' . ( $term->name ) . '</a></li>';
							}
						}
						?>
					</ul>
				</div>
				
				<div class="projects-box">
					<?php
					while( have_posts() ) : the_post(); ?>
						<?php 
							$term_list = wp_get_post_terms( $post->ID, 'projects_category' );  
							$taxonomies = array();
							if( count($term_list) > 0 ){
								foreach ($term_list as $term) {
									$taxonomies[] = 'filter-' . $term->slug;
								}
							}
						?>
						<div class="de-project-item-iso <?php echo ( implode(" ", $taxonomies ) ); ?>">
							<div class="de-project-item">
								<div class="de-project-item-wrap">
									<h6 class="de-project-cat"><?php echo get_the_term_list( $post->ID, 'projects_category', '', ', ', '' ); ?></h6>
									<h3><a href="<?php echo esc_url( get_permalink() ); ?>"><?php  the_title(); ?></a></h3>
									<div class="de_project_short_desc"><?php echo strlen(get_the_excerpt()) > 70 ? substr(get_the_excerpt(), 0, 70) . '..' : get_the_excerpt(); ?></div>
									<?php
									if( has_post_thumbnail() ) {
									?>
									<div class="de-proj-image-wrap">
										<?php echo get_the_post_thumbnail( $post->ID, 'decoElite-project-list-image' ); ?>
										<a href="<?php echo esc_url( get_permalink() ); ?>" class="info">
											<span class="mask">
						                		<i class="fa fa-link"></i>
						                    </span>
						               </a>
									</div>
										
									<?php } else { ?>
									<a href="<?php echo esc_url( get_permalink() ); ?>" class="de_read_more"><?php esc_html_e('Read More', 'deco-elite');?></a>
									<?php } ?>
								</div>
							</div>
						</div>
					<?php 
					endwhile; 
					?>
			<?php else : ?>
				<?php get_template_part( 'template', 'none' ); ?>
			<?php endif; ?>
			</div>
		</section>
		<?php
			$decoElite->coreFunctions->printSidebar( 'right' );
		?>
	</div>
<?php get_footer(); ?>