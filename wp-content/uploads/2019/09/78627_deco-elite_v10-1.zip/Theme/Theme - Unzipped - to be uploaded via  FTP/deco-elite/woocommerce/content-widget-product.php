<?php global $product, $decoElite; ?>
<li>
	<a class="de-leftcol-widget" href="<?php echo esc_url( get_permalink( $product->id ) ); ?>" title="<?php echo esc_attr( $product->get_title() ); ?>">
		<?php echo $product->get_image(); ?>
	</a>
	
	<div class="de-rightcol-widget">
		<a href="<?php echo esc_url( get_permalink( $product->id ) ); ?>" title="<?php echo esc_attr( $product->get_title() ); ?>">
			<?php echo $product->get_title(); ?>
		</a>
		<?php if( isset( $decoElite->coreFunctions->settings['layout']['enable_ratings'] ) && $decoElite->coreFunctions->settings['layout']['enable_ratings'] == 'yes' ) { ?>		
			<div class="de_product_rating_pagination de-widget">
		    	<?php if ( ! empty( $show_rating ) ) echo $product->get_rating_html(); ?>
		    </div>
		<?php } ?>
		
		<?php echo $product->get_price_html(); ?>
	</div>
</li>