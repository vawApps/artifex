(function() {

    tinymce.PluginManager.add('deshortcodes', function( editor )
    {
        var shortcodeValues = [];
        jQuery.each(shortcodes_button, function(i)
        {
            shortcodeValues.push({text: shortcodes_button[i], value:i});
        });

        editor.addButton('deshortcodes', {
            type: 'listbox',
            text: 'decoElite Shortcodes',
            onselect: function(e) {
                var v = typeof e.control.settings.text != 'undefined' ? e.control.settings.text : e.control._text;
				//console.log( e );
				if( v == 'decoElite_de_tabs' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_de_tabs tab1_title="Your title here" tab2_title="Your title here" tab3_title="Your title here" tab1_content="Your Content Here" tab2_content="Your Content Here" tab3_content="Your Content Here"]' );
				} else if( v == 'decoElite_button' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_button link="#" color="red-brown|black-red|white-brown"]Test Button[/decoElite_button]' );
				} else if( v == 'decoElite_highlight' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_highlight color="" font=""]text[/decoElite_button]' );
				} else if( v == 'decoElite_list_type' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_list_type type="list-arrow"]<li>List Element 1</li><li>List Element 2</li><li>List Element 3</li>[/decoElite_list_type]' );
				} else if( v == 'decoElite_column' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_column size="12" md="12" sm="12" xs="12" extra_class="extraclass"]Your content here[/decoElite_subcolumn]' );
				} else if( v == 'decoElite_subcolumn' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_subcolumn size="12"]Your content here[/decoElite_subcolumn]' );
				} else if( v == 'decoElite_row' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_row class="rowclass"]Your content here[/decoElite_row]' );
				} else if( v == 'decoElite_subrow' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_subrow class="subrowclass"]Your content here[/decoElite_subrow]' );
				} else if( v == 'decoElite_box' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_box class="de-three-rows"]Your content here[/decoElite_box]' );
				} else if( v == 'decoElite_horizontal_spacing' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_horizontal_spacing height="10px"]' );
				} else if( v == 'decoElite_vertical_space' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_vertical_space height="10px"]' );
				} else if( v == 'decoElite_box_headline' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_box_headline class=""]Headline Box[/decoElite_box_headline]' );
				} else if( v == 'decoElite_code' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_code]Your code here[/decoElite_code]' );
				} else if( v == 'decoElite_google_maps' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_google_maps width="100%" height="400px" hide_controls="true" black_and_white="true" address="London, United Kingdom" zoom="12" marker="url-to-image"]' );
				} else if( v == 'decoElite_blog_slideshow' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_blog_slideshow per_page="10" orderby="post_date"]' );
				} else if( v == 'decoElite_our_process' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_our_process title="Our Process" desc="Our process description" image="http://yourwebsite/yourimage.jpg" step_1_text="Step 1" step_2_text="Step 2" step_3_text="Step 3" step_4_text="Step 4" step_final_text="Final Step"]' );
				} else if( v == 'decoElite_designer_box' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_designer_box name="Christopher Jansen" picture="http://yourwebsite/yourdesignerimage.jpg" profession="Designer" title="Love your home" readmore_link="http://yoursite.com"]Text here[/decoElite_designer_box]' );
				} else if( v == 'decoElite_designer_box2' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_designer_box2 name="Christopher Jansen" picture="http://yourwebsite/yourdesignerimage.jpg" profession="Designer" title="Love your home" readmore_link="http://yoursite.com" height="400px"]Text here[/decoElite_designer_box2]' );
				} else if( v == 'decoElite_project_list' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_project_list per_page="3" orderby="post_date"]' );
				} else if( v == 'decoElite_project_box' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_project_box post_id="1"]' );
				} else if( v == 'decoElite_project_gallery' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_project_gallery project_id=""]' );
				} else if( v == 'decoElite_services' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_services title="Services" desc="Dynamically innovate resource leveling customer service for state of the art." service_1="Renovation & Remodeling" service_2="Kitchen & bath design" service_3="Furniture" service_4="Space planning" service_5="Project management" service_6="Decor" service_7="Purchasing & installation" service_8="Artwork"]' );
				} else if( v == 'decoElite_promotions' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_promotions title="Smashing Offer" subtitle="50% off" text="On Decorations" image="http://yourwebsite/promotions.png" height="325px"]' );
				} else if( v == 'decoElite_contact_address' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_contact_address address="Address 1588 Main Street, London, Uk"]' );
				} else if( v == 'decoElite_contact_phone phone' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_contact_phone phone=" (+245) 0800 989 855"]' );
				} else if( v == 'decoElite_contact_email' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_contact_email email="office@deco-elite.com"]' );
				} else if( v == 'decoElite_contact_schedule' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_contact_schedule schedule="Monday to Friday 9:00 a.m. to 5:00 p.m"]' );
				} else if( v == 'decoElite_services_slider_box' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_services_slider_box title="Interior decorating services" description="Your description goes here."][/decoElite_services_slider_box]' );
				} else if( v == 'decoElite_services_slide' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_services_slide link="http://www.yourwebsite.com" slide_image_url="http://yourwebsite/servicesimg.png"]' );
				} else if( v == 'decoElite_icon_box' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_icon_box fontawesome_icon_class="fa-glass" title="Bath & kitchen design" description="Globally incubate standards compliant channels before scalable benefits." link="#" height="410px"]' );
				} else if( v == 'decoElite_de_other_services' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_de_other_services description="Distinctively exploit optimal alignments for intuitive bandwidth."][decoElite_de_tabs tab1_title="Project  management" tab2_title="Artwork" tab3_title="Purchasing & installation" tab1_content="Proactively fabricate one-to-one materials via effective e-business. Completely synergize scalable e-commerce rather than high standards in e-services. Assertively iterate resource maximizing products after leading-edge intellectual capital."][/decoElite_de_other_services]' );
				} else if( v == 'decoElite_de_testimonial' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_de_testimonial author="Alexandra I.  AA-Team"]Appropriately empower dynamic leadership skills after business portals. Globally myocardinate interactive supply chains with distinctive quality vectors.[/decoElite_de_testimonial]' );
				} else if( v == 'decoElite_de_testimonials' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_de_testimonials slidespeed="5000"][decoElite_de_testimonial author="Alexandra I.  AA-Team"]Appropriately empower dynamic leadership skills after business portals. Globally myocardinate interactive supply chains with distinctive quality vectors.[/decoElite_de_testimonial][decoElite_de_testimonial  author="Bogdan C.  AA-Team"]Appropriately empower dynamic leadership skills after business portals.[/decoElite_de_testimonials]' );
				} else if( v == 'decoElite_de_accordion' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_de_accordion title="Why choose us"][decoElite_de_accordion_elm title="We make custom interior design projects"]Quickly aggregate B2B users and worldwide potentialities. Progressively plagiarize resource-leveling e-commerce.[/decoElite_de_accordion_elm][decoElite_de_accordion_elm title="We make complete project management"]Quickly aggregate B2B users and worldwide potentialities. Progressively plagiarize resource-leveling e-commerce.[/decoElite_de_accordion_elm][decoElite_de_accordion_elm title="Artwork & design for your home"]Quickly aggregate B2B users and worldwide potentialities. Progressively plagiarize resource-leveling e-commerce.[/decoElite_de_accordion_elm][decoElite_de_accordion_elm title="Full customization for everything"]Quickly aggregate B2B users and worldwide potentialities. Progressively plagiarize resource-leveling e-commerce.[/decoElite_de_accordion_elm][/decoElite_de_accordion]' );
				} else if( v == 'decoElite_de_accordion_elm' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_de_accordion_elm title="We make custom interior design projects"]Quickly aggregate B2B users and worldwide potentialities. Progressively plagiarize resource-leveling e-commerce.[/decoElite_de_accordion_elm]' );
				} else if( v == 'decoElite_de_clear' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_de_clear height="10px"]' );
				} else if( v == 'decoElite_interior_our_process' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_interior_our_process tagline="Interior design" title="Our Process" height="400px"]Our system is pretty simple, just follow the steps and you will have your dream home in no time! Proactively envisioned multimedia based expertise and cross-media growth strategies.[/decoElite_interior_our_process]' );
				} else if( v == 'decoElite_interior_startfrom_box' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_interior_startfrom_box title="Start from" price="$99.99" description="1 Project" definition="*standard measurements & project planning" image_url="http://yourwebsite.com/image.jpg" link="#" link_title="We are available" height="400px"]' );
				} else if( v == 'decoElite_interior_step1' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_interior_step1 tagline="Step 1 - process" title="Initial consult" image_url="http://yoursite.com/image.jpg" height="400px"]Make an appointment for one of the designers to come home for measurements and discuss your requirements.[/decoElite_interior_step1]' );
				} else if( v == 'decoElite_interior_step2' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_interior_step2 tagline="Step 2 - presentation" title="Fitting" project_presentation="Project Presentation" image_url="http://yoursite.com/image.jpg" height="400px"]In our showroom we will present our proposals for your new furniture design with an approximate quote.We will explain step by step and give our recommendations.[/decoElite_interior_step2]' );
				} else if( v == 'decoElite_interior_step3' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_interior_step3 tagline="Step 3 - we’re almost there" title="Materials" image_url="http://yoursite.com/image.jpg" height="400px"]Oak is a hard wood, light in colour, which has good pliable qualities despite its durable nature. It stains and finishes well and resists moisture absorption.[/decoElite_interior_step3]' );
				} else if( v == 'decoElite_interior_step4' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_interior_step4 tagline="Step 4 - final step" title="Fitting" image_url="http://yoursite.com/image.jpg" height="400px"]Our installation teams will be in contact with you during installation![/decoElite_interior_step4]' );
				} else if( v == 'decoElite_newsletter_box' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_newsletter_box title="Get interior design inspiration to your inbox!" caption="Simply subscribe to the newsletter by adding your email address to our mailing lists." contact_form_7_id="4"]' );
				} else if( v == 'decoElite_featured_block' ) {
					tinyMCE.activeEditor.selection.setContent( '[decoElite_featured_block title="Get interior design inspiration to your inbox!" icon="star-empty" link="#" link_text="Find out more"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc quis eros rutrum, sollicitudin ligula sed, feugiat mi. Sed leo metus, iaculis non eleifend quis, lacinia ut tortor.[/decoElite_featured_block]' );
				} else {
  					tinyMCE.activeEditor.selection.setContent( '[' + v + '][/' + v + ']' );              	
                }
            },
            values: shortcodeValues
        });
    });
})();