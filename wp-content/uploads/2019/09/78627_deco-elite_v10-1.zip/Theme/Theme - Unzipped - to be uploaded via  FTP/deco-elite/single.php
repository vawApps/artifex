<?php 
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Amazon Affiliate Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *	
**/

get_header();

$format = get_post_format();
?>
   	<div class="container-fluid de-single-blog">
		
		<?php
			$decoElite->coreFunctions->printSidebar( 'left' , 'col-lg-3 col-md-4 col-sm-4 col-xs-12' ); 
		?>
		<!-- Main Container -->
		<div class="inner-content" <?php echo $decoElite->coreFunctions->content_width();?>>
			<section id="post-<?php the_ID(); ?>">
				<?php if( have_posts() ) : while( have_posts() ) : the_post();?>
				<?php $post_layout = get_post_meta(get_the_ID(), '_layout', true); ?>
				
				<div class="de_simple_post_description <?php echo has_post_thumbnail() == false ? 'full' : '';?>">
					<div class="de-post-title-container">
						<p class="de-post-date"><span class="de-day"><?php echo get_the_date('d'); ?></span><span  class="de-month"><?php echo get_the_date('M'); ?></span><span class="de-year"><?php echo get_the_date('Y'); ?></span></p>
						<div class="de-post-title-wrap">
							<h2><a href="<?php esc_url(get_permalink()); ?>"><?php  the_title(); ?></a></h2>
							<div class="clear"></div>
							<p class="de-post-author"><i class="fa fa-user"></i><?php esc_html_e('by', 'deco-elite');?> <?php echo get_the_author(); ?></p>
							<?php if( has_category() ) { ?>
								<p class="de-post-cat"><i class="fa fa-list-alt"></i><?php the_category(', ', 'multiple'); ?></p>
							<?php } ?>
							<p class="de-comments-no"><i class="fa fa-comments-o"></i><?php echo get_comments_number().' '.esc_html__('comments', 'deco-elite'); ?></p>
						</div>
					</div>
					
					<div class="clear"></div>
					
					<?php if( has_post_thumbnail() && ($format == '' || ($format == 'video' && trim($post_layout['video_embed']) == ''))  ) { ?>
						
						<div class="de_simple_post_image">
							<?php echo get_the_post_thumbnail( $post->ID, 'decoElite-blog-featured-image' ); ?>
							
							<a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" class="info prettyPhoto">
								<span class="mask">
									<i class="fa fa-link"></i>
								</span>
							</a>
						</div>
					
					<?php }else if( $format == 'gallery' && has_shortcode( get_the_content(), 'gallery' ) ) { ?>
						
					<?php
						$gallery_img_ids = $decoElite->coreFunctions->get_gallery_attachments();
						if( count($gallery_img_ids) > 0 ) {
					?>
					
						<div class="list-blog-gallery">
							<?php
							foreach( $gallery_img_ids as $img_id ) {
								$img_full_url = wp_get_attachment_url( $img_id );
								$img = wp_get_attachment_image( $img_id, 'decoElite-blog-featured-image' );
							?>
								<div class="item"><a href="<?php echo esc_url($img_full_url); ?>" class="prettyPhoto"><?php echo $img; ?></a></div>
							<?php } ?>
						</div>
						
					<?php }elseif ( has_post_thumbnail() ) { ?>
					
						<div class="de_simple_post_image">
							<?php echo get_the_post_thumbnail( $post->ID, 'decoElite-blog-featured-image' ); ?>
							
							<a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" class="info prettyPhoto">
								<span class="mask">
									<i class="fa fa-link"></i>
								</span>
							</a>
						</div>
						
					<?php
						}
						
					}else if( $format == 'video' && isset($post_layout['video_embed']) ) { ?>
						
						<div class="de_simple_post_image de_hovereffect">
							<?php echo $post_layout['video_embed']; ?>
						</div>
						
					<?php } ?>
					
					<div class="post-entry">
						<?php
						$content = get_the_content();
						$content = preg_replace('/\[gallery[^\]]+\]/', '',  $content );
						$content = apply_filters('the_content', $content );
						echo $content;
						?>
					</div>
					<?php
					wp_link_pages( array(
						'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'deco-elite' ) . '</span>',
						'after'       => '</div>',
						'link_before' => '<span class="page">',
						'link_after'  => '</span>',
						'pagelink'    => '%',
					) );
					?>
					
					<div class="de_tags">
						<?php the_tags('', '', ''); ?>
					</div>
					
					<div class="de_social_tags">
						<div class="de_social_share">
							<span class="de_sharethis"><?php esc_html_e('Share this post!', 'deco-elite'); ?></span>
						 	<?php 
						 		$decoElite->coreFunctions->print_share_buttons( $post->ID, $post->post_title, get_the_excerpt(), true );
						 	?>
						</div>
					</div>
					
					<?php
					if( isset($decoElite->coreFunctions->settings['layout']['comments_on_pages']) && $decoElite->coreFunctions->settings['layout']['comments_on_pages'] == 'yes' ){
						comments_template();
					}
					?>

					<?php endwhile; endif; ?>
				
				</div>
				
			</section>
		</div>
			
		<?php
			$decoElite->coreFunctions->printSidebar( 'right', 'col-lg-3 col-md-4 col-sm-4 col-xs-12' );
		?>
  	</div>
    <!-- end of content -->

<?php get_footer(); ?>