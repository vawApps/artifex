<?php 
/**
 * The template for displaying 404 pages (Not Found)
 *
 * @package WordPress
 */
get_header();
$page_size = 'col-lg-9 col-sm-8 col-xs-12';

$page_id     = get_queried_object_id();
$sidebar_position = get_post_meta( $page_id, '_page_sidebar_position', true );
if( $sidebar_position == false || $sidebar_position == 'nosidebar' ){
	$page_size = 'col-lg-12 col-sm-12 col-xs-12';
}
?>
	<div class="container-fluid">
		<div class="row">
			<?php
				$decoElite->coreFunctions->printSidebar( 'left' );
			?>
			<div class="<?php echo $page_size;?>">
				<!-- Main Content Section -->
				<section class="<?php echo (isset($decoElite->coreFunctions->data['sidebar']['position']) && $decoElite->coreFunctions->data['sidebar']['position'] == 'nosidebar' ? 'span16' : 'span12'  );?>">
					<div class="main-content-box post-entry">
						<div class="extra-container-box">	
							<article  <?php post_class(); ?>>
								<div class="de_errorpage">
									<h1><span>404</span></h1>
									<h1><?php esc_html_e('Page not found', 'deco-elite'); ?></h1>
									<p><?php esc_html_e("Oops! The page you were looking for was not found on our server! Maybe use a search ?", 'deco-elite' );?></p>
									
									<?php get_search_form(); ?>
								</div>
							</article>
						</div>
					</div>
				</section>
			</div>
			<?php
				$decoElite->coreFunctions->printSidebar( 'right' );
			?>
		</div>
	</div>
    <!-- end of content -->

<?php get_footer(); ?>
