<?php
global $decoElite; 

if ( comments_open() ) :
$comments_count = wp_count_comments( $post->ID );
?>
<div class="clearfix"></div>

<!-- Comments -->
<div class="comments">
	<?php if ( have_comments() ) : ?>
		
		<div class="de_comments_header"><?php printf( _nx( 'One comment', '%1$s Comments', $comments_count->approved, 'comments title', 'deco-elite' ), number_format_i18n($comments_count->approved) ); ?></div>
		
		<ul class="media-list">
			<?php
			wp_list_comments( array(
				'type'		  => 'all',
				'style'       => 'ul',
				'callback'	  => array( $decoElite->coreFunctions, 'comment_template' ),
				'reply_text'  => esc_html__('Reply', 'deco-elite'),
				'short_ping'  => true,
				'avatar_size' => 40
			) );
			?>
		</ul>
		
		<div class="page-numbers-wrapper">
			<?php echo paginate_comments_links(); ?>
		</div>
	<?php endif; ?>
	
	<?php
		// If comments are closed and there are comments, let's leave a little note, shall we?
		if ( ! comments_open() && get_comments_number() ) :
	?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'deco-elite' ); ?></p>
	<?php endif; ?>
	
	<div class="de_comment_form">
		<h2 class="leave-replay"><?php esc_html_e( 'Leave a Reply', 'deco-elite' ); ?></h2>
		<?php
		$commenter = wp_get_current_commenter();
		$req = get_option( 'require_name_email' );
		$aria_req = ( $req ? " aria-required='true'" : '' );
		
		$commentForm_args = array(
		    'label_submit' => esc_html__( 'Post Comment', 'deco-elite' ),
		    'title_reply' => '',
		    'title_reply_to' => esc_html__( 'Leave a Reply to %s', 'deco-elite' ),
		    'cancel_reply_link' => esc_html__( 'Cancel Reply', 'deco-elite' ),
		    'logged_in_as' => '',
		    'comment_notes_before' => '',
		    'comment_notes_after' => '',
		    'comment_field' => '<label for="comment">Your Comment <span>*</span></label><textarea id="comment" name="comment" rows="9" ' . $aria_req . '></textarea>',
		    'fields' => apply_filters( 'comment_form_default_fields', array(
				'author' =>
					'<fieldset><label for="author">' . esc_html__( 'Name', 'deco-elite' ) .
					( $req ? ' <span>*</span> ' : '' ) .
					'<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
					'"' . $aria_req . ' /></label>',
				
				'email' =>
					'<label for="email">' . esc_html__( 'Email', 'deco-elite' ) .
					( $req ? ' <span>*</span> ' : '' ) .
					'<input id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
					'"' . $aria_req . ' /></label></fieldset>'
			))
		);
		 
		comment_form($commentForm_args);
		?>
	</div>
	
	<div class="clearfix"></div>
</div>
<?php
endif;