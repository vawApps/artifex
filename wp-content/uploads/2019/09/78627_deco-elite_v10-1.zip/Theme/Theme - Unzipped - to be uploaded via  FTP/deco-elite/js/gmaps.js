function initDecoEliteMap() {
	var map_elm = jQuery('div.decoElite-map');
	var geocoder = new google.maps.Geocoder();
	
	var customMapType = new google.maps.StyledMapType([
      {
        stylers: [
          {saturation : (map_elm.data('black_and_white') == true ? -100 : 0)}
        ]
      }
    ], {
      	name: 'DecoElite'
  	});
  	
  	var customMapTypeId = 'decoElite_style';
  	 
  	if( map_elm.data('hide_controls') == true ) {
  		var map = new google.maps.Map(document.getElementById('decoElite-map'), {
			zoom: map_elm.data('zoom'),
			panControl: false,
			zoomControl: false,
			mapTypeControl: false,
			scaleControl: false,
			streetViewControl: false,
			overviewMapControl: false
	  	});
  	}else{
  		var map = new google.maps.Map(document.getElementById('decoElite-map'), {
			zoom: map_elm.data('zoom')
	  	});
  	}
  	
  	
  	geocoder.geocode({'address': map_elm.data('address')}, function(results, status) {
		if (status === google.maps.GeocoderStatus.OK) {
			map.setCenter(results[0].geometry.location);
			var marker = new google.maps.Marker({
				map: map,
				position: results[0].geometry.location,
				icon: map_elm.data('marker')
			});
		} else {
			alert('Geocode was not successful for the following reason: ' + status);
		}
	});
	  
	map.mapTypes.set(customMapTypeId, customMapType);
	map.setMapTypeId(customMapTypeId);
}