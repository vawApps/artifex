jQuery(document).ready(function($) {

	// very global
	var decoElite_ID	= [];
	var decoElite_last_key = '';
	
	var decoElite_updateID = function() {
		jQuery(".decoElite-elements").each( function() {
			var elm = jQuery(this);
			if(elm.is(':checked') == true){
				var asin = elm.attr('id').replace('decoElite-check-', '');
				
				// if not in array
				if(jQuery.inArray(asin, decoElite_ID) == -1) decoElite_ID.push(asin);
			}else{
				if(jQuery.inArray(asin, decoElite_ID) > -1 ) decoElite_ID.pop(asin);
			}
		});
		
		jQuery('#decoElite-status-remaining').text(decoElite_ID.length);
	}
	
	var decoElite_reset_div = function () {
		
		var bulkimport_div 	= jQuery("#decoElite-bulkimport .decoElite-product-box"),
			win_h	 		= jQuery(window).height(),
			div_height 		= win_h - 300;
			
		bulkimport_div.height( div_height );	
	}

	var doit;
	jQuery(window).on('resize', function() {
		clearTimeout(doit);
		doit = setTimeout(function(){ decoElite_reset_div(); }, 100);
	});
	
	var decoElite_launch_search = function (data) {
		
		// delete all array documents
		decoElite_ID = null; decoElite_ID = [];
		
		var searchAjaxLoader 	= jQuery("#decoElite-ajax-loader"),
			searchBtn 			= jQuery("#decoElite-search-link");
			
		searchBtn.hide();	
		searchAjaxLoader.show();
		
		var data = {
			action: 'decoElite_bulk_products_request',
			category: jQuery('#dropdown_product_cat').val()
		};
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(response) {
			jQuery("#decoElite-ajax-results").html(response);
			
			searchBtn.show();	
			searchAjaxLoader.hide();
			
			decoElite_updateID();
			jQuery(".decoElite-import-bar").show();
			
			decoElite_reset_div();
			jQuery(".decoElite-product-box").scrollTop(0);
		});
	};
	
	
	jQuery("#decoElite-page").live('change', function() {
		// Hide the label at start
		jQuery('#progress_bar .ui-progress .ui-label').hide();

		// Set initial value
		jQuery('#progress_bar .ui-progress').css('width', '0%');
		
		jQuery('#decoElite-status-ready').text('0');
		
		decoElite_launch_search();
	});
	
	jQuery("#decoElite-check-all").live('change', function() {
		var allChecks = jQuery(".decoElite-elements");

		if(jQuery(this).is(':checked') == true){
			allChecks.each( function() {
				jQuery(this).attr("checked", true);
				decoElite_ID.pop(jQuery(this).attr('id').replace('decoElite-check-', ''));
			});
		}else{
			allChecks.each( function() {
				jQuery(this).attr("checked", false);
				decoElite_ID.pop(jQuery(this).attr('id').replace('decoElite-check-', ''));
			});
		}
		
		decoElite_updateID();
	});
	
	jQuery(".decoElite-elements").live('change', function() {
		if(jQuery(this).is(':checked') == false){
			decoElite_ID.pop(jQuery(this).attr('id').replace('decoElite-check-', ''));
		}else{
			decoElite_ID.push(jQuery(this).attr('id').replace('decoElite-check-', ''));
		}
		
		jQuery('#decoElite-status-remaining').text(decoElite_ID.length);
	});
	
	jQuery("#decoElite-search-form").submit(function(e) {
		decoElite_launch_search();
		return false;
	});
	
	jQuery("a.decoElite-load-product").live('click', function(e) {
		e.preventDefault();
		
		var data = {
			'action': 'decoElite_load_product',
			'ID':  jQuery(this).attr('rel')
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.ajax({
			url: ajaxurl,
			type: 'POST',
			dataType: 'json',
			data: data,
			success: function(response) {
				if(response.status == 'valid'){
					window.location = response.redirect_url;
					return true;
				}else{
					alert(response.msg);
					return false
				}
			}
		});
	});
	
	jQuery("#decoElite-category").live('change', function() {
		var $that 	= jQuery(this),
			val 	= $that.val();
		
		if(val != "All"){
			var data = {
				'action': 'decoElite_load_sort_by_categ',
				'cat': val
			};

			// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
			jQuery.ajax({
				url: ajaxurl,
				type: 'POST',
				dataType: 'json',
				data: data,
				success: function(response) {
					if(response.status == 'valid'){
						jQuery('#decoElite-sort-box').find('select').html(response.select_html);
						jQuery('#decoElite-sort-info').html(response.info_html);
					}
				}
			});
		}else{
			jQuery('#decoElite-sort-info').html('<tr><td><strong>You cannot use any sort parameters with the All search index.</strong></td></tr>');
		}
	});
	
	jQuery("a#decoElite-import-btn").live('click', function(e) {
		e.preventDefault();
		
		var numberOfItems = decoElite_ID.length,
			loaded = 0,
			labelCurr = jQuery('#decoElite-status-ready'),
			labelTotal = jQuery('#decoElite-status-remaining');
		
		// update totals
		labelCurr.text(loaded);	
		labelTotal.text(numberOfItems);	
		
		if(numberOfItems == 0) alert('Please first select some products from list!');
		
		// Hide the label at start
		jQuery('#progress_bar .ui-progress .ui-label').hide();

		// Set initial value
		jQuery('#progress_bar .ui-progress').css('width', '0%');
		
		
		var decoElite_insert_new_product = function(curr_step) {
		
			// stop if not valid decoElite_ID
			if(typeof decoElite_ID[curr_step] == 'undefined') return false;
			
			var data = {
				'action': 'decoElite_process_product',
				'ID':  decoElite_ID[curr_step],
				'to-category': jQuery('#decoElite-to-category').val()
			};

			// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
			jQuery.ajax({
				url: ajaxurl,
				type: 'POST',
				dataType: 'json',
				data: data,
				success: function(response) {
					if(response.status == 'valid'){
						++loaded;
						
						labelCurr.text(loaded);	
						
						// status bar 
						var progressCount = parseInt((loaded / (numberOfItems))  * 100);
						jQuery('#progress_bar .ui-progress').animateProgress({
							progress : progressCount,
							duration : 300,
							easing   : 'swing'
						});
						
						// continue insert the rest of ID
						if(numberOfItems > curr_step) decoElite_insert_new_product(++curr_step);
						
						jQuery('#pcp-response-' + data.ID ).html( response.html );
						
					}else{
						alert(response.msg);
					}
				}
			});
		}
		
		// run for first 
		if(numberOfItems > 0) decoElite_insert_new_product(0);
	});
});


(function( $ ){
    // Simple wrapper around jQuery animate to simplify animating options.progress from your app
    // Inputs: options.progress as a percent, Callback
    // TODO: Add options and jQuery UI support.
    $.fn.animateProgress = function(options, callback) { 
        
        return this.each(function() {
            
            var progress = options.progress;
            $(this).animate({
                width: options.progress + '%'
            }, {
                duration: options.duration, 
        
                // swing or linear
                easing: options.easing,

                // this gets called every step of the animation, and updates the label
                step: function( progress ){
                    var labelEl = $('.ui-label'),
                    valueEl = labelEl.find('.value');
          
                    if (Math.ceil(progress) < 20 && $('.ui-label', this).is(":visible")) {
                        labelEl.hide();
                    }else{
                        if (labelEl.is(":hidden")) {
                            labelEl.fadeIn();
                        };
                    }
                    valueEl.text((progress.toFixed(1)) + '%');
                    
                },
                complete: function(scope, i, elem) {
                    if (callback) {
                        callback.call(this, i, elem );
                    };
                }
            });
        });
    };
})( jQuery );