<?php
// Make sure we don't expose any info if called directly
if ( ! function_exists( 'add_action' ) ) {
    die('Direct script access not allowed');
}

if(class_exists('decoElite_price_filter') != true) 
{
	class decoElite_price_filter extends WP_Widget 
	{
		private $the_theme = null;
		private $the_widget = array();
		private $alias = 'price_filter';
		
	    private $default_config = array(
	        'title' => ''
	    );
	    
	    public function __construct() 
	    {
			global $decoElite;
			//  
			$this->the_theme = $decoElite;
			$this->the_widget = $this->the_theme->cfg['widgets'][$this->alias];
			if( isset($this->the_widget) && count($this->the_widget) > 0 ){
				$widget_ops = array(
		            'classname'   => 'widget_' . $this->the_theme->alias . '_' . $this->alias, 
		            'description' => $this->the_widget[$this->alias]['description']
		        );
		        parent::__construct( $this->the_theme->alias . '-' . $this->alias, $this->the_theme->alias . ' - ' . $this->the_widget[$this->alias]['title'], $widget_ops);
			}
	    }
	
	    public function widget( $args, $instance )
	    {
	    	global $wpdb, $wp;
	        extract( $args );
			
			$values = get_option( 'widget_' . ( $this->the_theme->alias ) . '-' . $this->alias );
			if( isset($values["_multiwidget"]) ) unset($values["_multiwidget"]);
			$values = $values[key($values)]; 
			
			if( is_product() === true ) return;
			
			$min = floor( $wpdb->get_var(
				$wpdb->prepare('
					SELECT min(meta_value + 0)
					FROM %1$s
					LEFT JOIN %2$s ON %1$s.ID = %2$s.post_id
					WHERE meta_key IN ("' . implode( '","', apply_filters( 'woocommerce_price_filter_meta_keys', array( '_price', '_min_variation_price' ) ) ) . '")
					AND meta_value != ""
					AND (
						%1$s.ID IN (' . implode( ',', array_map( 'absint', WC()->query->layered_nav_product_ids ) ) . ')
						OR (
							%1$s.post_parent IN (' . implode( ',', array_map( 'absint', WC()->query->layered_nav_product_ids ) ) . ')
							AND %1$s.post_parent != 0
						)
					)
				', $wpdb->posts, $wpdb->postmeta
			) ) );
			
			
			$max = ceil( $wpdb->get_var(
				$wpdb->prepare('
					SELECT max(meta_value + 0)
					FROM %1$s
					LEFT JOIN %2$s ON %1$s.ID = %2$s.post_id
					WHERE meta_key IN ("' . implode( '","', apply_filters( 'woocommerce_price_filter_meta_keys', array( '_price' ) ) ) . '")
					AND (
						%1$s.ID IN (' . implode( ',', array_map( 'absint', WC()->query->layered_nav_product_ids ) ) . ')
						OR (
							%1$s.post_parent IN (' . implode( ',', array_map( 'absint', WC()->query->layered_nav_product_ids ) ) . ')
							AND %1$s.post_parent != 0
						)
					)
				', $wpdb->posts, $wpdb->postmeta
			) ) );
			$total = 8;
			$range = array();
			for($i = 0; $i < $total; $i++) {
				$range[] = pow($max,$i/($total - 1));
			}
			
			if ( '' == get_option( 'permalink_structure' ) ) {
				$form_action = remove_query_arg( array( 'page', 'paged' ), add_query_arg( $wp->query_string, '', home_url( $wp->request ) ) );
			} else {
				$form_action = preg_replace( '%\/page/[0-9]+%', '', home_url( trailingslashit( $wp->request ) ) );
			}

			$current_min = isset($_GET['min_price']) ? (int) $_GET['min_price'] : false;
			$current_max = isset($_GET['max_price']) ? (int) $_GET['max_price'] : false;
			?>
			
			<!-- Custom Text Widget -->
			<div class="custom-widget decoElite-widget de-price-filter">
				<h3><?php echo esc_attr($values["title"]); ?></h3>
				<div class="de-price-filter-content">
					<form method="get" action="<?php echo $form_action;?>">
						<input type="hidden" id="min_price" name="min_price" value="<?php echo esc_attr( $current_min );?>" data-min="<?php echo esc_attr( apply_filters( 'woocommerce_price_filter_widget_amount', $min ) );?>" />
						<input type="hidden" id="max_price" name="max_price" value="<?php echo esc_attr( $current_max );?>" data-max="<?php echo esc_attr( apply_filters( 'woocommerce_price_filter_widget_amount', $max ) );?>" />
						<?php
						$range = array_slice( $range, 2 );
						foreach ($range as $step_key => $step) {
							if( ($step_key - 1) < 0 ) {
								$prev_val = 0;
							}else{
								$prev_val = (int) $range[ $step_key - 1 ];
							}
							
							$max_price = wc_price( (int) $step );
							$last = false;
							if( count($range) - 1 == $step_key ){
								$max_price = esc_html__( '& &nbsp;Above', 'deco-elite' );
								$last = true;
							}
							
							$is_on = false;
							if( $current_min != false && $current_max != false ){
								if( $prev_val == $current_min && (int) $step == $current_max ){
									$is_on = true; 
								}
							}
						?>
							<label class="<?php echo $is_on === true ? 'on' : ''; ?>" data-min="<?php echo $prev_val;?>" data-max="<?php echo (int)$step;?>">
								<span class="de-fake-checkbox"><i class="fa fa-check"></i></span>
								<span><?php echo "<span>" . (  wc_price( $prev_val ) ) . "</span> " . ( $last == false ? '-' : '' ) . " <span>" . ( $max_price ) . "</span>";?></span>
							</label>
						<?php
						}
						?>
						
						<button type="submit" class="button"><?php echo esc_html__( 'Filter', 'deco-elite' );?></button>
					</form>
				</div>
			</div>
			<?php 
	    }
	    
	    public function parse_output($instance)
	    {
	        $html = array();
	        
	        return implode("\n", $html);
	    }
	    
	    public function update( $new_instance, $old_instance )
	    {   
	        $instance = $old_instance;
	        // Strip tags from title and name to remove HTML 
	        if( count($this->the_widget[$this->alias]['options']) > 0 ){
	        	foreach ($this->the_widget[$this->alias]['options'] as $key => $value) {
					$instance[$key] = esc_html( $_REQUEST[$key] );  
				}
	        } 
			
	        return $instance;
	    }
	
	    public function form( $instance ) 
	    {
	    	echo $this->the_theme->print_widget_fields( $this->the_widget[$this->alias]['options'], $instance );
	    }
	}
  
	// register the widgets
	add_action( 'widgets_init', create_function( '', 'return register_widget("decoElite_' . ( $GLOBALS['decoElite_current_widget'] ) . '");' ) );
}