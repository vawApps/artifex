<?php  
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Amazon Affiliate Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *	
**/
get_header();
global $wp_query, $decoElite; 
?>
	<div class="container-fluid de-template-blog">
		<div class="row">
			<?php
				$decoElite->coreFunctions->printSidebar( 'left', 'col-lg-3 col-md-3 col-sm-4 col-xs-12' );
			?>
				
			<!-- Main Container -->
			<section class="<?php echo $decoElite->coreFunctions->content_class( 'col-lg-9 col-md-9 col-sm-8 col-xs-12' );?>">
				<div class="blog-box">
					
					<span class="search_info">The search query returned <strong><?php echo $wp_query->found_posts; ?></strong> results.</span>
					
					<?php get_search_form(); ?>
					
					<?php if ( have_posts() ) { ?>
				
					<?php while( have_posts() ) : the_post(); ?>
					<div class="de_simple_post">
						<div class="de_simple_post_description">
							<h2><a href="<?php echo esc_url( get_permalink() ); ?>"><?php  the_title(); ?></a></h2>
							<div class="clear"></div>
							<div class="de_blog_short_desc"><?php the_excerpt(); ?></div>
							<a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_attr( get_permalink() ); ?></a>
						</div>
					</div>
					
					<div class="clearfix"></div>
					<hr class="de_line"/>
					<?php endwhile; ?>
					
					<?php if( $wp_query->post_count < $wp_query->found_posts ) { ?>
					<div class="row blog_row">
						<nav class="post-pagination woocommerce-pagination">
						<!-- Pagination -->
						<?php
							$big = 999999999; // need an unlikely integer
							echo paginate_links( array(
								'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
								'format' => '?paged=%#%',
								'current' => max( 1, get_query_var('paged') ),
								'total' => $wp_query->max_num_pages,
								'prev_next' => false,
								'type' => 'list'
							) );
							$paged = intval(get_query_var('paged'));
							$max_page = intval( $wp_query->max_num_pages );
							$posts_count = intval( $wp_query->found_posts );
							if( empty( $paged ) || $paged == 0 ) {
								$paged = 1; 
							}
						?>
						</nav>
						<p class="de-post-loop-count"><?php esc_html_e('Showing', 'deco-elite'); ?> <?php echo $paged; ?>-<?php echo $max_page; ?> of <?php echo $posts_count; ?> <?php esc_html_e('results', 'deco-elite'); ?></p>
					</div>
					<?php } ?>
					
					<?php } ?>
					
				</div>
			
				<div class="clearfix"></div>

			</section>
			
			<?php
				$decoElite->coreFunctions->printSidebar( 'right', 'col-lg-3 col-md-4 col-sm-4 col-xs-12' );
			?>
		</div>
	</div>

<?php get_footer(); ?>