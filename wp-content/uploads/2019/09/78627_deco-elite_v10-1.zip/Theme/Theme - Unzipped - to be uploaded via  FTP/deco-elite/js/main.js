;(function($) { "use strict";

	var decoElite_sidebar_menu = function( $elm ){
		
		// layout fix
		$elm.each(function(){
			var that = $(this);
			
			that.find(' > li > .children, > li > .sub-menu').each(function(){
				var submenu = $(this),
					parent = submenu.parent('li').eq(0);
				
				parent.append('<span class="accordsuffix">+</span>');
			}); 
		});
		
		$elm.find('> li').on('click', '.accordsuffix', function(){
			var that = $(this),
				parent = that.parent('li').eq(0),
				submenu = parent.children('ul.children, ul.sub-menu');
			
			if( ! parent.hasClass('open') ){
				
				// close last open menu
				//var last_open = $elm.find(".open");
				//last_open.children('ul.children').slideUp('fast');

				
				// open current submenu
				submenu.slideDown('fast');
				parent.addClass("open");
				that.html('-');
			} else {
				submenu.slideUp('fast');
				parent.removeClass("open");
				that.html('+');
			}
		});
	};
	
	function equalizeServiceBlock() {
		var service_block = $('.service-block'),
			serviceBlockHeight = 0;
		
		service_block.each(function() {
			if( $(this).height() > serviceBlockHeight ) {
				serviceBlockHeight = $(this).height();
			}
		});
		
		service_block.height( serviceBlockHeight );
	}
	
	var deAfterUpdateEffect = function( slider )
	{
		slider.find(".item").each(function(i){
			var that = $(this),
				speed = (i + 1) * 240;
			
			if( speed > 1200 ) speed = 1200;
			 
			that.animate({
				opacity: 1
			}, speed);
		});
		
		slider.css('background', 'none');
		slider.css('overflow', 'visible');
		
		if( slider.attr('id') == 'de_footer_partners' ){
			slider.css('background', '#fafafa');
		}
		
	}
	
	if( $('.de-main-nav.de-sticky-header').length > 0 ) {
		$(window).scroll(function () {
		    if( $(window).scrollTop() > $('.de-main-nav.de-sticky-header').offset().top && !($('.de-main-nav').hasClass('stick'))){
		    	$('.de-main-nav').addClass('stick');
		    } else if ($(window).scrollTop() == 0){
		    	$('.de-main-nav').removeClass('stick');
		    }
		});	
	}
	
	$(window).load(function() {
		equalizeServiceBlock();
	});
	
	$(document).ready(function() {
		$("ul.list-dots li").prepend('<i class="fa fa-circle-o"></i>');
		$("ul.list-arrow li").prepend('<i class="fa fa-arrow-right"></i>');
		$("ul.list-arrow-circle li").prepend('<i class="fa fa-arrow-circle-right"></i>');
		$("ul.list-angle li").prepend('<i class="fa fa-angle-right"></i>');
		$("ul.list-angle-double li").prepend('<i class="fa fa-angle-double-right"></i>');
		$("ul.list-chevron li").prepend('<i class="fa fa-chevron-right"></i>');
		
		$(".de-content .de_shop_sidebar .decoElite-widget h3").after('<div class="clear"></div>');
		
		var large_gallery = $("#de_image_large_gallery");
		
		$("a.prettyPhoto, a.woocommerce-main-image").prettyPhoto({
			social_tools : null,
			theme: 'facebook',
			show_title: false
		});
		
		// product gallery on single product
		$("#de_product_gallery .owl-item").first().addClass('de-product-redborder');
		
		$("#de_product_gallery").on('click', '.owl-item', function(e) {
			e.preventDefault();
	 		$("#de_product_gallery .owl-item").removeClass('de-product-redborder');
			var that = $(this),
			pos = that.index();
			
			that.addClass('de-product-redborder');
			 
			large_gallery.trigger('owl.goTo', pos);
		});
		 
		$(".de_gallery_container").on('click', '.de-next-slide', function(e){
			e.preventDefault();
			var that = $(this);
			that.parent().find('#de_product_gallery').animate({
				scrollTop: "100px"
			});
		});
		
		$(".de_gallery_container").on('click', '.de-prev-slide', function(e){
			e.preventDefault();
			var that = $(this);
			that.parent().find('#de_product_gallery').animate({
				scrollTop: "-100px"
			});
		});
		
		$('#myTab').on('click', 'a', function(e) {
			e.preventDefault()
			$(this).tab('show')
		})
		
		/*var itemscount = $("#de_related_products").find('.de-products').size();
		if( itemscount <= 2 ) {
			itemscount = 2;
		} else {
			itemscount = 3;
		} 
		
		$("#de_related_products").owlCarousel({
			navigation : true,
			pagination : false,
			items : itemscount,
			itemsDesktop : [1199,2],
			itemsDesktopSmall : [981,2],
			itemsTablet: [768,2],
			itemsTabletSmall: [600,1],
			itemsMobile : [479,1],
			itemsScaleUp: true,
			navigationText: ['<span><i class="fa fa-chevron-left"></i></span>', '<span><i class="fa fa-chevron-right"></i></span>'],
			afterUpdate: deAfterUpdateEffect( $("#de_related_products") )
		});*/
		
		$(".de-services-slider").owlCarousel({
			navigation : true,
			pagination : false,
			items : 1,
			itemsDesktop : [1199,1],
			itemsDesktopSmall : [981,1],
			itemsTablet: [768,1],
			itemsTabletSmall: [600,1],
			itemsMobile : [479,1],
			itemsScaleUp: true,
			autoPlay : $(this).data('slidespeed'),
			navigationText: ['<span><i class="fa fa-angle-left"></i></span>', '<span><i class="fa fa-angle-right"></i></span>'],
		})
		
		large_gallery.owlCarousel({
			navigation : false,
			pagination : false,
			singleItem	: true,
			items : 1,
			navigationText: ["<span></span>", "<span></span>"],
		});
	
		$("#de_blog_slider").owlCarousel({
			navigation : true,
			pagination : false,
			items : 1,
			itemsDesktop : [1199,1],
			itemsDesktopSmall : [981,1],
			itemsTablet: [768,1],
			itemsTabletSmall: [600,1],
			itemsMobile : [479,1],
			afterUpdate: deAfterUpdateEffect( $("#de_blog_slider") )
		});
		
		$(".list-blog-gallery").owlCarousel({
			navigation : true, // Show next and prev buttons
			singleItem: true,
			navigationText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
			
			afterUpdate: deAfterUpdateEffect( $("#de_blog_slider") )
		});
		
		$(".de-testimonials-slider").owlCarousel({
			navigation : true,
			pagination : false,
			items : 1,
			itemsDesktop : [1199,1],
			itemsDesktopSmall : [981,1],
			itemsTablet: [768,1],
			itemsTabletSmall: [600,1],
			itemsMobile : [479,1],
			autoPlay : $(this).find('.de-testimonials').data('slidespeed'),
			navigationText: ['<span><i class="fa fa-chevron-left"></i></span>', '<span><i class="fa fa-chevron-right"></i></span>'],
		});
	
		$("#de_footer_partners").owlCarousel({
			navigation : true,
			pagination : false,
			items : 5,
			navigationText: ["<span></span>", "<span></span>"],
			afterUpdate: deAfterUpdateEffect( $("#de_footer_partners") )
		});
	
		$('a.de_cart_item-close-btn, .product-remove a').tooltip({
			'placement' : 'bottom'
		});
		
		var sync1 = $("#de_project_image_gallery");
		var sync2 = $("#de-projects-gallery");
		
		$(window).load(function() {
			$("#de_project_image_gallery").owlCarousel({
				navigation : false,
				pagination : false,
				lazyLoad : true,
				singleItem : true,
				afterAction : syncPosition,
				responsiveRefreshRate : 200,
				autoHeight: true
			});
			
			$("#de-projects-gallery").owlCarousel({
				navigation : false,
				rewindNav : true,
				lazyLoad : true,
				pagination : false,
				items : 3,
				itemsDesktop : [1199,3],
				itemsDesktopSmall : [981,3],
				itemsTablet: [768,3],
				itemsTabletSmall: [600,0],
				itemsMobile : [479,0],
				itemsScaleUp: true,
				navigationText: [
					"<i class='fa fa-angle-left'></i>",
					"<i class='fa fa-angle-right'></i>"
				],
				responsiveRefreshRate : 100,
				afterInit : function(el){
					el.find(".owl-item").eq(0).addClass("synced");
					el.find('.owl-controls').show();
				}
			});
		});
		
		// tabs
		$('.de-tabs-links li a').each(function(){
			var that = $(this);
			that.on('click', function(e){
				e.preventDefault();
				var href = that.attr('href');
				$('.de-tabs-links li a').removeClass('de-active');
				that.addClass('de-active');
				that.parents('.de-other-services-tabs').find('.de-tabs-containers div').stop().animate({opacity:0}, 'fast', function() {
					that.parents('.de-other-services-tabs').find('.de-tabs-containers div').stop().hide();
					that.parents('.de-other-services-tabs').find('div' + href).stop().show().animate({opacity:1});
				});
			});
		});
		
		// accordion
		var all_acc_lings = $('.de-acc-links li a');
		all_acc_lings.each(function(){
			var that = $(this);
			if( that.hasClass('de-active') ) {
				that.find('i.plus-square').removeClass().addClass('minus-square'); 	
			}
			that.on('click', function(e){
				e.preventDefault();
				
				that.next().stop().slideToggle(function(){
					if( that.next().is(":visible") ) {
						that.addClass('de-active');
						that.find('i.plus-square').removeClass().addClass('minus-square');
					} else {
						that.removeClass('de-active');
						that.find('i.minus-square').removeClass().addClass('plus-square');
					}
				});
			});
		});
		
		// our process steps animation
		if( $(window).width() >= 768 ) {
			$('.de-our-process .de-prod-desc .de-step').each(function(i){
				
				var that = $(this),
					hr = that.find("hr"),
					stepNumber = that.find(".de-step-number"),
					stepText = that.find(".de-step-text");
					stepNumber.hide();
					stepText.hide();
				
				var stepAnimate = function(){
					hr.animate({ width: '72px' }, { duration: 1000, 
						 start: function(){ 
							 	hr.css('border-top', '1px solid #fff'); 
							 	stepNumber.fadeIn('normal');
							 	stepText.fadeIn('normal');
							},
					   	 complete: function(){ 
						   	 	hr.css('borderborder-top', '1px solid #fff');
						   	 	stepNumber.css('cssText', 'color: #fff; border: 1px solid #fff;'); 
						   	 	stepText.css('color', '#fff');
					   		}
					    }
					  			);
					if( i === 4 ) {
						stepNumber.fadeIn('normal').css('cssText', 'color: #ffcd06; border: 1px solid #ffcd06;');
						stepText.fadeIn('normal').css('color', '#ffcd06');
					}
				}
				setTimeout(stepAnimate, i*1000);
			});
		}
	
		function syncPosition(el){
			var current = this.currentItem;
			$("#de-projects-gallery")
			.find(".owl-item")
			.removeClass("synced")
			.eq(current)
			.addClass("synced")
			if($("#de-projects-gallery").data("owlCarousel") !== undefined){
				center(current)
			}
		}
			 
		$("#de-projects-gallery").on("click", ".owl-item", function(e){
			e.preventDefault();
			var number = $(this).data("owlItem");
			sync1.trigger("owl.goTo",number);
		});
		
		function center(number){
			var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
			var num = number;
			var found = false;
			for(var i in sync2visible){
				if(num === sync2visible[i]){
					var found = true;
				}
			}
			 
			if(found===false){
				if(num>sync2visible[sync2visible.length-1]){
					sync2.trigger("owl.goTo", num - sync2visible.length+2)
				}else{
					if(num - 1 === -1){
						num = 0;
					}
					sync2.trigger("owl.goTo", num);
				}
			} else if(num === sync2visible[sync2visible.length-1]){
				sync2.trigger("owl.goTo", sync2visible[1])
			} else if(num === sync2visible[0]){
				sync2.trigger("owl.goTo", num-1)
			}
		}
		
		$(window).load(function() {
			$('.de-plus-product').each(function(){
				var that 	= $(this),
					//top 	= that.data('_top'),
					//left 	= that.data('_left'),
					parent	= that.parents('.owl-item').eq(0),
					firstparent = that.parent().eq(0),
					img = firstparent.find('> img'),
					details	= that.next('.de-plus-product-preview');
		 
			    var psize	= {
		            width       : parseInt( parent.width() ),
					height      : parseInt( parent.height() )
				}, imgsize = {
				    width       : parseInt( img.width() ),
				    height      : parseInt( img.height() )
				};
				//console.log( parent, psize, img, imgsize );
					
			    var objpos = that.data('objpos');
		        //objpos = JSON && JSON.parse( objpos ) || $.parseJSON( objpos );
		        objpos = $.extend(objpos, {
		           _left      : parseFloat( ( objpos.left * 100 ) / objpos.iw ).toFixed(3), 
		           _top       : parseFloat( ( objpos.top * 100 ) / objpos.ih ).toFixed(3)
		        });
		        objpos = $.extend(objpos, {
		           _left_px      : parseInt( parseFloat( ( objpos._left * imgsize.width ) / 100 ) ), 
		           _space_left   : parseInt( ( psize.width - imgsize.width ) / 2 ),
		        });
		        objpos = $.extend(objpos, {
		           _left_px      : parseInt( objpos._left_px + objpos._space_left ), 
		        });
		        //console.dir( objpos );
		
				that.css({
					'left'   : objpos._left_px + 'px', //objpos._left + '%'
		            'top'    : objpos._top + '%'
				});
				
		        var boxSize = {
		            w     : details.outerWidth() + 40,
		            h     : details.outerHeight(),
		        }
		        boxSize = $.extend(boxSize, {
		            _w    : parseFloat( ( boxSize.w * 100 ) / psize.width ).toFixed(3),
		            _h    : parseFloat( ( boxSize.h * 100 ) / psize.height ).toFixed(3),
		        });
		        //console.log( 'boxSize' ); console.dir( boxSize ); 
				
				// test if hotpoint details exit horizontal
				//if( ( details.outerWidth() + 40 + parseInt(left) ) > psize.width ) {
		        if( parseFloat( parseFloat( boxSize._w ) + parseFloat( objpos._left ) ).toFixed(2) > 100.00 ) {
					details.addClass("open-left");
				}
				
				// test if hotpoint details exit vertical
				//if( ( details.outerHeight() + 40 + parseInt(top) ) > psize.height ) {
		        if( parseFloat( parseFloat( boxSize._h ) + parseFloat( objpos._top ) ).toFixed(2) > 100.00 ) {
					details.addClass("open-top");
				}
				
				$(this).on('click', function(e){
					e.preventDefault();
					var that = $(this),
						details = that.next('.de-plus-product-preview');
					
					$(".de-plus-product-preview").slideUp();
					if( details.hasClass('open-left') ){ 
						details.css({
							'margin-left': "-" + ( details.outerWidth() -24 ) + "px"
						});
					}
					
					if( details.hasClass('open-top') ){
						details.css({
							'margin-top': "-" + ( details.outerHeight() - 24 ) + "px"
						});
					}
					
		            details.css({
		                'left'   : objpos._left_px + 'px', //objpos._left + '%'
		                'top'    : objpos._top + '%'
		            });
					details.slideToggle( 245 );
				});
				
				
				$(this).next().on('click', '.de-prod-prev-close',function(e){
					e.preventDefault();
					$(this).parent().slideUp();
				});
				
				/*$(this).next('.de-plus-product-preview').on('click', '.de-prod-add-to-cart > a', function(e){
					//e.preventDefault();
				});*/
				
			});
		});
		
		$('body').on('click', '#de-click-view-prod', function(e){
			e.preventDefault();
			$('.de-plus-product').each(function(){
				$(this).toggleClass('pulse_holder');
			});
		});
		
		$('body').on('click', '#de-panorama', function(e){
			e.preventDefault();
		    $('#panoramaModal').modal({show:true})
		});
	
		$("#de_slider_range").slider({
			range : true,
			min : 0,
			max : 1800,
			values : [0, 900],
			slide : function(event, ui) {
				$("#de_amount").val("$" + ui.values[0] + " - $" + ui.values[1]);
			}
		});
		$("#de_amount").val("$" + $("#de_slider_range").slider("values", 0) + " - $" + $("#de_slider_range").slider("values", 1));
		
		$(".nav-tabs").on('click', 'li a', function(e){
			e.preventDefault();
			
			var that = $(this);
			
			if( !that.parent("li").hasClass('active') ){
				
				$(".nav-tabs").find('li.active').removeClass('active');
				that.parent('li').addClass("active");
				
				$(".entry-content.active").removeClass('active');
				$("#" + that.attr('href').replace("#", "")).addClass("active")
			}
		});
		
		// Save Rating
		$('.rating-input').on('click', 'span', function(e)
		{
			var that = $(this),
				value = that.data('value'),
				parent = that.parent('.rating-input').find("input");
				
			jQuery.post(ajaxurl, {
				'action': 'decoElite_save_stars',
				'value': value,
				'productid': parent.data('productid')
			}, function() {
			}, 'json');
		});
		
		var isMobile = window.matchMedia("only screen and (max-width: 760px)");
		
		if( isMobile.matches != true ) {
			$(".de_custom_select").each(function(){
				var that = $(this),
					select_box = that.find("select"),
					list = that.find('ul'),
					options = select_box.find('option'),
					options_size = options.size();
				
				// check if don't have any selected item
				var has_selected = true;
				if( options.find('li:selected').size() == 0 ){
					has_selected = false;
				}
				
				options.each(function(i){
					var li = $(this);
					list.append('<li><a href="#' + ( li.val() ) + '">' + ( li.text() ) + '</a></li>');
					
					if( i < (options_size - 1) )
						list.append('<li class="divider"></li>');
					
					if( li.attr('selected') == 'selected' || ( has_selected == false && i == 0 ) ){
						that.find("span.current_value").text( li.text() );
					}
				});
			});
			
			$(".de_custom_select").on('click touchstart', "a", function(e){
				e.preventDefault();
				
				var that = $(this),
					alias = that.attr("href").replace("#", ''),
					container = that.parents('.de_custom_select').eq(0),
					select_box = container.find("select");
				
				var selected_option = select_box.find('option[value="' + ( alias ) + '"]');
				
				container.find("span.current_value").text( selected_option.text() );
				selected_option.prop('selected', true);
				
				select_box.trigger( "change" );
				
				if( select_box.hasClass('orderby') ){
					select_box.parent('.woocommerce-ordering').submit();
				}
			});
		} else {
			$('.de_custom_select select').css('cssText', 'display:inline;');
			$('.de_custom_select .btn.dropdown-toggle').hide();
		}
		
		
		// woocommerce widget filters
		$('.product_list_widget > li > a > img').each(function() {
			$(this).parent().before(this);
			$(this).wrap('<div class="product_list_widget_img_wrapper" />');
		});
		
		$('.product_list_widget > li > a').each(function() {
			if ($.trim($(this).text()).length > 30 ) { $(this).text($.trim($(this).text()).substr(0, 30) + "..."); }
		});
		
		$('.product_list_widget > li > .product_list_widget_img_wrapper').each(function() {
			$(this).parent().children('a').prepend(this);
		});
		
		// woocommerce product categoies, create accordition
		decoElite_sidebar_menu( $(".widget_product_categories .product-categories") );
		decoElite_sidebar_menu( $(".widget_categories ul") );
		decoElite_sidebar_menu( $(".widget_nav_menu ul") );
		
		$(".de_small-cart .cart-details-wrapper").each(function(){
			var that = $(this);
			
			that.height( (that.find(".de_small_cart_items li").size() * 94) + 110 );
			
			if( that.find(".de_small_cart_items .empty").size() > 0 ){
				that.height( 32 );
			}
		});
		
		$("#top_nav .sub-menu").parent('li').append( '<i class="icon icon_arrow-menu"></i>' );
		
		$("input[type=number]")
			.attr("type", "text")
			.show();
		
		// projects 
		var isotope_container = $('.projects-box');
		
	    isotope_container.isotope({
	        itemSelector : '.de-project-item-iso'
	    });
	    
	    $('.projects-filter').on('click', 'a', function(e){
	    	if( !$(this).parents().eq(1).hasClass('archive-filter') ) {
		    	e.preventDefault();
		    	
		        $('.projects-filter a').removeClass('active');
		        $(this).addClass('active');
		        var selector = $(this).attr('data-filter');
		        isotope_container.isotope({ filter: selector });
		        
		        return false;
			}
	    });
	    
	    $('#de_products_listitems .woocommerce.product.compare-button a, #de_related_products .woocommerce.product.compare-button a, .page-template-template-home-php .woocommerce.product.compare-button a, #de_complementary_products .woocommerce.product.compare-button a').html('<i class="fa fa-clipboard"></i>');
	    
	    $('#de_products_listitems .add_to_wishlist, #de_related_products .add_to_wishlist, .page-template-template-home-php .add_to_wishlist, #de_complementary_products .add_to_wishlist').html('<i class="fa fa-heart"></i>');
	    
	    $('#de_products_listitems .yith-wcwl-wishlistexistsbrowse a, #de_products_listitems .yith-wcwl-wishlistaddedbrowse a, #de_related_products .yith-wcwl-wishlistexistsbrowse a, #de_related_products .yith-wcwl-wishlistaddedbrowse a, .page-template-template-home-php .yith-wcwl-wishlistexistsbrowse a, .page-template-template-home-php .yith-wcwl-wishlistaddedbrowse a, #de_complementary_products .yith-wcwl-wishlistexistsbrowse a, #de_complementary_products .yith-wcwl-wishlistaddedbrowse a').html('<i class="fa fa-heart"></i>');
	    
	    $('.de-main-nav .de-cart .de-cart-details .de-cart-details-products .de-cart-product .de-delete-product a').html('<i class="fa fa-trash"></i>');
	    
	    $('#de_products_listitems .de_buttons_wrapper, .page-template-template-home-php .de_buttons_wrapper').each(function(){
	    	$(this)
	    	.mouseover(function(){
	    		$(this).parent().find('.yith-wcwl-add-to-wishlist').stop().animate({"left": '0px'});
	    		$(this).parent().find('.woocommerce.product.compare-button').stop().animate({"right": '0px'});	
	    		$(this).parent().find('.yith-wcwl-wishlistexistsbrowse a').stop().animate({"left": '0px'});
	    		$(this).parent().find('.yith-wcwl-wishlistaddedbrowse a').stop().animate({"left": '0px'});
	    	})
	    	.mouseout(function(){
				$(this).parent().find('.yith-wcwl-add-to-wishlist').stop().animate({"left": '34px'});
				$(this).parent().find('.woocommerce.product.compare-button').stop().animate({"right": '34px'});	
				$(this).parent().find('.yith-wcwl-wishlistexistsbrowse a').stop().animate({"left": '34px'});
				$(this).parent().find('.yith-wcwl-wishlistaddedbrowse a').stop().animate({"left": '34px'});
	    	});
	    });
	    
	    $('.single-product .de_description .add_to_wishlist, .single-product .de_description .yith-wcwl-wishlistaddedbrowse a, .single-product .de_description .yith-wcwl-wishlistexistsbrowse a').prepend('<i class="fa fa-heart"></i>'); 
	    $('.single-product .de_description .yith-wcwl-add-to-wishlist').next().hide();
	    
	    $('.wishlist_table .product-remove a.remove').html('<i class="fa fa-trash"></i>');
	    
	    /*Fullscreen trigger*/
		// open in fullscreen
		$('body').on('click', '.requestfullscreen', function() {
			$('#fullscreen').fullscreen();
			return false;
		});
	
		// document's event
		$(document).on('fscreenchange', function(e, state, elem) {
			// if we currently in fullscreen mode
			if ($.fullscreen.isFullScreen()) {
				$('.requestfullscreen').hide();
				$('.exitfullscreen').show();
			} else {
				$('.requestfullscreen').show();
				$('.exitfullscreen').hide();
			}
	
			$('#state').text($.fullscreen.isFullScreen() ? '' : 'not');
		});
		
		// caption for transparent effect layers in revslider
		$('.de-transparent').each(function(){
			$(this).append('<p class="de-transparent-title">' + $(this).attr('title') + '</p>');
			$(this).mouseenter(
			function(){
				$(this).find('p.de-transparent-title').fadeIn('normal');
			}
			);
			$(this).mouseleave(
				function(){
					$(this).find('p.de-transparent-title').fadeOut('normal');
				}
			); 
		});
		
		
		$(".de-price-filter").on('click', 'label',function(e){
			e.preventDefault();
			
			var that = $(this),
				min = that.data('min'),
				max = that.data('max'); 
			
			$(".de-price-filter .on").removeClass('on');
			that.addClass('on');
			
			$("#min_price").val( min );
			$("#max_price").val( max );
		});
		
		if( typeof $('#de-bd-wrap') != 'undefined' && $('#de-bd-wrap').length > 0 ) {
			$('#de-bd-wrap').scrollpanel({
				prefix: 'sp-'
			});
		}
		
		/* entire block clickable for header contact bopresent in all interior pages) */ 
		$("body").on('click', '.block-click', function(){
		    window.location=$(this).find("a").attr("href");
		return false;
		});
		
		// init Google Map
		var map_elm = $('div.decoElite-map');
		if( map_elm.length > 0 ) {
			initDecoEliteMap(map_elm);
		}
	});
	
	;( function( window ) {
		
		'use strict';
		
		// EventListener | @jon_neal | //github.com/jonathantneal/EventListener
		!window.addEventListener && window.Element && (function () {
		   function addToPrototype(name, method) {
			  Window.prototype[name] = HTMLDocument.prototype[name] = Element.prototype[name] = method;
		   }
		 
		   var registry = [];
		 
		   addToPrototype("addEventListener", function (type, listener) {
			  var target = this;
		 
			  registry.unshift({
				 __listener: function (event) {
					event.currentTarget = target;
					event.pageX = event.clientX + document.documentElement.scrollLeft;
					event.pageY = event.clientY + document.documentElement.scrollTop;
					event.preventDefault = function () { event.returnValue = false };
					event.relatedTarget = event.fromElement || null;
					event.stopPropagation = function () { event.cancelBubble = true };
					event.relatedTarget = event.fromElement || null;
					event.target = event.srcElement || target;
					event.timeStamp = +new Date;
		 
					listener.call(target, event);
				 },
				 listener: listener,
				 target: target,
				 type: type
			  });
		 
			  this.attachEvent("on" + type, registry[0].__listener);
		   });
		 
		   addToPrototype("removeEventListener", function (type, listener) {
			  for (var index = 0, length = registry.length; index < length; ++index) {
				 if (registry[index].target == this && registry[index].type == type && registry[index].listener == listener) {
					return this.detachEvent("on" + type, registry.splice(index, 1)[0].__listener);
				 }
			  }
		   });
		 
		   addToPrototype("dispatchEvent", function (eventObject) {
			  try {
				 return this.fireEvent("on" + eventObject.type, eventObject);
			  } catch (error) {
				 for (var index = 0, length = registry.length; index < length; ++index) {
					if (registry[index].target == this && registry[index].type == eventObject.type) {
					   registry[index].call(this, eventObject);
					}
				 }
			  }
		   });
		})();
	
		// http://stackoverflow.com/a/11381730/989439
		function mobilecheck() {
			var check = false;
			(function(a){if(/(android|ipad|playbook|silk|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4)))check = true})(navigator.userAgent||navigator.vendor||window.opera);
			return check;
		}
		
		// http://www.jonathantneal.com/blog/polyfills-and-prototypes/
		!String.prototype.trim && (String.prototype.trim = function() {
			return this.replace(/^\s+|\s+$/g, '');
		});
	
		function UISearch( el, options ) {	
			this.el = el;
			this.inputEl = el.querySelector( 'form > input.de-search-input' );
			this._initEvents();
		}
	
		UISearch.prototype = {
			_initEvents : function() {
				var self = this,
					initSearchFn = function( ev ) {
						ev.stopPropagation();
						// trim its value
						self.inputEl.value = self.inputEl.value.trim();
						
						if( !classie.has( self.el, 'de-search-open' ) ) { // open it
							ev.preventDefault();
							self.open();
						}
						else if( classie.has( self.el, 'de-search-open' ) && /^\s*$/.test( self.inputEl.value ) ) { // close it
							ev.preventDefault();
							self.close();
						}
					}
	
				this.el.addEventListener( 'click', initSearchFn );
				this.el.addEventListener( 'touchstart', initSearchFn );
				this.inputEl.addEventListener( 'click', function( ev ) { ev.stopPropagation(); });
				this.inputEl.addEventListener( 'touchstart', function( ev ) { ev.stopPropagation(); } );
			},
			open : function() {
				var self = this;
				classie.add( this.el, 'de-search-open' );
				// focus the input
				this.inputEl.focus();
				
				// close the search input if body is clicked
				var bodyFn = function( ev ) {
					self.close();
					this.removeEventListener( 'click', bodyFn );
					this.removeEventListener( 'touchstart', bodyFn );
				};
				document.addEventListener( 'click', bodyFn );
				document.addEventListener( 'touchstart', bodyFn );
			},
			close : function() {
				this.inputEl.blur();
				$('#de-search-results').hide();
				classie.remove( this.el, 'de-search-open' );
				// clear search input
				$('#de-search input#search').val('');
			}
		}
	
		// add to global namespace
		window.UISearch = UISearch;
	
	} )( window );
	 
	new UISearch( document.getElementById( 'de-search' ) );
	
	// Live Search
	function search() {
		var query_value = $('#de-search input#search').val();
		$('b#search-string').text(query_value);
		if(query_value !== '' && $){
			jQuery.post(ajaxurl, {
				'action': 'decoElite_live_search',
				'cache': false,
				'query': query_value,
			},function(html) {
				$("ul#results").html(html);
				$('#de-search-results').show();
			});
			
		}return false;    
	}
	
	$("#de-search input#search").on("keyup", function(e) {
		// Set Timeout
		clearTimeout($.data(this, 'timer'));
	
		// Set Search String
		var search_string = $(this).val();
	
		// Do Search
		if (search_string == '') {
			$("ul#results").fadeOut();
			$('h4#results-text').fadeOut();
		}else{
			$("ul#results").fadeIn();
			$('h4#results-text').fadeIn();
			$(this).data('timer', setTimeout(search, 100));
		};
	});
	
	function initDecoEliteMap(map_elm) {
		var geocoder = new google.maps.Geocoder();
		
		var customMapType = new google.maps.StyledMapType([
	      {
	        stylers: [
	          {saturation : (map_elm.data('black_and_white') == true ? -100 : 0)}
	        ]
	      }
	    ], {
	      	name: 'DecoElite'
	  	});
	  	
	  	var customMapTypeId = 'decoElite_style';
	  	 
	  	if( map_elm.data('hide_controls') == true ) {
	  		var map = new google.maps.Map(document.getElementById('decoElite-map'), {
				zoom: map_elm.data('zoom'),
				panControl: false,
				zoomControl: false,
				mapTypeControl: false,
				scaleControl: false,
				streetViewControl: false,
				overviewMapControl: false
		  	});
	  	}else{
	  		var map = new google.maps.Map(document.getElementById('decoElite-map'), {
				zoom: map_elm.data('zoom')
		  	});
	  	}
	  	
	  	
	  	geocoder.geocode({'address': map_elm.data('address')}, function(results, status) {
			if (status === google.maps.GeocoderStatus.OK) {
				map.setCenter(results[0].geometry.location);
				var marker = new google.maps.Marker({
					map: map,
					position: results[0].geometry.location,
					icon: map_elm.data('marker')
				});
			} else {
				alert('Geocode was not successful for the following reason: ' + status);
			}
		});
		  
		map.mapTypes.set(customMapTypeId, customMapType);
		map.setMapTypeId(customMapTypeId);
	}
	
})(jQuery);