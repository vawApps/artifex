<?php 
/**
 * decoEliteProjects class
 * ================
 *
 * @author		Andrei Dinca, AA-Team
 * @version		1.0
 * @access 		public
 * @return 		void
 */  
global $decoElite;
 
// check if you have plugin install or not
if( file_exists( $decoElite->cfg['paths']['plugin_dir_path'] . '/projects/init.php' ) ) {
	load_template( $decoElite->cfg['paths']['plugin_dir_path'] . '/projects/init.php', true );
}