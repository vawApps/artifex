<?php
/**
 * Mini-cart
 *
 * Contains the markup for the mini-cart, used by the cart widget
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $woocommerce, $decoElite;
?>

<?php do_action( 'woocommerce_before_mini_cart' ); ?>

		<?php if ( sizeof( WC()->cart->get_cart() ) > 0 ) : ?>

			<?php
				foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
					$_product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
					$product_id   = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
	
					if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
	
						$product_name  = apply_filters( 'woocommerce_cart_item_name', $_product->get_title(), $cart_item, $cart_item_key );
						$thumbnail     = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image('thumbnail'), $cart_item, $cart_item_key );
						$product_price = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
						?>
							<div class="de-cart-product"><!-- start of .de-cart-product -->
					          <div class="de-cart-img">
					          		<a href="<?php echo get_permalink( $product_id ); ?>">
										<?php echo str_replace( array( 'http:', 'https:' ), '', $thumbnail ); ?>
									</a>
					          </div>
					          <div class="de-cp-title">
					            <a href="<?php echo get_permalink( $product_id ); ?>"><?php echo $product_name;?></a>
					            <p><span><?php echo $product_price;?></span></p>
					          </div>
					          <div class="de-delete-product"><a href="<?php echo WC()->cart->get_remove_url( $cart_item_key );?>">x</a></div>
					        </div><!-- END of .de-cart-product -->
						<?php
					}
				}
			?>
	
		<?php else : ?>
	
			<p class="empty"><?php esc_html_e( 'No products in the cart.', 'woocommerce' ); ?></p>
	
		<?php endif; ?>
		
		<?php if ( sizeof( WC()->cart->get_cart() ) > 0 ) : ?>
		<div class="de-total-cart-widget">
			<p class="total"><strong><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?>:</strong> <?php echo WC()->cart->get_cart_subtotal(); ?></p>
			<?php do_action( 'woocommerce_widget_shopping_cart_before_buttons' ); ?>
			<p class="buttons">
				<a href="<?php echo WC()->cart->get_cart_url(); ?>" class="button wc-forward"><?php esc_html_e( 'View Cart', 'woocommerce' ); ?></a>
				<a href="<?php echo WC()->cart->get_checkout_url(); ?>" class="button checkout wc-forward"><?php esc_html_e( 'Checkout', 'woocommerce' ); ?></a>
			</p>
		</div>
		<?php endif; ?>

<?php do_action( 'woocommerce_after_mini_cart' ); ?>