<?php
/**
 * Dummy module return as json_encode
 * http://www.aa-team.name
 * =======================
 *
 * @author		Andrei Dinca, AA-Team
 * @version		0.1 - in development mode
 */
global $decoElite;

$layout_options = array(
	$GLOBALS['decoElite_tried_module']['db_alias'] => array(
	
		/* define the form_sizes  box */
		'config' => array(
			'title' 	=> 'General Settings',
			//'icon' 		=> '{theme_folder_uri}assets/menu_icon.png',
			'size' 		=> 'grid_4', // grid_1|grid_2|grid_3|grid_4
			'header' 	=> false, // true|false
			'toggler' 	=> false, // true|false
			'buttons' 	=> true, // true|false
			'style' 	=> 'panel', // panel|panel-widget
			
			// tabs
			'tabs'	=> array(
				'__tab1'	=> array(esc_html__('General SETUP', 'deco-elite'), 'favicon,comments_on_pages,project_page,wishlist_page'),
				'__tab2'	=> array(esc_html__('Header', 'deco-elite'), 'sticky_header,enable_top_navigation,enable_cart,logo,logo_width,logo_height,logo_bg_color,logo_bg_color_select,phone_support, top_menu_background, top_menu_text_color, top_menu_font_family, top_menu_font_size, main_menu_background, main_menu_text_color,main_menu_hover_text_color,main_menu_font_family, main_menu_font_size, main_menu_top_padding, main_menu_bottom_padding,main_menu_element_margin,main_menu_element_padding'),
				'__tab3'	=> array(esc_html__('Footer', 'deco-elite'), 'footer_container_background, footer_logo_bg_color,footer_logo_bg_color_select,footer_logo,footer_logo_width,footer_logo_height,footer_container_text_color, footer_disclaimer_background, footer_disclaimer_text_color,footer_font_size, footer_font_family, footer_copyright,footer_cols,enable_footer_sidebar'),
				'__tab4'	=> array(esc_html__('Shop', 'deco-elite'), 'products_per_page, enable_ratings,store_description,store_image'),
				'__tab5'	=> array(esc_html__('Product Page', 'deco-elite'), 'enable_complementary_products, enable_other_collections'),
				'__tab6'	=> array(esc_html__('My Account', 'deco-elite'), 'reg_content, login_content'),
				'__tab7'	=> array(esc_html__('Styling', 'deco-elite'), 'body_color,primary_color,secondary_color,background_color, background_image, background_fit'),
				'__tab8'	=> array(esc_html__('Typography', 'deco-elite'), 'main_font, headers_font,intro_font'),
				'__tab9'	=> array(esc_html__('Social SETUP', 'deco-elite'), 'fb_like_share,fb_app_id'),
			),
			
			// create the box elements array
			'elements'	=> array(
				/* tab 1 */
				'favicon' => array(
					'type' 			=> 'upload_image_wp',
					'size' 			=> 'large',
					'force_width'	=> '80',
					'preview_size'	=> 'large',	
					'value' 		=> esc_html__('Favicon Image', 'deco-elite'),
					'title' 		=> esc_html__('Favicon', 'deco-elite'),
					'desc' 			=> esc_html__('Upload your favicon using the native media uploader', 'deco-elite'),
				),
				
				'comments_on_pages' => array(
					'type' 		=> 'select',
					'std' 		=> 'no',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Enable comments on pages', 'deco-elite'),
					'desc'		=> esc_html__('Enable comments section on pages? Default is NO.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				// TODO: check where used
				'project_page' => array(
					'type' 		=> 'select_pages',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Project page', 'deco-elite')
				),
				
				'wishlist_page' => array(
					'type' 		=> 'select_pages',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Wishlist page', 'deco-elite'),
					'desc'		=> esc_html__('Displayed in the header section of the site.', 'deco-elite'),
				),
				
				/* tab 2 */
				'sticky_header' => array(
					'type' 		=> 'select',
					'std' 		=> 'yes',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Enable Sticky Header', 'deco-elite'),
					'desc'		=> esc_html__('Enable Sticky Header? Default is YES.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				'enable_top_navigation' => array(
					'type' 		=> 'select',
					'std' 		=> 'yes',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Enable Top Navigation', 'deco-elite'),
					'desc'		=> esc_html__('Enable Top Navigation? Default is YES.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				'enable_cart' => array(
					'type' 		=> 'select',
					'std' 		=> 'yes',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Enable Cart', 'deco-elite'),
					'desc'		=> esc_html__('Enable Cart? Default is YES.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				'logo' => array(
					'type' 			=> 'upload_image_wp',
					'size' 			=> 'large',
					'force_width'	=> '80',
					'preview_size'	=> 'large',	
					'value' 		=> esc_html__('Upload Image', 'deco-elite'),
					'title' 		=> esc_html__('Logo', 'deco-elite'),
					'desc' 			=> esc_html__('Upload your Logo using the native media uploader', 'deco-elite'),
				),
				
				'logo_width' => array(
					'type' 		=> 'text',
					'std' 		=> '150px',
					'size' 		=> 'large',
					'title'		=> esc_html__('Logo Width', 'deco-elite'),
					'desc'		=> esc_html__('Logo width in pixels. Default value is 150px.', 'deco-elite')
				),
				
				'logo_height' => array(
					'type' 		=> 'text',
					'std' 		=> '90px',
					'size' 		=> 'large',
					'title'		=> esc_html__('Logo Height', 'deco-elite'),
					'desc'		=> esc_html__('Logo height in pixels. Default value is 90px.', 'deco-elite')
				),
				
				'logo_bg_color' => array(
					'type' 		=> 'select',
					'std' 		=> 'yes',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Enable background color on header logo', 'deco-elite'),
					'desc'		=> esc_html__('Enable background color on header logo? Default is YES. Disable if you do not want a background color for your logo.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				'logo_bg_color_select' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#e93712',
					'size' 		=> 'large',
					'title'		=> esc_html__('Header Logo Background Color', 'deco-elite'),
					'desc'		=> esc_html__('The Header Logo background color. Choose from the color picker. The default color is: #e93712', 'deco-elite')
				),
				
				/*'slider_theme' => array(
					'type' 		=> 'select',
					'std' 		=> 'slider_theme1',
					'size' 		=> 'large',
					'force_width'=> '200',
					'title'		=> esc_html__('Choose homepage slider theme', 'deco-elite'),
					'desc'		=> esc_html__('Choose slider theme. Default is Theme 1.', 'deco-elite'),
					'options'	=> array(
						'slider_theme1' => 'Slider Theme 1',
						'slider_theme2' => 'Slider Theme 2',
					)
				),*/
				
				'phone_support' => array(
					'type' 		=> 'text',
					'std' 		=> 'Call Us : 0123-456-789',
					'size' 		=> 'large',
					'title'		=> esc_html__('Phone Support text', 'deco-elite'),
					'desc'		=> esc_html__('The text for header Phone Support box', 'deco-elite')
				),
				
				'top_menu_background' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#39201b',
					'size' 		=> 'large',
					'title'		=> esc_html__('Top Menu Background Color', 'deco-elite'),
					'desc'		=> esc_html__('The top menu background color. Choose from the color picker. The default color is: #29150a', 'deco-elite')
				),
				
				'top_menu_text_color' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#eaeaea',
					'size' 		=> 'large',
					'title'		=> esc_html__('Top Menu Text Color', 'deco-elite'),
					'desc'		=> esc_html__('The top menu text color. Choose from the color picker. The default color is: #d6cfcb', 'deco-elite')
				),
				
				'top_menu_font_size' => array(
					'type' 		=> 'text',
					'std' 		=> '10px',
					'size' 		=> 'large',
					'title'		=> esc_html__('The Top Menu Font Size', 'deco-elite'),
					'desc'		=> esc_html__('The font size for the top menu in pixels. Default value is 11px.', 'deco-elite')
				),
				
				'top_menu_font_family' => array(
					'type' 		=> 'google-font-select',
					'std' 		=> 'Montserrat',
					'size' 		=> 'large',
					'force_width'	=> '150',
					'title'		=> esc_html__('Top Menu Font-Family', 'deco-elite'),
					'desc'		=> esc_html__('Select the Font-Family for your top menu. Default is Montserrat', 'deco-elite'),
				),
				
				'main_menu_background' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#ffffff',
					'size' 		=> 'large',
					'title'		=> esc_html__('Main Menu Background Color', 'deco-elite'),
					'desc'		=> esc_html__('The main menu background color. Choose from the color picker. The default color is: #ffffff', 'deco-elite')
				),
				
				'main_menu_text_color' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#252525',
					'size' 		=> 'large',
					'title'		=> esc_html__('Main Menu Text Color', 'deco-elite'),
					'desc'		=> esc_html__('The main menu text color. Choose from the color picker. The default color is: #101010', 'deco-elite')
				),
				
				'main_menu_hover_text_color' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#e93712',
					'size' 		=> 'large',
					'title'		=> esc_html__('Main Menu Hover Text Color', 'deco-elite'),
					'desc'		=> esc_html__('The main menu element hover text color. Choose from the color picker. The default color is: #e93712', 'deco-elite')
				),
				
				'main_menu_font_size' => array(
					'type' 		=> 'text',
					'std' 		=> '14px',
					'size' 		=> 'large',
					'title'		=> esc_html__('The Main Menu Font Size', 'deco-elite'),
					'desc'		=> esc_html__('The font size for the main menu in pixels. Default value is 14px.', 'deco-elite')
				),
				
				'main_menu_font_family' => array(
					'type' 		=> 'google-font-select',
					'std' 		=> 'Montserrat',
					'size' 		=> 'large',
					'force_width'	=> '150',
					'title'		=> esc_html__('Main Menu Font-Family', 'deco-elite'),
					'desc'		=> esc_html__('Select the Font-Family for your main menu. Default is Montserrat', 'deco-elite'),
				),
				
				'main_menu_top_padding' => array(
					'type' 		=> 'text',
					'std' 		=> '44px',
					'size' 		=> 'large',
					'title'		=> esc_html__('Main Menu Top Spacing', 'deco-elite'),
					'desc'		=> esc_html__('The main menu top spacing in pixels. Default is 36px.', 'deco-elite')
				),
				
				'main_menu_bottom_padding' => array(
					'type' 		=> 'text',
					'std' 		=> '44px',
					'size' 		=> 'large',
					'title'		=> esc_html__('Main Menu Bottom Spacing', 'deco-elite'),
					'desc'		=> esc_html__('The main menu bottom spacing in pixels. Default is 36px.', 'deco-elite')
				),
				
				'main_menu_element_margin' => array(
					'type' 		=> 'text',
					'std' 		=> '0 17px 0 17px',
					'size' 		=> 'large',
					'title'		=> esc_html__('Main Menu Element Margin', 'deco-elite'),
					'desc'		=> esc_html__('The main menu element margin in this order - top right bottom left. Default is 0 17px 0 17px.', 'deco-elite')
				),
				
				'main_menu_element_padding' => array(
					'type' 		=> 'text',
					'std' 		=> '15px 6px 15px 6px',
					'size' 		=> 'large',
					'title'		=> esc_html__('Main Menu Element Padding', 'deco-elite'),
					'desc'		=> esc_html__('The main menu element padding in this order - top right bottom left. Default is 15px 6px 15px 6px.', 'deco-elite')
				),
				
				/* tab 3 */
				'footer_logo_bg_color' => array(
					'type' 		=> 'select',
					'std' 		=> 'yes',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Enable background color on footer logo', 'deco-elite'),
					'desc'		=> esc_html__('Enable background color on footer logo? Default is YES. Disable if you do not want a background color for your logo.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				'footer_logo_bg_color_select' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#e93712',
					'size' 		=> 'large',
					'title'		=> esc_html__('Footer Logo Background Color', 'deco-elite'),
					'desc'		=> esc_html__('The Footer Logo background color. Choose from the color picker. The default color is: #e93712', 'deco-elite')
				),
				
				'footer_logo' => array(
					'type' 			=> 'upload_image_wp',
					'size' 			=> 'large',
					'force_width'	=> '80',
					'preview_size'	=> 'large',	
					'value' 		=> esc_html__('Upload Image', 'deco-elite'),
					'title' 		=> esc_html__('Logo', 'deco-elite'),
					'desc' 			=> esc_html__('Upload your Footer Logo using the native media uploader', 'deco-elite'),
				),
				
				'footer_logo_width' => array(
					'type' 		=> 'text',
					'std' 		=> '150px',
					'size' 		=> 'large',
					'title'		=> esc_html__('Footer Logo Width', 'deco-elite'),
					'desc'		=> esc_html__('Footer Logo width in pixels. Default value is 150px.', 'deco-elite')
				),
				
				'footer_logo_height' => array(
					'type' 		=> 'text',
					'std' 		=> '90px',
					'size' 		=> 'large',
					'title'		=> esc_html__('Footer Logo Height', 'deco-elite'),
					'desc'		=> esc_html__('Footer Logo height in pixels. Default value is 90px.', 'deco-elite')
				),
				
				'enable_footer_sidebar' => array(
					'type' 		=> 'select',
					'std' 		=> 'yes',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Enable Footer Sidebar', 'deco-elite'),
					'desc'		=> esc_html__('Enable Footer Sidebar? Default is YES.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				'footer_container_background' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#321c18',
					'size' 		=> 'large',
					'title'		=> esc_html__('Footer Container Background Color', 'deco-elite'),
					'desc'		=> esc_html__('The Footer container background color. Choose from the color picker. The default color is: #321c18', 'deco-elite')
				),
				
				'footer_disclaimer_background' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#22100d',
					'size' 		=> 'large',
					'title'		=> esc_html__('Footer Disclaimer Background Color', 'deco-elite'),
					'desc'		=> esc_html__('The Footer disclaimer background color. Choose from the color picker. The default color is: #22100d', 'deco-elite')
				),
				
				'footer_container_text_color' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#d6cfcb',
					'size' 		=> 'large',
					'title'		=> esc_html__('Footer Container Text Color', 'deco-elite'),
					'desc'		=> esc_html__('The footer container text color. Choose from the color picker. The default color is: #d6cfcb', 'deco-elite')
				),
				
				'footer_disclaimer_text_color' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#817a75',
					'size' 		=> 'large',
					'title'		=> esc_html__('Footer Disclaimer Text Color', 'deco-elite'),
					'desc'		=> esc_html__('The footer disclaimer text color. Choose from the color picker. The default color is: #817a75', 'deco-elite')
				),
				
				'footer_font_size' => array(
					'type' 		=> 'text',
					'std' 		=> '146x',
					'size' 		=> 'large',
					'title'		=> esc_html__('The Footer Font Size', 'deco-elite'),
					'desc'		=> esc_html__('The font size for the Footer in pixels. Default value is 16px.', 'deco-elite')
				),
				
				'footer_font_family' => array(
					'type' 		=> 'google-font-select',
					'std' 		=> 'Source Sans Pro',
					'size' 		=> 'large',
					'force_width'	=> '150',
					'title'		=> esc_html__('Footer Font-Family', 'deco-elite'),
					'desc'		=> esc_html__('Select the Font-Family for Footer. Default is Source Sans Pro', 'deco-elite'),
				),
				
				'footer_copyright' => array(
					'type' 		=> 'text',
					'std' 		=> '&copy; Copyright 2014 <a href="' . esc_url('http://aa-team.com') .'">AA-Team</a>. All rights reserved.',
					'size' 		=> 'large',
					'title'		=> esc_html__('The Copyright text', 'deco-elite'),
					'desc'		=> esc_html__('The text for footer copyright', 'deco-elite')
				),
				
				'footer_cols' => array(
					'type' 		=> 'select',
					'std' 		=> '4',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Footer Columns', 'deco-elite'),
					'desc'		=> esc_html__('Select the number of columns for the footer. Default is 4.', 'deco-elite'),
					'options'	=> array(
						  1 => '1',
						  2 => '2',
						  3 => '3',
						  4 => '4',
					)
				),
				
				/* tab 4 */
				'products_per_page' => array(
					'type' 		=> 'text',
					'std' 		=> '12',
					'size' 		=> 'small',
					'title'		=> esc_html__('Numer of products/page on category pages', 'deco-elite'),
					'desc'		=> esc_html__('Input the number of products do you want to be displayed per page on category pages. Default is 12', 'deco-elite')
				),
				
				'enable_ratings' => array(
					'type' 		=> 'select',
					'std' 		=> 'no',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Enable ratings on products', 'deco-elite'),
					'desc'		=> esc_html__('Enable ratings on products? Default is NO.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				'store_description' => array(
					'type' 		=> 'textarea',
					'std' 		=> '<p>Choose between more than 250 articles from our online store!</p>',
					'size' 		=> 'large',
					'title'		=> esc_html__('Store Description', 'deco-elite'),
					'desc'		=> esc_html__('The Store Description wich will appear before shop product list.', 'deco-elite')
				),
				
				'store_image' => array(
					'type' 			=> 'upload_image_wp',
					'size' 			=> 'large',
					'force_width'	=> '80',
					'preview_size'	=> 'large',	
					'value' 		=> esc_html__('Upload Image', 'deco-elite'),
					'title' 		=> esc_html__('Store Image', 'deco-elite'),
					'desc' 			=> esc_html__('Upload your Store image using the native media uploader', 'deco-elite'),
				),
				
				/* tab 5 */
				'enable_complementary_products' => array(
					'type' 		=> 'select',
					'std' 		=> 'yes',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Complementary products section', 'deco-elite'),
					'desc'		=> esc_html__('Enable complementary products section? Default is YES.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				'enable_other_collections' => array(
					'type' 		=> 'select',
					'std' 		=> 'yes',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Other Collections section', 'deco-elite'),
					'desc'		=> esc_html__('Enable "Other Collections" section? Default is YES.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				/* tab 6 */
				'reg_content' => array(
					'type' 		=> 'textarea',
					'std' 		=> '<h3>Your Registration text here</h3>
									<ul>
									<li>Your text here</li>
									<li>Your text here</li>
									<li>Your text here</li>
									<li>Your text here</li>
									</ul>',
					'size' 		=> 'large',
					'title'		=> esc_html__('Registration Content', 'deco-elite'),
					'desc'		=> esc_html__('The Registration Content wich will appear before registration form.', 'deco-elite')
				),
				
				'login_content' => array(
					'type' 		=> 'textarea',
					'std' 		=> '<h3>Your Login text here</h3>
									<ul>
									<li>Your text here</li>
									<li>Your text here</li>
									<li>Your text here</li>
									<li>Your text here</li>
									</ul>',
					'size' 		=> 'large',
					'title'		=> esc_html__('Login Content', 'deco-elite'),
					'desc'		=> esc_html__('The Login Content wich will appear before login form.', 'deco-elite')
				),
				
				/* tab 7 */
				'body_color' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#FFFFFF',
					'size' 		=> 'large',
					'title'		=> esc_html__('Main Container Color', 'deco-elite'),
					'desc'		=> esc_html__('The main container background color. Choose from the color picker. The default color is: #FFFFFF', 'deco-elite')
				),
				'primary_color' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#e93712',
					'size' 		=> 'large',
					'title'		=> esc_html__('Primary Color', 'deco-elite'),
					'desc'		=> esc_html__('The primary color. Choose from the color picker. The default color is: #e93712', 'deco-elite')
				),
				
				'secondary_color' => array(
					'type' 		=> 'color_picker',
					'std' 		=> '#55312a',
					'size' 		=> 'large',
					'title'		=> esc_html__('Secondary Color', 'deco-elite'),
					'desc'		=> esc_html__('The secondary color. Choose from the color picker. The default color is: #55312a', 'deco-elite')
				),
				
				'background_image' => array(
					'type' 			=> 'upload_image_wp',
					'size' 			=> 'large',
					'force_width'	=> '80',
					'preview_size'	=> 'large',	
					'value' 		=> esc_html__('Upload Background', 'deco-elite'),
					'title' 		=> esc_html__('Background Image', 'deco-elite'),
					'desc' 			=> esc_html__('Upload your Background Image for the main container using the native media uploader', 'deco-elite'),
				),
				
				'background_fit' => array(
					'type' 		=> 'select',
					'std' 		=> 'cover',
					'force_width'	=> '160',
					'size' 		=> 'large',
					'title'		=> esc_html__('How to fit background image', 'deco-elite'),
					'desc'		=> esc_html__('Pick one from the list', 'deco-elite'),
					'options'	=> array(
						'cover'     => esc_html__( 'Cover' , 'deco-elite'),
                        'contain'   => esc_html__( 'Contain' , 'deco-elite'),
                        'auto 100%'      => esc_html__( 'Fit Vertically' , 'deco-elite'),
                        '100% auto'      => esc_html__( 'Fit Horizontally' , 'deco-elite'),
                        'center'    => esc_html__( 'Just center' , 'deco-elite'),
                        'repeat'    => esc_html__( 'Repeat' , 'deco-elite'),
					)
				),
				
				/* tab 8 */
				'main_font' => array(
					'type' 		=> 'google-font-select',
					'std' 		=> 'Source Sans Pro',
					'size' 		=> 'large',
					'force_width'	=> '150',
					'title'		=> esc_html__('Body Font', 'deco-elite'),
					'desc'		=> esc_html__('Select the Body Font sitewide. Default is Source Sans Pro', 'deco-elite'),
				),
				
				'headers_font' => array(
					'type' 		=> 'google-font-select',
					'std' 		=> 'Montserrat',
					'size' 		=> 'large',
					'force_width'	=> '150',
					'title'		=> esc_html__('Headers Font', 'deco-elite'),
					'desc'		=> esc_html__('Select the Headers Font sitewide. Default is Montserrat', 'deco-elite'),
				),
				
				'intro_font' => array(
					'type' 		=> 'google-font-select',
					'std' 		=> 'Playfair Display',
					'size' 		=> 'large',
					'force_width'	=> '150',
					'title'		=> esc_html__('Intro Font', 'deco-elite'),
					'desc'		=> esc_html__('Select the Intro Font sitewide. Default is Playfair Display', 'deco-elite'),
				),
				
				/* tab 9 */
				'fb_like_share' => array(
					'type' 		=> 'select',
					'std' 		=> 'no',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Enable Facebook Like/Share on pages', 'deco-elite'),
					'desc'		=> esc_html__('Enable Facebook Like/Share buttons on pages? Default is NO.', 'deco-elite'),
					'options'	=> array(
						'yes' => 'YES',
						'no' => 'NO',
					)
				),
				
				'fb_app_id' => array(
					'type' 		=> 'text',
					'std' 		=> ' ',
					'size' 		=> 'large',
					'force_width'=> '120',
					'title'		=> esc_html__('Facebook App ID', 'deco-elite'),
					'desc'		=> esc_html__('Facebook App ID is used to gather statistics (in your facebook app) about Likes/Shares made by the buttons. Without the App ID, the buttons will work but you will not have statistics.', 'deco-elite'),
				),
			)
		)
	)
);

if( function_exists('wp_site_icon') ) {
	unset( $layout_options[$GLOBALS['decoElite_tried_module']['db_alias']]['config']['elements']['favicon'] );
}

echo json_encode($layout_options);
