<?php
/**
 * Config file, return as json_encode
 * http://www.aa-team.com
 * ======================
 *
 * @author		Andrei Dinca, AA-Team
 * @version		1.0
 */
$decoElite = $GLOBALS['decoElite'];
 echo json_encode(
	array(
		'projects' => array(
			'version' => '1.0',
			'hide_from_menu' => true,
			'menu' => array(
				'order' => 16,
				'title' => esc_html__('Projects', 'deco-elite'),
				'icon' => 'assets/16_icon.png'
			),
			'in_dashboard' => array(
				'icon' 	=> 'assets/32_advsearch.png',
				'url'	=> admin_url("edit.php?post_type=projects")
			),
			'description' => "Projects Custom Post Type.",
			'module_init' => 'init.php'
		)
	)
 );