<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * Override this template by copying it to yourtheme/woocommerce/content-single-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */
global $decoElite, $woocommerce, $product;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

<?php
	/**
	 * woocommerce_before_single_product hook
	 *
	 * @hooked wc_print_notices - 10
	 */
	 do_action( 'woocommerce_before_single_product' );

	 if ( post_password_required() ) {
	 	echo get_the_password_form();
	 	return;
	 }
?>

<div itemscope itemtype="<?php echo woocommerce_get_product_schema(); ?>" id="product-<?php the_ID(); ?>" <?php post_class( array('decoElite-prod-details') ); ?>>
	<meta itemprop="url" content="<?php the_permalink(); ?>" />
	<div class="row">
			<?php
				/**
				 * woocommerce_before_single_product_summary hook
				 *
				 * @hooked woocommerce_show_product_sale_flash - 10
				 * @hooked woocommerce_show_product_images - 20
				 */
				woocommerce_show_product_images();
			?>
		
			<?php
				/**
				 * woocommerce_single_product_summary hook
				 *
				 * @hooked woocommerce_template_single_title - 5
				 * @hooked woocommerce_template_single_rating - 10
				 * @hooked woocommerce_template_single_price - 10
				 * @hooked woocommerce_template_single_excerpt - 20
				 * @hooked woocommerce_template_single_add_to_cart - 30
				 * @hooked woocommerce_template_single_meta - 40
				 * @hooked woocommerce_template_single_sharing - 50
				 */
				//do_action( 'woocommerce_single_product_summary' );
			?>
		    <div class="de_description col-lg-6">
		        <?php woocommerce_template_single_title();?>
		        <h6 class="de_post_in_cat">
		        	<?php 
		        		$terms_list = get_the_term_list( $product->id, 'product_cat', '', ', ', '' ); 
						$terms_list = explode( ',', $terms_list );
						$terms_list = $terms_list[0];
						echo $terms_list; 
		        	?>
		        </h6>
		        <div class="de_line"></div>
		        
		        <div class="de_size_input">
				    <p class="de-quantity-text"><?php esc_html_e('Quantity', 'deco-elite'); ?></p>
				 	<?php
				 		if ( ! $product->is_sold_individually() )
				 			woocommerce_quantity_input( array(
				 				'min_value' => apply_filters( 'woocommerce_quantity_input_min', 1, $product ),
				 				'max_value' => apply_filters( 'woocommerce_quantity_input_max', $product->backorders_allowed() ? '' : $product->get_stock_quantity(), $product )
				 			) );
				 	?>
				 	<?php
						// Availability
						$availability = $product->get_availability(); 
						if ( $availability['availability'] ){
							echo apply_filters( 'woocommerce_stock_html', '<p class="stock ' . esc_attr( $availability['class'] ) . '">' . esc_html( $availability['availability'] ) . '</p>', $availability['availability'] );
						}
					?>
			 	</div>
	 	
				<?php woocommerce_template_single_price();?>
				
				<?php if( isset( $decoElite->coreFunctions->settings['layout']['enable_ratings'] ) && $decoElite->coreFunctions->settings['layout']['enable_ratings'] == 'yes' ) { ?>
				<?php 
					$rating = $product->get_rating_html(); 
					if ( $rating != '' ) { 
				?>
				<div class="de_product_rating_pagination">
			        <p class="de_prating"><span class="de_prating_title"><?php esc_html_e('Reviews','deco-elite');?></span></p>
			        <?php echo $product->get_rating_html(); ?>
			    </div>
			  	<?php } ?>
			    
				<?php } ?>			   
			   
		        <div class="de_social_share">
		        	<span class="de_social_share_title"><?php esc_html_e('Share','deco-elite');?></span>
		            <?php 
				 		$decoElite->coreFunctions->print_share_buttons( $post->ID, $post->post_title, null, true );
				 	?>
		        </div>
		        
		        <?php 
		        	if( shortcode_exists('yith_wcwl_add_to_wishlist')) {
		        		echo do_shortcode('[yith_wcwl_add_to_wishlist wishlist_url="'. get_site_url() .'/wishlist/"]');
					} 
		        ?>
		    	<?php 
		    		if( shortcode_exists('yith_compare_button')) {
		    			echo do_shortcode('[yith_compare_button]'); 
					}
		    	?>
		    	
		    	<?php woocommerce_template_single_add_to_cart(); ?>
		    </div>
		    
	</div>
	
	<?php
		/**
		 * woocommerce_after_single_product_summary hook
		 *
		 * @hooked woocommerce_output_product_data_tabs - 10
		 * @hooked woocommerce_output_related_products - 20
		 */
		do_action( 'woocommerce_after_single_product_summary' );
	?>

</div><!-- #product-<?php the_ID(); ?> -->

<?php do_action( 'woocommerce_after_single_product' ); ?>
