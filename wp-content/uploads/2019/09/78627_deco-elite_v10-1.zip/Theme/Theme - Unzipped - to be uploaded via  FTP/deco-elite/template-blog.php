<?php  
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Amazon Affiliate Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *  Template Name: Template Blog
 *	
**/
get_header();
global $tag, $cat, $decoElite;
?>
	<div class="container-fluid de-template-blog">
		<?php
			$decoElite->coreFunctions->printSidebar( 'left', 'col-lg-3 col-md-4 col-sm-12 col-xs-12' );
		?>
			
		<!-- Main Container -->
		<section class="inner-content" <?php echo $decoElite->coreFunctions->content_width();?>>
			<?php
			$args = array(
				'post_type' => 'post',
				'paged' => $paged,
			);
			
			if( isset($tag) && trim($tag) != "" ){
				$args['tag'] = $tag;
			}
			if( isset($cat) && trim($cat) != "" ){
				$args['cat'] = $cat;
			}
			query_posts($args);
			?>
			<?php if ( have_posts() ) : ?>
			
			<div class="blog-box">
				<?php while( have_posts() ) : the_post(); ?>
				<?php $format = get_post_format(); ?>
				<?php $post_layout = get_post_meta(get_the_ID(), '_layout', true); ?>
				
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="de_simple_post">
						<div class="de_simple_post_description <?php echo has_post_thumbnail() == false ? 'full' : '';?> ">
							<div class="de-post-title-container">
								<p class="de-post-date"><a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"><span class="de-day"><?php echo get_the_date('d'); ?></span><span  class="de-month"><?php echo get_the_date('M'); ?></span><span class="de-year"><?php echo get_the_date('Y'); ?></span></a></p>
								<div class="de-post-title-wrap">
									<?php if( !has_post_format( 'quote' ) && !has_post_format('aside') ) { ?>
										<?php if( has_post_format( 'link' ) ) { ?>
											<h2><a href="<?php echo esc_url( $decoElite->coreFunctions->deco_get_link_url() ); ?>" rel="bookmark"><?php  the_title(); ?></a></h2>
										<?php }else{ ?>
											<h2><a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"><?php  the_title(); ?></a></h2>
										<?php } ?>
									<?php } ?>
									<div class="clear"></div>
									<p class="de-post-author"><i class="fa fa-user"></i><?php esc_html_e('by', 'deco-elite');?> <?php echo get_the_author(); ?></p>
									<p class="de-post-cat"><i class="fa fa-list-alt"></i><?php the_category(', ', 'multiple'); ?></p>
									<p class="de-comments-no"><i class="fa fa-comments-o"></i><?php echo get_comments_number().' '.esc_html__('comments', 'deco-elite'); ?></p>
									
									<?php if( has_post_format( 'quote' ) ) { ?>
										<div class="clear"></div>
										<div class="quote">
											<?php the_content(); ?>
										</div>
									<?php }else if( has_post_format('aside') ) { ?>
										<div class="clear"></div>
										<div class="aside">
											<?php the_content(); ?>
										</div>
									<?php } ?>
								</div>
							</div>
							<div class="clear"></div>
							<?php if( has_post_thumbnail() && ($format == '' || $format == 'video')  ) { ?>
								
								<div class="de_simple_post_image">
									<?php echo get_the_post_thumbnail( $post->ID, 'decoElite-blog-featured-image' ); ?>
									
									<a href="<?php echo esc_url( get_permalink() ); ?>" class="info">
										<span class="mask">
											<i class="fa fa-link"></i>
										</span>
									</a>
								</div>
								
							<?php }else if( $format == 'gallery' && has_shortcode( get_the_content(), 'gallery' ) ) { ?>
								
							<?php
								$gallery_img_ids = $decoElite->coreFunctions->get_gallery_attachments();
								
								if( count($gallery_img_ids) > 0 ) {
							?>
							
								<div class="list-blog-gallery">
									<?php
									foreach( $gallery_img_ids as $img_id ) {
										//$img = wp_get_attachment_url( $img_id );
										$img = wp_get_attachment_image( $img_id, 'decoElite-blog-featured-image' );
									?>
										<div class="item"><?php echo $img; ?></div>
									<?php } ?>
								</div>
								
							<?php }else if( has_post_thumbnail() ) { ?>
								
								<div class="de_simple_post_image">
									<?php echo get_the_post_thumbnail( $post->ID, 'decoElite-blog-featured-image' ); ?>
									
									<a href="<?php echo esc_url( get_permalink() ); ?>" class="info">
										<span class="mask">
											<i class="fa fa-link"></i>
										</span>
									</a>
								</div>
								
							<?php
								}
							
							}else if( in_array($format, array('video', 'audio', 'status')) ) { ?>
								
								<div class="de_blog_short_desc">
									<?php
									if( isset($post_layout['video_embed']) && trim($post_layout['video_embed']) != '' ) {
										echo $post_layout['video_embed'];
									}else{
										the_content();
									}
									?>
								</div>
								
							<?php } ?>
							
							<?php
							if( has_post_format( 'link' ) ) {
								echo '<a href="' . esc_url( $decoElite->coreFunctions->deco_get_link_url() ) . '" rel="bookmark" class="link">' . esc_url( $decoElite->coreFunctions->deco_get_link_url() ) . '</a>';
							}else if ( $format == '' || in_array($format, array('gallery', 'chat')) ) {
							?>
								<div class="de_blog_short_desc"><?php the_excerpt(); ?></div>
							<?php } ?>
							
							<?php
							wp_link_pages( array(
								'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'deco-elite' ) . '</span>',
								'after'       => '</div>',
								'link_before' => '<span class="page">',
								'link_after'  => '</span>',
								'pagelink'    => '%',
							) );
							?>
							
							<?php if( !in_array($format, array('link', 'quote', 'aside', 'status' )) ) { ?>
								<a href="<?php echo esc_url( get_permalink() ); ?>" class="de_read_more"><?php esc_html_e('Read More', 'deco-elite');?></a>
							<?php } ?>
						</div>
					</div>
					
					<div class="clearfix"></div>
					<hr class="de_line"/>
				</article>
				
				<?php endwhile; ?>
				<?php if( $wp_query->post_count < $wp_query->found_posts ) { ?>
				<div class="row blog_row">
					<nav class="post-pagination woocommerce-pagination">
					<!-- Pagination -->
					<?php
						$big = 999999999; // need an unlikely integer
						echo paginate_links( array(
							'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
							'format' => '?paged=%#%',
							'current' => max( 1, get_query_var('paged') ),
							'total' => $wp_query->max_num_pages,
							'prev_next' => false,
							'type' => 'list'
						) );
						$paged = intval(get_query_var('paged'));
						$max_page = intval( $wp_query->max_num_pages );
						$posts_count = intval( $wp_query->found_posts );
						if( empty( $paged ) || $paged == 0 ) {
							$paged = 1; 
						}
					?>
					</nav>
					<p class="de-post-loop-count"><?php esc_html_e('Showing', 'deco-elite'); ?> <?php echo $paged; ?>-<?php echo $max_page; ?> of <?php echo $posts_count; ?> <?php esc_html_e('results', 'deco-elite'); ?></p>
				</div>
				<?php } ?>
			</div>
		
			<div class="clearfix"></div>
			
			<?php else : ?>
				<?php get_template_part( 'template', 'none' ); ?>
			<?php endif; ?>
		</section>
		
		<?php
			$decoElite->coreFunctions->printSidebar( 'right', 'col-lg-3 col-md-4 col-sm-12 col-xs-12' );
		?>
	</div>

<?php get_footer(); ?>