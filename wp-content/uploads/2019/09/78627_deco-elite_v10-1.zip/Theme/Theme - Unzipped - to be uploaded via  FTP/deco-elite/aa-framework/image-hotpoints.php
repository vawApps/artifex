<?php
/*
* Define class decoEliteImagesHotpoints
* Make sure you skip down to the end of this file, as there are a few
* lines of code that are very important.
*/
!defined('ABSPATH') and exit;

if (class_exists('decoEliteImagesHotpoints') != true) {
    class decoEliteImagesHotpoints
    {
        /*
        * Some required plugin information
        */
        const VERSION = '1.0';

        /*
        * Store some helpers config
        */
		public $the_plugin = null;

		private $module_folder = '';
		private $module = '';

		static protected $_instance;
		
		private $settings;

        /*
        * Required __construct() function that initalizes the AA-Team Framework
        */
        public function __construct()
        {
        	global $decoElite;

        	$this->the_plugin = $decoElite;
			
			if (is_admin()) {
				add_action( 'admin_head', array( $this, 'load_assets' ) );
				add_action( 'admin_footer', array( $this, 'lightbox' ) );
			}
			
			add_action('wp_ajax_decoEliteImagesHotpoints', array( $this, 'ajax_request' ));
        }
		
		public function load_assets()
		{
			global $typenow;
 			  
		    // only on Post Type: post and page
		    if( ! in_array( $typenow, array( 'projects' ) ) )
		        return ;
			
			wp_enqueue_script('deco-json2', $this->the_plugin->cfg['paths']['freamwork_dir_url'] . '/js/json2.js', array('jquery'));
			wp_enqueue_script('deco-hotpoints', $this->the_plugin->cfg['paths']['freamwork_dir_url'] . '/js/hotpoints.js', array('jquery'));
			wp_enqueue_script('deco-chosen', $this->the_plugin->cfg['paths']['freamwork_dir_url'] . '/js/chosen.jquery.js', array('jquery'));
			wp_enqueue_style('deco-chosen-css', $this->the_plugin->cfg['paths']['freamwork_dir_url'] . '/css/chosen.css');
		}
		
		// inline content for woo amazon add new products
		public function lightbox()
		{
			$html = array();
			
			$html[] = '<div class="deco-hotpoints-lightbox" id="decoEliteLighbox" style="display: none">';
			$html[] = 	'<div id="decoEliteLighboxContent"></div>';
			$html[] = '</div>';
			
			echo implode( "\n", $html );
		}
		
		
		public function ajax_request()
		{
			$html = array();
			
			
			$params = array(
				'sub-action' => isset($_REQUEST['subaction']) ? $_REQUEST['subaction'] : '',
				'image' => isset($_REQUEST['image']) ? $_REQUEST['image'] : '',
			);
			
			if( $params['sub-action'] == 'create-interface' ){
				
				$image_full = wp_get_attachment_image_src( $params['image'], 'full' );
				$image_full_src = $image_full[0];
                
                // prop = width / height
                $image_prop = $image_full[1] / $image_full[2];
                $image_prop = number_format($image_prop, 5);
				
				$html[] = '<div id="deco-interface-wrapper">';
				$html[] = 	'<div id="deco-interface-full-image"><img src="' . ( $image_full_src ) . '" data-width="' . ( $image_full[1] ) . '" data-height="' . ( $image_full[2] ) . '" data-prop="' . ( $image_prop ) . '" /></div>';
				
				$html[] = 	'<ul class="hotpoints-images"><li id="deco-no-pins">NO pins. Click on image to create a new pin.</li></ul>';
				$products = $this->getAllPublishProducts();
				$html[] = 	'<script id="deco-add-new-tpl" type="text/template">
					<li>
						<table class="deco-product-row">
							<tr>
								<td class="deco-product-image">
									<img src="http://placehold.it/30x30" />
								</td>
								<td class="deco-product-details">
									<select class="de-chose-select" data-thumb="http://placehold.it/30x30" data-placeholder="Choose a product...">';
									foreach ($products as $product) {
										$html[] =	'<option value="' . ( $product['ID'] ) . '" data-thumb="' . ( $product['thumb'] ) . '">' . ( $product['title'] ) . '</option>';
									}
				$html[] = 			'</select>
								</td>
								<td class="deco-product-action">
									<a href="#remove" class="decoElite-button red deco-product-remove">remove</a>
								</td>
							</tr>
						</table>
					</li>	
					</script>';
					
				$html[] = 	'<div class="hotpoints-options">
					<a href="#" class="decoElite-button green deco-box-done">Done</a>
					<!--span>You need to save the page for saving the pins.</span-->
				</div>';
				$html[] = '';
				$html[] = '</div>';
			}
 
			die( json_encode(array(
				'status' => 'valid',
				'html'	=> implode( "\n", $html )
			)) );
		}
		
		public function get_the_post_thumbnail_src($img)
		{
		  return (preg_match('~\bsrc="([^"]++)"~', $img, $matches)) ? $matches[1] : '';
		}

		final protected function getAllPublishProducts()
		{
		
			$ret = array();
			$args = array();
			$args['post_type'] = 'product';
	
			// show all posts
			$args['fields'] = 'ids';
			$args['posts_per_page'] = '-1';
			
			$loop = new WP_Query( $args );
			$cc = 0;
			$html = array(); 
			$ret[] = array(  
				'ID' => 0,
				'title' => 'Select one from list above',
				'thumb' => ''
			);
			while ( $loop->have_posts() ) : $loop->the_post();
				global $post;
				
				$asin = get_post_meta( $post, '_amzASIN', true );
				$ret[] = array(  
					'ID' => $post,
					'title' => get_the_title(),
					'thumb' => $this->get_the_post_thumbnail_src( get_the_post_thumbnail( $post, array(30, 30) ) )
				);
				
			endwhile;
			return $ret;
		}


		/**
	    * Singleton pattern
	    *
	    * @return decoEliteImagesHotpoints Singleton instance
	    */
	    static public function getInstance()
	    {
	        if (!self::$_instance) {
	            self::$_instance = new self;
	        }

	        return self::$_instance;
	    }

		/**
	    * Hooks
	    */
	    static public function adminMenu()
	    {
	       self::getInstance()
	    		->_registerAdminPages();
	    }
    }
}
decoEliteImagesHotpoints::getInstance();