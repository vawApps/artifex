<?php  
/**
 * @package WordPress
 * @subpackage:
 *	Name: 	decoElite Amazon Affiliate Theme
 *	Alias: 	decoElite
 *	Author: AA-Team
 *	Name: 	http://themeforest.net/user/AA-Team/portfolio
 *	
**/
get_template_part( 'template-blog' );