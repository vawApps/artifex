/*
Document   :  decoEliteSidebarsPerPages
Author     :  AA-Team http://themeforest.net/user/AA-Team
*/
// Initialization and events code for the app
decoEliteSidebarsPerPages = (function ($) {
    "use strict";

    // public
    var debug_level = 0;
    var maincontainer = null;

	// init function, autoload
	(function init() {
		// load the triggers
		$(document).ready(function(){
			maincontainer = $(".decoElite-panel");
			triggers();
		});
	})();
	
	function changeToPanel( elm )
	{
		var section = elm.data('section'),
			section_obj = $("#decoElite-panel-" + section);
		
		$(".decoElite-panel-sections-choose").hide();
		
		section_obj.show();
		
		
		$('#decoElite-sections-choose a.on').removeClass('on');
		elm.addClass('on');
	}
	
	function saveThePanel( elm )
	{
		elm.find("#decoElite-status-box").fadeIn('fast');
	}
	
	function triggers()
	{
		maincontainer.on('click', '#decoElite-sections-choose a', function(e) {
			e.preventDefault();
			changeToPanel( $(this) );
		});
		
		// click on first element
		$('#decoElite-sections-choose a').eq(0).click();
		
		maincontainer.on('submit', '#decoElite_sidebars_per_sections', function(e) {
			e.preventDefault();
			
			saveThePanel( $(this) );
		});
	}

	// external usage
	return {}
})(jQuery);