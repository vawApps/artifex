<?php
/**
 * Config file, return as json_encode
 * http://www.aa-team.com
 * ======================
 *
 * @author		AA-Team
 * @version		1.0
 */
$decoElite = $GLOBALS['decoElite']; 
echo json_encode(
	array(
		'color_filter' => array(
			'version' => '1.0',
			'title' => esc_html__('Color filter', 'deco-elite'),
			'description' => esc_html__("Here you can filter your products based on color", 'deco-elite'),
			'options' => array(
				'title' 	=> array(
					'title'		=> esc_html__('Title', 'deco-elite'),
					'type' 		=> 'text',
					'width'		=> '100%',
					'std' 		=> esc_html__('Color filter title', 'deco-elite')	
				)
			)
		)
	)
);