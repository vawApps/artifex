<?php 
// retrive the main class as global
global $decoElite;

$de_page_layout = isset($decoElite->coreFunctions->data['layout']) ? $decoElite->coreFunctions->data['layout'] : array();
$post_id = 0;
if( is_array($post) || is_object($post) ){
	$post_id = $post->ID;
}

$slideshow_type = get_post_meta( $post_id, '_layout' );
$revslider_select = get_post_meta( $post_id, '_layout' ); 
$slideshow_type = isset($slideshow_type[0]["slideshow_type"]) ? $slideshow_type[0]["slideshow_type"] : array();
if( isset( $revslider_select[0]["revolution_slider_select"] ) ) {
	$revslider_select = $revslider_select[0]["revolution_slider_select"];
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <link rel="pingback" href="<?php esc_url( bloginfo( 'pingback_url' ) ); ?>" />
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<!-- NAVIGATION -->
	<div class="navbar de-navigation">
		<?php if( isset($decoElite->coreFunctions->settings['layout']['enable_top_navigation']) && trim($decoElite->coreFunctions->settings['layout']['enable_top_navigation']) && $decoElite->coreFunctions->settings['layout']['enable_top_navigation'] == 'yes' ){ ?>
		<div class="de-top-nav clearfix"> <!-- start of .de-top-navbar -->
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-6 col-lg-6">
						<div class="pull-left">
							<?php
							$my_account_page_id = get_option('woocommerce_myaccount_page_id');
							if ( is_user_logged_in() ) {
								$logout_url = wp_logout_url( get_permalink( $my_account_page_id ) );
								
								if ( get_option( 'woocommerce_force_ssl_checkout' ) == 'yes' )
									$logout_url = str_replace( 'http:', 'https:', $logout_url );
							?>
								<a href="<?php echo esc_url(get_permalink( $my_account_page_id )); ?>" title="<?php esc_html_e('My Account','deco-elite'); ?>"><?php esc_html_e('My Account','deco-elite'); ?></a>
								<a href="<?php echo esc_url($logout_url); ?>" title="<?php esc_html_e('Sign out','deco-elite'); ?>"><?php esc_html_e('Sign out','deco-elite'); ?></a>
							<?php } else { ?>
								<a href="<?php echo esc_url(get_permalink( $my_account_page_id )); ?>" title="<?php esc_html_e('Login / Register','deco-elite'); ?>"><?php esc_html_e('Login / Register','deco-elite'); ?></a>
							<?php } ?>
							
							<?php
							if(has_nav_menu( 'top_nav' )){
								//Top Menu
								$menuParams = array(
									'theme_location' => 'top_nav',
							        'container'      => false,
							        'echo'            => false,
							        'items_wrap'      => '%3$s',
							        'depth'           => 0,
							    );
								echo strip_tags( wp_nav_menu( $menuParams ), '<a>' );
							}
							?>
						</div>
					</div>
					<div class="col-md-6 col-lg-6 top-pull-left">
						<div class="de-tn-right">
							<?php if ( class_exists( 'YITH_WCWL') && isset($decoElite->coreFunctions->settings['layout']['wishlist_page']) && $decoElite->coreFunctions->settings['layout']['wishlist_page'] > 0 ) {
								$wcwl = new YITH_WCWL($details = '' );
								$wishlist_page_link = esc_url( get_permalink( $decoElite->coreFunctions->settings['layout']['wishlist_page'] ));
							?>
							<a href="<?php echo $wishlist_page_link; ?>" class="de-wishlist"><i class="fa fa-heart"></i> <?php esc_html_e('Wishlist', 'deco-elite');?> (<?php echo $wcwl->count_products(); ?>)</a>
							<?php } ?>
							<?php
							if( isset($decoElite->coreFunctions->settings['layout']['phone_support']) && trim($decoElite->coreFunctions->settings['layout']['phone_support']) ){
							?>
								<a href="skype:<?php echo $decoElite->coreFunctions->settings['layout']['phone_support'];?>?call" class="de-phone"><i class="fa fa-phone"></i> <?php echo $decoElite->coreFunctions->settings['layout']['phone_support'];?></a>
							<?php
							} 
							?>
							
							<!-- Search -->
							<div id="de-search" class="de-search">
							  <form action="<?php echo esc_url( home_url('/') ); ?>" method="get">
							  	<input class="de-search-input" placeholder="<?php esc_html_e('to search type and hit enter', 'deco-elite'); ?>" type="search" value="" id="search" name="s" autocomplete="off">
							    <input class="de-search-submit" type="submit" value="">
							    
							    <span class="de-icon-search"></span>
							  </form>
							</div>
							<!-- Show Results -->
							<div id="de-search-results">
								<h4 id="results-text"><?php esc_html_e('Showing results for:', 'deco-elite'); ?> <b id="search-string"></b></h4>
								<ul id="results"></ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div> <!-- END of .de-top-navbar -->
		
		<?php } ?>
			
		<?php
			if( isset($decoElite->coreFunctions->settings['layout']['sticky_header']) && trim($decoElite->coreFunctions->settings['layout']['sticky_header']) && $decoElite->coreFunctions->settings['layout']['sticky_header'] == 'yes' ){
				$sticky_header = "de-sticky-header";
			} else {
				$sticky_header = "";
			}
		?>
		<div class="de-main-nav <?php echo $sticky_header; ?>"> <!-- start of .de-main-nav -->
			<div class="container-fluid">
				<!-- Logo -->
				<div class="de-logo">
					<a href="<?php echo esc_url( home_url('/') ); ?>">
						<?php 
						 
						if( !isset($decoElite->coreFunctions->settings['layout']['logo']) || empty($decoElite->coreFunctions->settings['layout']['logo']) ){
							echo '<img src="' . ( $decoElite->cfg['paths']['theme_dir_url'] ) . 'images/deco-icon-logo1.png">';
						}else{
							echo wp_get_attachment_image( $decoElite->coreFunctions->settings['layout']['logo'], 'full' );
						}
						?>
					</a>
				</div>

				<!-- Nav Links -->
				<?php
				if( has_nav_menu( 'main_nav' )){
					//Main Menu
					wp_nav_menu(array(
						'theme_location' => 'main_nav',
				        'container'      => 'div',
				        'container_class' => 'de-main-menu',
				        //'container_class' => 'collapse navbar-collapse de-main-menu',
				        'menu_class'	=> 'nav navbar-nav navbar-right',
				    ));
				}
				?>
				<?php
				if( $decoElite->is_woo_activated() ) {
				?>
					<?php global $woocommerce; ?>
					<!-- Cart -->
					<?php if( isset($decoElite->coreFunctions->settings['layout']['enable_cart']) && trim($decoElite->coreFunctions->settings['layout']['enable_cart']) && $decoElite->coreFunctions->settings['layout']['enable_cart'] == 'yes' ){ ?>
						<div class="de-cart">
							<a class="cart-contents" href="#">
								<i class="mi-icon mi-icon-cart5"></i>
								<span class="de-items">(<?php echo sprintf(_n('%d', '%d', $woocommerce->cart->cart_contents_count, 'woothemes'), $woocommerce->cart->cart_contents_count);?>)</span> <span class="de-total-price"><?php echo $woocommerce->cart->get_cart_total(); ?></span>
							</a>
							<div class="de-cart-details-wrapper"><!-- start of .de-cart-details-wrapper -->
						    	<div class="de-cart-details"><!-- start of .de-cart-details -->
						      		<div class="de-cart-details-products"><!-- start of .de-cart-details-products -->
						    			<?php woocommerce_get_template( 'cart/mini-cart.php' ); ?>
						      		</div><!-- END of .de-cart-details-products -->
						      		
						      		<div class="de-cart-subtotal">
						        		<h2><?php esc_html_e('Order subtotal', 'deco-elite'); ?></h2>
						        		<p><?php esc_html_e('Excludes shipping &amp; handling', 'deco-elite'); ?></p>
						        		<span><?php echo WC()->cart->get_cart_subtotal(); ?></span>
						      		</div>
						      		<div class="de-cart-checkout">
						      			<a href="<?php echo esc_url( WC()->cart->get_checkout_url() ); ?>" class="de-checkout"><?php esc_html_e('Checkout', 'deco-elite'); ?></a>
						      			<a class="de-viewcart" href="<?php echo esc_url( $woocommerce->cart->get_cart_url() ); ?>" title="<?php esc_html_e('View your shopping cart', 'deco-elite'); ?>"><?php esc_html_e( 'View Cart', 'deco-elite' ); ?></a>
						      		</div>
						    	</div><!-- END of .de-cart-details -->          
						  	</div><!-- END of .de-cart-details-wrapper -->
						</div>
					<?php } ?>
				<?php } ?>
				<div class="clear"></div>
			</div>
		</div> <!-- END of .de-main-nav -->
		
		<!-- Breadcrumbs -->
		<?php if( !is_front_page() || !isset( $slideshow_type ) || $slideshow_type == 'none' || count($slideshow_type) == 0 ){ ?>
		<div class="de-breadcrumb"> <!-- start of .de-top-navbar -->
			<div class="container-fluid">
				<div class="de-links">
					<?php echo $decoElite->coreFunctions->display_breadcrumbs();?>
				</div>
			</div>
		</div> <!-- END of .de-top-navbar -->
		<?php
		}
		?>

	</div> <!-- END NAVIGATION -->
	
	<!-- Slider -->
	<?php
	if ( isset( $slideshow_type ) && count( $slideshow_type ) > 0 ) {
		if( $slideshow_type == 'revolution-slider' ) {
			putRevslider( $revslider_select );
		}
	} 
	?>
	<!-- end Slider -->
