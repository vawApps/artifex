<?php
/**
 * Single Product Image
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.14
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $post, $woocommerce, $product, $decoElite;
if ( has_post_thumbnail() ) {
	/*$image_title = esc_attr( get_the_title( get_post_thumbnail_id() ) );
	$image_link  = wp_get_attachment_url( get_post_thumbnail_id() );
	$image       = get_the_post_thumbnail( $post->ID, apply_filters( 'single_product_large_thumbnail_size', 'shop_single' ), array(
		'title' => $image_title
	));*/
	
	$attachment_ids = $product->get_gallery_attachment_ids();

	//$attachment_count = count( $attachements_ids );
	$gallery = '-prod-details';
	
	$images = array();
	if ( $attachment_ids ) {
		foreach ( $attachment_ids as $attachment_id ) {
			$full_img = wp_get_attachment_image_src( $attachment_id, 'full' );
			$images[] = array(
				'thumb' => wp_get_attachment_image( $attachment_id, array(86, 86), false, array('class' => 'class_image') ),
				'full_img' => $full_img[0]
			);
		}
	}  
}
?>

<div class="de_gallery_container <?php echo count($images) <= 1 ? 'de_gallery_no_images' : '';?> col-lg-6">
    <div class="de_image_large">
    	<?php if( $product->is_on_sale() ){?>
        	<span class="de-sale-badge">Sale</span>
        <?php }?>
        <div id="de_image_large_gallery">
	        <?php
			if ( has_post_thumbnail() ) {
				if ( $attachment_ids ) { 
                    $loop = 0;
                    $columns = apply_filters( 'woocommerce_product_thumbnails_columns', 3 );						
                    
                    foreach ( $attachment_ids as $attachment_id ) {

                        $classes = array( 'zoom' );
            
                        if ( $loop == 0 || $loop % $columns == 0 )
                            $classes[] = 'first';
            
                        if ( ( $loop + 1 ) % $columns == 0 )
                            $classes[] = 'last';
            
                        $image_link = wp_get_attachment_url( $attachment_id );
            
                        if ( ! $image_link )
                            continue;
            
                        $image       = wp_get_attachment_image( $attachment_id, apply_filters( 'single_product_small_thumbnail_size', 'shop_thumbnail' ) );
                        $image_class = esc_attr( implode( ' ', $classes ) );
                        $image_title = esc_attr( get_the_title( $attachment_id ) );

						echo sprintf( '<div class="item"><a href="%s" itemprop="image" class="woocommerce-main-image zoom" title="%s" data-rel="prettyPhoto' . $gallery . '">%s</a></div>', wp_get_attachment_url( $attachment_id ), $image_title, wp_get_attachment_image( $attachment_id, 'shop_single' ) );
						
                        $loop++;
                    }
                }
			} else {
				echo apply_filters( 'woocommerce_single_product_image_html', sprintf( '<img src="%s" alt="Placeholder" />', wc_placeholder_img_src() ), $post->ID );
			}
			?>
    	</div>
    </div>
    
    <?php
		if ( has_post_thumbnail() ) {
			
			if( count($images) > 1 ){
		    ?>
		    <div id="de_product_gallery">
		    	<?php
				foreach ( $images as $image ) { 
				?>
				<div class="owl-item">
					<div class="item">
			            <a href="<?php echo $image['full_img'];?>">
			                <?php echo $image['thumb'];?>
			            </a>
			        </div>
			    </div>
				<?php
				}
				?>
		    </div>
		<?php
		}
	}
	?>
</div>